# Databricks notebook source
# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

import psycopg2
import json
import pandas as pd
import os
from datetime import datetime

# COMMAND ----------

# Declare and assign variables
awsSecretKeyName = 'DATABRICKS_ENV_CONFIG'
s3_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_mountpoint']
study_id = dbutils.widgets.get("src_study_id")
env = dbutils.widgets.get("src_env")
tgt_study_id = dbutils.widgets.get("tgt_study_id")
user_email =dbutils.widgets.get("userEmail")
# Generate the target folder paths
folder_name = "copy_study_assets/" + tgt_study_id.lower() + f"/{study_id}/{env}/".lower() + datetime.now().strftime('%Y%m%d')
file_path = f"{s3_mountpoint}/{folder_name}"
file_name = "export_" + datetime.now().strftime('%Y%m%d_%H%M%S')
tmp_file_path=f"{file_path}/{file_name}.tmp"
export_file=f"{file_path}/{file_name}.csv"
final_file_path=f"{folder_name}/{file_name}.csv"
print(file_path)
print(tmp_file_path)
print(export_file)
print(final_file_path)


# COMMAND ----------

# Override default EKS Postgres details with Sandbox Postgres details
# dbMarvelHost="marvel-dre-cer-sbox.ccww0oqaizad.us-east-1.rds.amazonaws.com"
# dbMarvelUser="sa_marvel_sbox_readwrite"
# dbMarvelPwd=

# COMMAND ----------

connection = None
response = ""
try:
    print('Connection to DB')
    connection = psycopg2.connect(user=dbMarvelUser,
                                    password=dbMarvelPwd,
                                    host=dbMarvelHost,
                                    port=dbMarvelPort,
                                    database=dbMarvelName)
    cursor = connection.cursor()
    # Query to fetch study listing records for a data source of a study
    studyListingQuery = f"""WITH study_assets AS (SELECT av.asset_id, av.id AS asset_version_id, a.display_id,
                            a.is_active, av.is_latest, av.description, sla.config
                      FROM dre.asset a
                      JOIN dre.asset_version av ON av.asset_id = a.id
                      JOIN dre.study_lifecycle_assets sla on sla.asset_id = a.id AND sla.asset_version_id = av.id
                      WHERE sla.study_lifecycle_version_id = (select study_lifecycle_version_id
                                                              from dre.get_latest_study_lifecycle_version('{study_id}', '{env}')
                                                             )
                     )
SELECT '{study_id}' as source_study_id, '{env}' as source_env, asset_type, name, display_id
FROM (SELECT 'Listing' AS asset_type, sa.display_id, sl.label AS name, 1 AS sort_order
      FROM study_assets sa
      JOIN dre.study_listing sl ON sa.asset_version_id = sl.id
      UNION ALL
      SELECT 'Visualization' AS asset_type, sa.display_id, sv.label AS name, 2 AS sort_order
      FROM study_assets sa
      JOIN dre.study_visualization sv ON sa.asset_version_id = sv.id
      UNION ALL
      SELECT 'Page' AS asset_type, sa.display_id, sp.config->>'title' AS name, 3 AS sort_order
      FROM study_assets sa
      JOIN dre.study_page sp ON sa.asset_version_id = sp.id
      UNION ALL
      SELECT 'Patient Profile' AS asset_type, sa.display_id, spp.config->>'title' AS name, 4 AS sort_order
      FROM study_assets sa
      JOIN dre.study_patient_profile spp ON sa.asset_version_id = spp.id
      UNION ALL
      SELECT 'Review Requirement' AS asset_type, sa.display_id, srr.title AS name, 5 AS sort_order
      FROM study_assets sa
      JOIN dre.study_rr srr ON sa.asset_version_id = srr.id
     ) assets
ORDER BY sort_order"""
    cursor.execute(studyListingQuery)
    print("Fetching study")
    column_names = [desc[0] for desc in cursor.description]
    print(column_names)
    
    df = spark.createDataFrame(cursor.fetchall(), column_names)
    
    # Create the target folder if it does not exist
    retVal = dbutils.fs.mkdirs(file_path)

    if retVal:
        print(f"Directory [{file_path}] created successfully")
    else:
        raise Exception("Unable to create the target directory")

    # Export the data from dataframe to temporary CSV file
    df.coalesce(1).write.csv(tmp_file_path, header=True)

    # Get the details of the temporary CSV file
    part_file_list = list(filter(lambda file: file.name.endswith(".csv"), dbutils.fs.ls(tmp_file_path)))

    # Generate the export file from temporary CSV file
    if len(part_file_list) > 0:
        # Move the part file to target file name
        dbutils.fs.mv(part_file_list[0].path, export_file)
        # Check if file is moved succesfully
        dbutils.fs.ls(export_file)
        # Removed the temporary filder
        dbutils.fs.rm(tmp_file_path, True)
        
        print(f"File [{tmp_file_path}] has been renamed to [{export_file}] successfully")
        response = f"Assets from study [{study_id}] and environment [{env}] have been successfully exported to [{final_file_path}] in the mbox [{env}] landing zone."
        print(response)
        execution_status ="Success"
    else:
        # Removed the temporary filder
        dbutils.fs.rm(tmp_file_path, True)
        execution_status ="Failure"
        raise Exception("No file created in the temporary path [{tmp_file_path}].")
    
except (Exception, psycopg2.Error) as error:
    if 'java.io.FileNotFoundException' in str(error):
        print("Error while checking the file existance: ", error) 
        execution_status ="Failure"
        response = f"Error: Export file [{export_file}] could not be created."
    elif 'non-existent directory' in str(error):
        print("Error while writing that data into target file: ", error) 
        execution_status ="Failure"
        response = f"Error: Export file [{export_file}] could not be created."
    else:
        print("Error while fetching data from PostgreSQL", error) 
        execution_status ="Failure"
        response = "Exception - "+ str(error)
    
finally:
    # closing database connection.
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")


# COMMAND ----------

try:
    print('Audit log:Connection to DB')
    connection = psycopg2.connect(user=dbMarvelUser,
                                  password=dbMarvelPwd,
                                  host=dbMarvelHost,
                                  port=dbMarvelPort,
                                  database=dbMarvelName)
    cursor = connection.cursor()
    stuy_uuid_qry = f"""select asset_id, asset_version_id from dre.get_study_version_table('{study_id}', 'PROD')"""
    cursor.execute(stuy_uuid_qry)
    print("Fetching study uuid")
    records1 = cursor.fetchall()
    study_asset_uuid = records1[0][0]
    study_lifecycle_version_uuid = records1[0][1]
    
    fn_param_value = json.dumps({
        'status': execution_status
    })
    param_value = json.dumps({
        'source_studyid': study_id,
        'target_studyid': tgt_study_id,
    })
    
    audit_log_qry = f"""select * from dre.insert_audit_log('{study_asset_uuid}', '{study_lifecycle_version_uuid}', '{user_email}', 'Export_Study_Assets', '{param_value}'::jsonb, '{fn_param_value}'::jsonb, '{response}')"""
    cursor.execute(audit_log_qry)
    connection.commit()
    cursor.close()
    connection.close()
    
except Exception as e:
    print("Exception message: ", e)
    raise e

# COMMAND ----------

# Exit the notebook with the response text
dbutils.notebook.exit(response)
