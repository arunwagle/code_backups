# Databricks notebook source
# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

import psycopg2
import pandas as pd
import json

# COMMAND ----------

# Override default EKS Postgres details with Sandbox Postgres details
# dbMarvelHost="marvel-dre-cer-sbox.ccww0oqaizad.us-east-1.rds.amazonaws.com"
# dbMarvelUser="sa_marvel_sbox_readwrite"
# dbMarvelPwd=

# COMMAND ----------

# Get the parameter values
import_file_path = dbutils.widgets.get("import_file_path")
tgt_study_id = dbutils.widgets.get("tgt_study_id")
src_study_id = dbutils.widgets.get("src_study_id")
src_env = dbutils.widgets.get("src_env")
user_email =dbutils.widgets.get("userEmail")

# Set the final import path
awsSecretKeyName = 'DATABRICKS_ENV_CONFIG'
s3_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_mountpoint']
full_file_path = "/dbfs" + s3_mountpoint + "/" + import_file_path

print('User performing the study copy: ', user_email)
print('Import file path : ', full_file_path)
print('Source Study : ', src_study_id)
print('Source Env : ', src_env)
print('Target Study : ', tgt_study_id)


# COMMAND ----------

# Read the data from import file
df = pd.read_csv(full_file_path)

# Check if the entered parameter match the uploaded file
study_count = df.source_study_id.unique().size
env_count = df.source_study_id.unique().size
study_id = df.source_study_id.unique()[0]
env = df.source_env.unique()[0]

# Get study details from path
path_item_list = import_file_path.split('/')
path_tgt_study = path_item_list[1]
path_src_study = path_item_list[2]
path_src_env = path_item_list[3]

if (int(study_count) > 1):
    print('Number of distinct studies from uploaded file: ', int(study_count))
    raise Exception("Multiple study ids/protocol numbers are present in the uploaded file")
elif (int(env_count) > 1):
    print('Number of distinct lifecycles from uploaded file: ', int(env_count))
    raise Exception("Multiple lifecycles are present in the uploaded file")
elif (study_id.upper() != src_study_id.upper()):
    print('Source Study from uploaded file: ', study_id)
    print('Source Study from parameter: ', src_study_id)
    raise Exception("Source Study id/Protocol number does not match the one in the uploaded file")
elif (env.upper() != src_env.upper()):
    print('Source Study Lifecycle from uploaded file: ', env)
    print('Source Study Lifecycle from parameter: ', src_env)
    raise Exception("Source Study Lifecycle does not match the one in the uploaded file")
elif (src_env.upper() != path_src_env.upper()):
    print('Source Study Lifecycle from uploaded file path: ', path_src_env)
    print('Source Study Lifecycle from parameter: ', src_env)
    raise Exception("Source Study Lifecycle does not match the one in the path of the uploaded file")
elif (src_study_id.upper() != path_src_study.upper()):
    print('Source Study from uploaded file path: ', path_src_study)
    print('Source Study from parameter: ', src_study_id)
    raise Exception("Source Study id/Protocol number does not match the one in the path of the uploaded file")
elif (tgt_study_id.upper() != path_tgt_study.upper()):
    print('Target Study from uploaded file path: ', path_tgt_study)
    print('Target Study from parameter: ', tgt_study_id)
    raise Exception("Target Study id/Protocol number does not match the one in the path of the uploaded file")

asset_count = df['display_id'].notnull().count()
print('No of assets selected for copying: ', asset_count)

if (asset_count < 1):
    raise Exception("No asset display id to be be copied exist in the the uploaded file")


# COMMAND ----------

# Build json parameter data from the uploaded data
param_value = json.dumps({
    'source_study': src_study_id,
    'source_study_lifecycle': src_env,
    'target_study': tgt_study_id,
    'import_file': import_file_path,
    'listing_ids': df[df["asset_type"] == "Listing"]['display_id'].tolist(),
    'visualization_ids': df[df["asset_type"] == "Visualization"]['display_id'].tolist(),
    'page_ids': df[df["asset_type"] == "Page"]['display_id'].tolist(),
    'pp_ids': df[df["asset_type"] == "Patient Profile"]['display_id'].tolist(),
    'rr_ids': df[df["asset_type"] == "Review Requirement"]['display_id'].tolist()
})
print('Parameter details: ', param_value)

# Call the copy_study_assets postgres function
connection = None
try:
    print('Connection to DB')
    connection = psycopg2.connect(user=dbMarvelUser,
                                    password=dbMarvelPwd,
                                    host=dbMarvelHost,
                                    port=dbMarvelPort,
                                    database=dbMarvelName)
    cursor = connection.cursor()
    # Query to fetch study listing records for a data source of a study
    studyListingQuery = f"""select res->>'return_status' as status, res->>'return_message' as message,
    res->'return_data' as error_data from dre.copy_study_assets('{param_value}'::jsonb, '{user_email}') res"""

    cursor.execute(studyListingQuery)
    print("Fetching study")
    records = cursor.fetchall()
    execution_status=records[0][0]
    # Process the result
    if records[0][0] == "SUCCESS":
        response = f'Copy assets completed successfully and copied all assets to the target study'
        print('Copy assets completed successfully.')
        print('Message from DB: ', records[0][1])
        connection.commit()
    elif records[0][0] == "WARNING":
        print('Copy assets completed with warning.')
        print('Message from DB: ', records[0][1])
        df = pd.DataFrame(records[0][2])
        display(df)
        failed_count = df['display_id'].notnull().count()
        response = f'Copy assets was not able to copy {failed_count} out of {asset_count} assets'
        connection.commit()
    else:
        execution_status="failed"
        response = f'Copy assets failed.'
        print('Copy assets failed')
        print('Message from DB: ', records[0][1])
    
except (psycopg2.Error) as error:
    print("Exception occurred when calling copy_study_assets function.")
    print("Error message from DB: ", error)
    response = f"Error: Copying of assets failed with exception {error}"
except (Exception) as error:
    print("Exception occurred when calling copy_study_assets function.")
    print("Exception message : ", error)
    response = f"Error: Copying of assets failed with exception {error}"
finally:
    # closing database connection.
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")


# COMMAND ----------

try:
    print('Audit log:Connection to DB')
    connection = psycopg2.connect(user=dbMarvelUser,
                                  password=dbMarvelPwd,
                                  host=dbMarvelHost,
                                  port=dbMarvelPort,
                                  database=dbMarvelName)
    cursor = connection.cursor()
    study_uuid_qry = f"""select asset_id, asset_version_id from dre.get_study_version_table('{tgt_study_id}', 'DEV')"""
    cursor.execute(study_uuid_qry)
    print("Fetching study uuid")
    records1 = cursor.fetchall()
    study_asset_uuid = records1[0][0]
    study_lifecycle_version_uuid = records1[0][1]
    fn_param_value = json.dumps({
        'status': execution_status,
    })
    audit_log_qry = f"""select * from dre.insert_audit_log('{study_asset_uuid}', '{study_lifecycle_version_uuid}', '{user_email}', 'Copy_Assets_Between_Studies', '{param_value}'::jsonb, '{fn_param_value}'::jsonb, '{response}')"""
    cursor.execute(audit_log_qry)
    connection.commit()
    cursor.close()
    connection.close()
except Exception as e:
    print("Exception message : ", e)
    raise e


# COMMAND ----------

# Return the response
dbutils.notebook.exit(response)
