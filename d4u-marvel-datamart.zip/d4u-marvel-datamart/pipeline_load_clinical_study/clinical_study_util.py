# Databricks notebook source
# MAGIC %run ../utils/audit_logger

# COMMAND ----------

import pandas as pd
import re
from pyspark.sql.functions import col,expr,when,lit,explode,count,row_number, regexp_replace
from pyspark.sql.types import ArrayType,StringType,StructField
from pyspark.sql.window import Window
import datetime
from datetime import datetime as dt
from pyspark.sql.functions import col, lit,current_timestamp
import boto3 
import zipfile 
from io import BytesIO 
import json 
import re 
import time
from delta.tables import *
from multiprocessing.pool import ThreadPool
from itertools import repeat
from pyspark.sql.functions import concat,lit,col,collect_list,concat_ws,md5,collect_set,array,to_json,create_map,array_agg
today=dt.today()
current_date=today.strftime("%Y%m%d")

# COMMAND ----------

def get_version_snapshot(catalog,study_id,temp_study_id):
    schema_tables = spark.sql(f"show tables in `{catalog}`.`{study_id}`")
    schema_tables = schema_tables.withColumn('database', regexp_replace(col('database'), '`', ''))
    schema_tables = schema_tables.filter((col("tableName").like("drm%"))|(col("tableName").like("relrec%"))|(col("tableName").like("sdtm%"))) 
    schema_tables = schema_tables.filter((~col("tableName").like("%whiteboard%")))
    tablecount = schema_tables.select("tableName").count()
    if(tablecount==0):
        print("new study")
    else:
        schema_table_query = schema_tables.withColumn("query",concat(lit(f"select '{catalog}' as catalog,'"),col("database"),lit("' as database ,'"),col("tableName"),lit("' as table "),lit(f",max(version) as stableversion from (describe history `{catalog}`.`"),col("database"),lit("`.`"),col("tableName"),lit("`)")))    
        sql_query_for_versions = " union all ".join(schema_table_query.select(collect_list("query").alias("querycollect")).collect()[0].querycollect)
        #print(sql_query_for_versions)
        versionstable = spark.sql(sql_query_for_versions) 
        print(f"`{catalog_marvel}`.default.`temp_table_restore_{catalog}_{temp_study_id}`")
        versionstable.write.mode("overwrite").format("delta").saveAsTable(f"`{catalog_marvel}`.default.`temp_table_restore_{catalog}_{temp_study_id}`")
        versionstable = spark.sql(f"select * from `{catalog_marvel}`.default.`temp_table_restore_{catalog}_{temp_study_id}`")
        return versionstable


# COMMAND ----------

def restore_tables(catalog,study_id,temp_study_id):
    df=spark.sql(f"show tables in `{catalog_marvel}`.default")
    if (df.selectExpr(f"any(tableName =='temp_table_restore_{catalog}_{temp_study_id}')").collect()[0][0]):
        versionstable = spark.sql(f"select * from `{catalog_marvel}`.default.`temp_table_restore_{catalog}_{temp_study_id}`")
        table_df = versionstable
        tables_restore = table_df.withColumn("restorequery",concat(lit(f"restore table  `{catalog}`.`"),col("database"),lit("`.`"),col("table"),lit("` to version as of "),col("stableversion")))
        sql_query_for_restore = tables_restore.select(collect_list("restorequery").alias("restorequerycollect")).collect()[0].restorequerycollect     
        [spark.sql(x) for x in sql_query_for_restore]
        logger.info('Restoring of Tables completed')
    else:
        pass

# COMMAND ----------

def drop_new_tables(catalog, study_id, temp_study_id):
    df=spark.sql(f"show tables in `{catalog_marvel}`.default")
    
    snapShotTableName = f"temp_table_restore_{catalog}_{temp_study_id}"

    if (df.selectExpr(f"any(tableName == '{snapShotTableName}')").collect()[0][0]):
        versionstable = spark.sql(f"select * from `{catalog_marvel}`.default.`{snapShotTableName}`")
#         print("exists")
        old_tables_df = versionstable
        new_schema_tables = spark.sql(f"show tables in `{catalog}`.`{study_id}`")
        new_schema_tables = new_schema_tables.withColumn('database', regexp_replace(col('database'), '`', ''))
        new_schema_tables = new_schema_tables.filter((col("tableName").like("drm%"))|(col("tableName").like("relrec%")))
        new_schema_tables = new_schema_tables.filter((~col("tableName").like("%whiteboard%")))
        new_schema_tables = new_schema_tables.filter("isTemporary == 'False'") 
        #old_tables_df.show(truncate= False)
        #new_schema_tables.show(truncate=False)
        new_schema_tables = new_schema_tables.select(col("database"),col("tableName").alias("table"))
        new_tables = new_schema_tables.subtract(old_tables_df.select(col("database"),col("table")))
        #new_tables.show(truncate=False)
        new_tables_drop_query = new_tables.withColumn("drop_query",concat(lit(f"drop table `{catalog}`.`"),col("database"),lit("`.`"),col("table"),lit("`")))
        sql_query_for_drop = new_tables_drop_query.select(collect_list("drop_query").alias("dropquerycollect")).collect()[0].dropquerycollect
        [spark.sql(x) for x in sql_query_for_drop]
    else:
        # DJM - 5/1/24 - JADF-23844 was flagged during GR2.0.0 testing.  Removed drop schema cascade.
        print(f"The snapshot table {snapShotTableName} does not exist.")
    

# COMMAND ----------

def handle_error(e,error_process,error_table):
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)           
    restore_tables(catalog_silver,study_id,temp_study_id)
    restore_tables(catalog_gold,study_id,temp_study_id)
    drop_new_tables(catalog_silver,study_id,temp_study_id)
    drop_new_tables(catalog_gold,study_id,temp_study_id)
    #spark.sql(f"drop table if exists `{catalog_marvel}`.default.`temp_table_restore_{catalog_silver}_{study_id}`")
    #spark.sql(f"drop table if exists `{catalog_marvel}`.default.`temp_table_restore_{catalog_gold}_{study_id}`")
    # send_email(job_name, "FAILED", error_msg)
    errant_tables = str(error_table)
    domainstats ={} 
    message = build_clinical_study_json(study_id, errant_tables, study_environment, job_id, run_id, load_timestamp,"", error_msg, domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
#     print(error_process)
#     print(error_table)
    raise e
    #dbutils.notebook.exit(error_msg)        

# COMMAND ----------

def build_column_datatype(name,dtype):
    if(str(dtype) == "date"):
        return f"to_date("+name+",'ddMMMyyyy') as "+name+" "
    elif(str(dtype) == "timestamp"):
        return "to_timestamp("+name+",'ddMMMyyyy:HH:mm:ss') as "+name+""
    elif(str(dtype) == "double"):
        return "double("+name+") as "+name+" "
    else:
        return str(name)


# COMMAND ----------

def ingest_domain_labels(data_frame, catalog_name, schema_name, table_name,domain_name,temp_study_id):
    
    query_top_record=f"SELECT * FROM `{catalog_name}`.`{schema_name}`.`{table_name}` WHERE domain='{domain_name}' LIMIT 1"
    df_top_rec=spark.sql(query_top_record)
    
    if (df_top_rec.count()==0):
        data_frame.createOrReplaceTempView(f"{temp_study_id}_{domain_name}_label_tempview")
        insertqry = f"INSERT INTO `{catalog_name}`.`{schema_name}`.`{table_name}` SELECT * FROM `{temp_study_id}_{domain_name}_label_tempview`"
        spark.sql(insertqry)

    else:
        data_frame.createOrReplaceTempView(f"{temp_study_id}_{domain_name}_label_tempview")
        latest_label_query=f"SELECT * FROM {temp_study_id}_{domain_name}_label_tempview ip LEFT ANTI JOIN  `{catalog_name}`.`{schema_name}`.`{table_name}` op ON ip.name=op.name AND ip.label=op.label and op.domain='{domain_name}'"
        df_final=spark.sql(latest_label_query)
        df_final.createOrReplaceTempView(f"{temp_study_id}_{domain_name}_newupdate_label_tempview")

        update_query=f"MERGE INTO `{catalog_name}`.`{schema_name}`.`{table_name}`  d USING {temp_study_id}_{domain_name}_newupdate_label_tempview as ip ON  d.name = ip.name AND d.domain=ip.domain WHEN MATCHED THEN UPDATE SET d.d4u_isactive=false"
        insert_query=f"INSERT INTO `{catalog_name}`.`{schema_name}`.`{table_name}` SELECT * FROM {temp_study_id}_{domain_name}_newupdate_label_tempview"
        execute_sql_with_retry(sql=update_query, log_try="Updating Labels Table")
        spark.sql(insert_query)


# COMMAND ----------

def ingest_domain_metadata(data_frame, catalog_name, domain_model, schema_name, domain,temp_study_id):

    df=spark.sql(f"show tables in `{catalog_name}`.`{schema_name}`")

    if (df.selectExpr(f"any(tableName =='{domain}_meta')").collect()[0][0]):
        data_frame.createOrReplaceTempView(f"{temp_study_id}_{domain}_metadata_tempview")
        latest_metadata_query=f"SELECT * FROM {temp_study_id}_{domain}_metadata_tempview ip LEFT ANTI JOIN `{catalog_name}`.`{schema_name}`.`{domain}_meta` op ON ip.name=op.name AND ip.label=op.label AND ip.type=op.type AND ip.length=op.length"
        df_meta_final=spark.sql(latest_metadata_query)
        df_meta_final=df_meta_final.withColumn("d4u_recverdate",current_timestamp()).withColumn("d4u_isactive",lit(True))
        latest_metadata_query_drop = f"SELECT * FROM  `{catalog_name}`.`{schema_name}`.`{domain}_meta` op LEFT ANTI JOIN  {temp_study_id}_{domain}_metadata_tempview ip ON ip.name=op.name AND ip.label=op.label AND ip.type=op.type AND ip.length=op.length                where op.d4u_isactive = True"
        df_meta_final_drop=spark.sql(latest_metadata_query_drop)
        df_meta_final_drop=df_meta_final_drop.withColumn("d4u_recverdate",current_timestamp()).withColumn("d4u_isactive",lit(False))
        # df_meta_final = df_meta_final.union(df_meta_final_drop)
        
#         display(df_meta_final)
        df_meta_final.createOrReplaceTempView(f"{temp_study_id}_{domain}_newupdate_meta_tmpview")
        df_meta_final_drop.createOrReplaceTempView(f"{temp_study_id}_{domain}_newupdate_meta_tmpview_drop")        
        updatequery = f"MERGE INTO `{catalog_name}`.`{schema_name}`.`{domain}_meta` d USING {temp_study_id}_{domain}_newupdate_meta_tmpview as ip ON  d.name = ip.name  WHEN MATCHED THEN UPDATE SET d.d4u_isactive=false"
        updatequerydrop = f"MERGE INTO `{catalog_name}`.`{schema_name}`.`{domain}_meta` d USING {temp_study_id}_{domain}_newupdate_meta_tmpview_drop as ip ON  d.name = ip.name  WHEN MATCHED THEN UPDATE SET d.d4u_isactive=false"

        insertquery = f"INSERT INTO `{catalog_name}`.`{schema_name}`.`{domain}_meta` SELECT * FROM {temp_study_id}_{domain}_newupdate_meta_tmpview"
        spark.sql(updatequery)
        spark.sql(updatequerydrop)
        spark.sql(insertquery)
        
    else:
        dataframe_meta=data_frame.withColumn("d4u_recverdate",current_timestamp()).withColumn("d4u_isactive",lit(True))
        dataframe_meta.write.mode("append").saveAsTable("`{0}`.`{1}`.{3}_meta".format(catalog_name, schema_name, domain_model, domain))


# COMMAND ----------

def modify_column_label(catalog_name, schema_name, domain_model, domain, column_name, data_type,label):
    table = f"`{catalog_name}`.`{schema_name}`.`{domain}`"
    spark.sql(f"ALTER TABLE {table} CHANGE `{column_name}` `{column_name}` {data_type} COMMENT \"{label}\"")

# COMMAND ----------

def modify_column_datatype(catalog_name, schema_name, domain_model, domain, column_name, data_type,label,old_type,batch_id):
    
    table = f"`{catalog_name}`.`{schema_name}`.`{domain}`"
    batch_name = batch_id.replace('-','_')    
    df = spark.read.table(f"{table}").withColumn(f"D4U_ARCHIVE_{column_name}_{batch_name}",col(f"{column_name}"))
    df = df.withColumn(f"{column_name}",col(f"{column_name}").cast(f"{data_type}"))
    df = df.select(df.columns[:-7]+df.columns[-1:]+df.columns[-7:-1])
    df.write.format("delta").mode("overwrite").option("overwriteSchema","true").saveAsTable(f"{table}") 
       
    spark.sql(f"ALTER TABLE {table} CHANGE `{column_name}` `{column_name}` {data_type} COMMENT \"{label}\"")
    if(old_type == "double" and data_type == "string"):
        spark.sql(f"""update {table} set {column_name} = rtrim('.',rtrim('0',cast(cast(cast( {column_name} as double) as decimal(27,7)) as string)))""")
        
    

# COMMAND ----------

def drop_column(catalog_name, schema_name, domain_model, domain, column_name,temp_study_id,batch_id):
    
    table = f"`{catalog_name}`.`{schema_name}`.`{domain}`"
    batch_name = batch_id.replace('-','_')
    df = spark.read.table(f"{table}").withColumn(f"D4U_ARCHIVE_{column_name}_{batch_name}",col(f"{column_name}"))
    new_col_list = df.columns
    new_col_list.remove(f"{column_name}")
    df = df.select(new_col_list[:-7]+new_col_list[-1:]+new_col_list[-7:-1])
    df.write.format("delta").mode("overwrite").option("overwriteSchema","true").saveAsTable(f"{table}")

# COMMAND ----------

def add_new_column(catalog_name, schema_name, domain_model, domain, column_name, data_type,label,temp_study_id):
    
    table = f"`{catalog_name}`.`{schema_name}`.`{domain}`"
    df_pos = spark.sql(f"SELECT varnum, label FROM {temp_study_id}_{domain}_metadata WHERE name = '{column_name}'")
    col_position = df_pos.select("varnum").collect()[0][0]
    prev_col_position = int(col_position) - 1
    new_col_label = df_pos.select("label").collect()[0][0]
    if (int(col_position) == 1):
        add_col_query = f"ALTER TABLE {table} ADD COLUMN {column_name} {data_type} comment \"{label}\" first"  
        spark.sql(add_col_query)
    elif int(prev_col_position) > 0:
        df_prev_col = spark.sql(f"SELECT name FROM `{temp_study_id}_{domain}_metadata` WHERE varnum = {prev_col_position}")
        prev_col_name = df_prev_col.collect()[0][0]
        add_col_query = f"ALTER TABLE {table} ADD COLUMN {column_name} {data_type} COMMENT \"{label}\" AFTER {prev_col_name}"
        spark.sql(add_col_query)

# COMMAND ----------

def build_pandas_df(zip_extractionpoint_path,meta_file,domain,non_clinical_domains):
    #print("build_pandas_df function is called...")
    meta_file_path = zip_extractionpoint_path + "/" + meta_file + ""
    print(f'build_pandas_df: {meta_file_path}')
    df = spark.read.option("header","true").option("delimiter",",").option("ignoreLeadingWhiteSpace","true").csv(meta_file_path)
    df = df.na.drop("all")
    # if domain in non_clinical_domains:
    #         non_clinical_colslist =["STUDYID","RDOMAIN","USUBJID","IDVAR","IDVARVAL","RELTYPE","RELID"]
    #         df = df.filter(df.name.isin(non_clinical_colslist))
    df = df.withColumn("finalformat",when(df.format.rlike("DATETIME[0-9\.]*"),lit("timestamp")).when(df.format.rlike("DATE[^TIME][0-9\.]*"),lit("date")).when(df.format.rlike("TIME[0-9\.]*"),lit("string")).otherwise(df.type))

    df_pandas = df.select("name","finalformat","label","notnull","varnum").toPandas()
    dict = {'name':['D4U_RECID','D4U_RECVER','D4U_DATAPROV','D4U_RECVERDATE','D4U_ISACTIVE','D4U_ISDROP'],
            'finalformat':['string','string','string','timestamp','boolean','boolean'],
            'label': ['DATA4YOU Unique Record Identifier','DATA4YOU Record Version Identifier','DATA4YOU Data Provenance object','DATA4YOU Record Insert Date','DATA4YOU Latest Record Version Flag','DATA4YOU Soft Delete Flag'],      
            'notnull':['yes','yes','yes','yes','yes','yes'],
            'varnum':['na','na','na','na','na','na']
     }
    # nc_dict = {'name':['HASH_VALUE','D4U_RECVERDATE','D4U_ISACTIVE','D4U_ISDROP'],
    #             'finalformat':['string','timestamp','boolean','boolean'],
    #             'label': ['HASH Key','Record Insert Date','Record Active Status','Record Drop Status'],      
    #             'notnull':['yes','yes','yes','yes'],
    #             'varnum':['na','na','na','na'] 
    #      }
    
    # if domain in non_clinical_domains:
    #     df_flags = pd.DataFrame(nc_dict)           
    # else:
    df_flags = pd.DataFrame(dict)
    df_pandas = pd.concat([df_pandas, df_flags], ignore_index = True)
    df_pandas.reset_index()
    df_pandas["finalformat"] = df_pandas["finalformat"].replace("char","string").replace("num","double")
    df_pandas["notnull"] = df_pandas["notnull"].replace("no","").replace("yes"," not null")
    df_pandas["finalqueryformat"] = df_pandas[["name","finalformat"]].apply(lambda x: build_column_datatype(*x),axis = 1)
    return df_pandas


# COMMAND ----------

# def update_audit_log(batch_id, job_status, error_msg):        
#     job_end_time = int(time.time())
#     job_end_timestamp = datetime.datetime.fromtimestamp(job_end_time).strftime('%Y-%m-%d %H:%M:%S')
#     audit_log_update_query = f"""UPDATE `{catalog_marvel}`.default.audit_log SET job_end_datetime = '{job_end_timestamp}', job_status = '{job_status}', error_msg = '{error_msg}' WHERE batch_id = '{batch_id}' and job_name = '{job_name}'"""
#     spark.sql(audit_log_update_query)
