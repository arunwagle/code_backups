# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

# domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_domains",default = "error", debugValue = "")
domains = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes_silver",key = "clinical_domains",default = "error", debugValue = "")
non_clinical_domains = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes_silver",key = "non_clinical_domains",default = "error", debugValue = "")
initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")
domain_comparison_log_file = dbutils.jobs.taskValues.get(taskKey = "domain_comparison", key = "domain_comparison_log_file", default = "", debugValue = "")
non_clinic_file = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes_silver",key = "non_clinic_file_name",default = "error", debugValue = "")
# config_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_dict",default = "error", debugValue = "")
config_domain_dict = dbutils.jobs.taskValues.get(taskKey  = "domain_comparison",key = "config_domain_dict",default = "error", debugValue = "")
config_dict = spark.sql(f"select * from `{catalog_marvel}`.`default`.`config_dict_table_{run_id}`")
config_dict = config_dict.select("*").toPandas()
config_dict = config_dict.set_index('table').to_dict('index')


# COMMAND ----------

def populate_silver_tables(domain, config_dict, study_domain_model, catalog_silver, study_schema_name, study_extraction_path, catalog_gold, non_clinical_domains,temp_study_id,config_domain_dict):
    try:        
        data_file = config_domain_dict[domain] + ".csv"
        domain_table_name = domain + ""
        meta_file = config_domain_dict[domain]+ "-meta.csv"
        query_top_record = "SELECT * FROM `%s`.`%s`.`%s` LIMIT 1" % (catalog_silver, study_schema_name, domain_table_name)
        df_top_record = spark.sql(query_top_record)        
        if (config_dict[f"{domain}"]):          
            composite_keys= config_dict[f"{domain}"]['RecIdKeys']
            RECVER_KEY = config_dict[f"{domain}"]['RecverKey']
        #Reading Full File
        inputdata = spark.read.option('header','true').option('delimiter',',').option("ignoreLeadingWhiteSpace","true").option('quote',None).option('escape','"').option('multiline',True).csv(study_extraction_path+'/'+data_file+'')
        inputdata.na.drop("all") 
        inputdata=inputdata.withColumn("D4U_RECID",lit(md5(concat_ws("||",*composite_keys)))).withColumn("D4U_RECVER",md5(concat_ws("||",*RECVER_KEY))).withColumn("D4U_DATAPROV",array(to_json(create_map(lit("table"),lit(domain_table_name),lit("D4U_RECID"),md5(concat_ws("||",*composite_keys)),lit("D4U_RECVER"),md5(concat_ws("||",*RECVER_KEY))))).cast("string"))   
        df_pandas = build_pandas_df(study_extraction_path,meta_file,domain,non_clinical_domains)
        querycolsstr = ",".join(df_pandas["finalqueryformat"])
        querycolsstr = querycolsstr.replace("to_timestamp(D4U_RECVERDATE,'ddMMMyyyy:HH:mm:ss')","timestamp(D4U_RECVERDATE)")
        
        colnamesstr = ",".join(df_pandas["name"])
        spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")
        spark.sql("SET spark.sql.ansi.enabled = False")
        # If no record exist in domain table, ingest full load data to table. If record exist, then load incremental data to table
        df_inputdata = inputdata.withColumn("D4U_RECVERDATE", lit(load_timestamp)).withColumn("D4U_ISACTIVE", lit(True)).withColumn("D4U_ISDROP", lit(False))
        df_inputdata = df_inputdata.dropDuplicates(["D4U_RECID"])
        
        
        silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{domain_table_name}`")).alias('silver')
        silver_records = silverTable.toDF().filter((col('D4U_ISACTIVE') == True) &(col('D4U_ISDROP') == False)).alias('silver')
        list_columns = silver_records.columns
        all_columns = silver_records.select(silver_records.colRegex("`^(D4U_ARCHIVE).*`")).schema.jsonValue()
        d1 = {x['name']: lit(0) for x in all_columns['fields'] if x['type'] == 'double'}
        d2 = {x['name']: lit(None) for x in all_columns['fields'] if x['type'] != 'double'}
        result = d1.copy()
        result.update(d2)
        df_inputdata = df_inputdata.withColumns(result)
        # DJM 3/15/24 Performance Tweak - df_inputdata.show()

        df_inputdata.createOrReplaceTempView(f"{study_environment}_{temp_study_id}_{domain}_full_data_tempview")        
        result_key = ','.join(result.keys())
        if(result_key != ''):
            querycolsstr =','.join([querycolsstr,result_key])
        else:
            pass
        # querycolsstr = querycolsstr[0:len(querycolsstr)]
               
        df = spark.sql(f"select {querycolsstr} from {study_environment}_{temp_study_id}_{domain}_full_data_tempview")
        
        df = df.select(list_columns)
        df_drop = silver_records.join(df.alias("df"),on = 'D4U_RECID',how = 'leftanti')
        df_drop = df_drop.withColumn("D4U_ISDROP",lit(True)).withColumn("D4U_RECVERDATE",lit(load_timestamp).cast('timestamp'))
        df_drop = df_drop.select(list_columns)

        logger.info(f'{domain}: {df_drop.count():,} records in to drop')

        df_insert = df.alias("df").join(silver_records,on = 'D4U_RECID',how = 'leftanti')
        df_insert = df_insert.select(list_columns)

        logger.info(f'{domain}: {df_insert.count():,} records in to insert')

        df_update = silver_records.join(df.alias("df"),expr(f"df.D4U_RECID = silver.D4U_RECID and df.D4U_RECVER != silver.D4U_RECVER"),how = 'inner').select(['df.*'])
        df_update = df_update.select(list_columns)

        logger.info(f'{domain}: {df_update.count():,} records in to update')

        df_insertupdate_drop = df_insert.union(df_update).union(df_drop)

        logger.info(f'{domain}: {silverTable.toDF().count():,} records in silver before merge')
        logger.info(f'{domain}: Merging { df_insertupdate_drop.count()} records into silver')
            
        
        df_insertupdate_drop= df_insertupdate_drop.select(list_columns)

        df_insertupdate_drop.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(f"`{catalog_marvel}`.`default`.`temp_{study_environment}_{temp_study_id}_{domain}`")

        df_insert_update_drop = spark.sql(f"select * from `{catalog_marvel}`.`default`.`temp_{study_environment}_{temp_study_id}_{domain}`")

        tic = time.perf_counter()

        if (silver_records.count() == 0):
            silverTable.alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()
        else:
            #set previous records as false for updated records
            silverTable.alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID') == col('silver.D4U_RECID')).whenMatchedUpdate(set = {"silver.D4U_ISACTIVE": lit(False)}).execute()      
            
            #insert all new and updated records
            silverTable.alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()
        
        toc = time.perf_counter()

        logger.info(f'{domain}: {silverTable.toDF().count():,} records in silver after merge')
        logger.info(f'Merge completed {toc - tic:0.4f} seconds')

        dropquery = spark.sql(f"drop table IF EXISTS `{catalog_marvel}`.`default`.`temp_{study_environment}_{temp_study_id}_{domain}`")
        

    except Exception as p:
        global error_process
        global error_table
        error_process = "ingest_study_data_silver"       
        error_table = f"{catalog_silver}.{study_schema_name}.{domain}"
        raise p



# COMMAND ----------

def nc_populate_silver_tables(domain,study_domain_model,catalog_silver,study_schema_name,study_extraction_path,non_clinical_domains,temp_study_id):
    try:  
        data_file = config_domain_dict[domain] + ".csv"
        domain_table_name = domain + ""
        meta_file = config_domain_dict[domain]+ "-meta.csv"
        query_top_record = "SELECT * FROM `%s`.`%s`.%s LIMIT 1" % (catalog_silver, study_schema_name, domain_table_name)
        df_top_record = spark.sql(query_top_record)        
        if (config_dict[f"{domain}"]):          
            composite_keys= config_dict[f"{domain}"]['RecIdKeys']
            RECVER_KEY = config_dict[f"{domain}"]['RecverKey']
        inputdata = spark.read.option('header','true').option('delimiter',',').option("ignoreLeadingWhiteSpace","true").option('quote',None).option('escape','"').option('multiline',True).csv(study_extraction_path+'/'+data_file+'')
        inputdata.na.drop("all")  
        inputdata=inputdata.withColumn("D4U_RECID",lit(md5(concat_ws("||",*composite_keys)))).withColumn("D4U_RECVER",md5(concat_ws("||",*RECVER_KEY))).withColumn("D4U_DATAPROV",array(to_json(create_map(lit("table"),lit(domain_table_name),lit("D4U_RECID"),md5(concat_ws("||",*composite_keys)),lit("D4U_RECVER"),md5(concat_ws("||",*RECVER_KEY))))).cast("string"))   
        df_pandas = build_pandas_df(study_extraction_path,meta_file,domain,non_clinical_domains)
        querycolsstr = ",".join(df_pandas["finalqueryformat"])
        querycolsstr = querycolsstr.replace("to_timestamp(D4U_RECVERDATE,'ddMMMyyyy:HH:mm:ss')","timestamp(D4U_RECVERDATE)")
        window_spec = Window.partitionBy("D4U_RECID")
        colnamesstr = ",".join(df_pandas["name"])
        spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")
        # If no record exist in domain table, ingest full load data to table. If record exist, then load incremental data to table
        df_inputdata = inputdata.withColumn("D4U_RECVERDATE", lit(load_timestamp)).withColumn("D4U_ISACTIVE", lit(True)).withColumn("D4U_ISDROP", lit(False))
        df_inputdata = df_inputdata.withColumn("GroupCount", count("D4U_RECID").over(window_spec))
        # df_inputdata = df_inputdata.dropDuplicates(["D4U_RECID"])
        df_inputdata.createOrReplaceTempView(f"{temp_study_id}_{study_environment}_{domain}_full_data_tempview")
        
        silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{domain_table_name}`")).alias('silver')
        silver_records = silverTable.toDF().filter((col('D4U_ISACTIVE') == True) &(col('D4U_ISDROP') == False)).alias('silver')
        list_columns = silver_records.columns
        list_columns = silver_records.columns
        all_columns = silver_records.select(silver_records.colRegex("`^(D4U_ARCHIVE).*`")).schema.jsonValue()
        d1 = {x['name']: lit(0) for x in all_columns['fields'] if x['type'] == 'double'}
        d2 = {x['name']: lit(None) for x in all_columns['fields'] if x['type'] != 'double'}
        result = d1.copy()
        result.update(d2)
        df_inputdata = df_inputdata.withColumns(result)
        df_inputdata.createOrReplaceTempView(f"{study_environment}_{temp_study_id}_{domain}_full_data_tempview")
        result_key = ','.join(result.keys())
        if(result_key != ''):
            querycolsstr =','.join([querycolsstr,result_key])
        else:
            pass
        df = spark.sql(f"select {querycolsstr} from {study_environment}_{temp_study_id}_{domain}_full_data_tempview")
        df = df.select(list_columns)
        df = df.withColumn("GroupCount", count("D4U_RECID").over(window_spec))
        silver_records = silver_records.withColumn("GroupCount", count("D4U_RECID").over(window_spec))
        
        df_drop = silver_records.alias("silver_records").join(df.alias("df"),((col('silver_records.D4U_RECID')==col('df.D4U_RECID'))&(col('silver_records.GroupCount')==col('df.GroupCount'))),how = 'leftanti')
        df_drop = df_drop.withColumn("D4U_ISDROP",lit(True)).withColumn("D4U_RECVERDATE",lit(load_timestamp).cast('timestamp'))
        df_drop = df_drop.select(list_columns)      
        df_insert = df.alias("df").join(silver_records.alias("silver_records"),((col('silver_records.D4U_RECID')==col('df.D4U_RECID'))&(col('silver_records.GroupCount')==col('df.GroupCount'))),how = 'leftanti')

        df_insert = df_insert.select(list_columns)     
        # df_update = silver_records.join(df.alias("df"),expr(f"df.D4U_RECID = silver.D4U_RECID and df.D4U_RECVER != silver.D4U_RECVER"),how = 'inner').select(['df.*'])
        # df_update = df_update.select(list_columns)
        df_insertupdate_drop = df_insert.union(df_drop)
        
        df_insertupdate_drop.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(f"`{catalog_marvel}`.`default`.`temp_{study_environment}_{temp_study_id}_{domain}`")

        df_insert_update_drop = spark.sql(f"select * from `{catalog_marvel}`.`default`.`temp_{study_environment}_{temp_study_id}_{domain}`")
        df_column  = spark.sql(f"select distinct(d4u_recid) from `{catalog_marvel}`.`default`.`temp_{study_environment}_{temp_study_id}_{domain}`")
        id_list = [row[0] for row in df_column.collect()]

        if (silver_records.count() == 0):
            silverTable.alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()
        else:   
            #set previous records as false for updated records
            silverTable.alias("silver").update(condition = col('silver.D4U_RECID').isin(id_list),set = { "silver.D4U_ISACTIVE": lit(False) })    
            

            #insert all new and updated records
            silverTable.alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()
            
        dropquery = spark.sql(f"drop table IF EXISTS `{catalog_marvel}`.`default`.`temp_{study_environment}_{temp_study_id}_{domain}`")
        
    except Exception as p:
        global error_process
        global error_table
        error_process = "ingest_study_data_silver"       
        error_table = f"{catalog_silver}.{study_schema_name}.{domain}"
        raise p

# COMMAND ----------

try:
    logger.info("Silver Layer Tables Insertion Started")
    study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
    parallel_runs = ThreadPool(thread_count)
    parallel_runs.starmap(populate_silver_tables,
                          zip(domains,
                              repeat(config_dict),
                              repeat(study_domain_model), 
                              repeat(catalog_silver), 
                              repeat(study_schema_name), 
                              repeat(study_extraction_path), 
                              repeat(catalog_gold), 
                              repeat(non_clinical_domains),
                              repeat(temp_study_id),
                              repeat(config_domain_dict)))
    logger.info("Silver Layer Tables Insertion Completed")
except Exception as e:
        logger.error("Silver Layer Tables Insertion Failed")
        logger.error(e)
        log_file_data=read_log_file(p_filename)      
        write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,
                      metadata_log_file,log_file_data,"","","",log_file)
        handle_error(e, error_process, error_table)

# COMMAND ----------

try:
    if len(non_clinical_domains) > 0:
        logger.info("Non Clinical Domains Tables insertion started at  Silver Layer")
        study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
        parallel_runs = ThreadPool(4)
        parallel_runs.starmap(nc_populate_silver_tables,
                              zip(non_clinical_domains,
                                  repeat(study_domain_model),                                                                                        repeat(catalog_silver),
                                  repeat(study_schema_name),
                                  repeat(study_extraction_path),
                                  repeat(non_clinical_domains),
                                  repeat(temp_study_id)))
except Exception as e:
        logger.error("Non Clinical Domains Tables insertion Failed at  Silver Layer")
        logger.error(e)
        log_file_data=read_log_file(p_filename)      
        write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,metadata_log_file
                 ,log_file_data,"","","",log_file)
        handle_error(e,error_process,error_table)

# COMMAND ----------

try:
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "ingest_silver_log_file", value = log_file_data)
    spark.sql(f"drop table IF EXISTS `{catalog_marvel}`.`default`.`config_dict_table_{run_id}`")
except Exception as e:
    raise e
