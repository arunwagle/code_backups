# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

non_clinical_domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "non_clinical_domains",default = "error", debugValue = "")
initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")
ingest_silver_log_file = dbutils.jobs.taskValues.get(taskKey = "ingest_study_data_silver", key = "ingest_silver_log_file", default = "", debugValue = "")
non_clinic_file = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "non_clinic_file_name",default = "error", debugValue = "")


# COMMAND ----------

# DBTITLE 1,Notify function for duplicates in the initial and cumulative load
def notify (load_type, duplicate_df):
    study_folder=f"{study_id}_{current_date}/{load_type}"
    dbutils.fs.mkdirs(study_folder)
    s3_path = f"{s3_mountpoint}/{domain_data_path}/{study_folder}"
    duplicate_df = duplicate_df.drop("HASH_VALUE","D4U_RECVERDATE","D4U_ISACTIVE","D4U_ISDROP")
    duplicate_df.coalesce(1).write.mode("append").options(header='True',delimiter=',').csv(s3_path)
    aws_s3_path = f"s3://{s3_bucket_name}/{domain_data_path}/{study_folder}"
    msg = f"S3 folder containing non_clinical discrepancy records - {aws_s3_path}"
    logger.warning(msg)
    errant_tables = "N/A"
    domainstats={}
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",msg,domainstats)
    send_notification(study_id,study_environment,"Warning",admin_user_recipients,message,vpc_name,"NA","","","","")
    

# COMMAND ----------

# DBTITLE 1,Non_clinical domain silver layer process
def nc_populate_silver_tables(nc_domain,study_domain_model,catalog_silver,study_schema_name,study_extraction_path,non_clinical_domains,temp_study_id):
    try:  
        if non_clinic_file == nc_domain:
            nc_data_file = nc_domain + ".csv"
            nc_meta_file = nc_domain + "-meta.csv"
        else:
            nc_data_file = study_domain_model + "_" + nc_domain + ".csv"
            nc_meta_file = study_domain_model + "_" + nc_domain + "-meta.csv"
            
        non_clinical_table = study_domain_model + "_" + nc_domain + ""
        query_top_record = "SELECT * FROM `%s`.`%s`.`%s` LIMIT 1" % (catalog_silver, study_schema_name, non_clinical_table)
        nc_top_record = spark.sql(query_top_record)
        non_clinical_data = spark.read.option("header","true").option("delimiter",",").option("ignoreLeadingWhiteSpace","true").csv(study_extraction_path+"/"+ nc_data_file+"")
        non_clinical_data.na.drop("all")        
        nc_cols_list =["STUDYID","RDOMAIN","USUBJID","IDVAR","IDVARVAL","RELTYPE","RELID"]
        non_cli_dom_cols = nc_cols_list 
        non_clinical_data = non_clinical_data.select(non_cli_dom_cols)
        nc_df_pandas = build_pandas_df(study_extraction_path, nc_meta_file,nc_domain,non_clinical_domains)
        querycolsstr = ",".join(nc_df_pandas["finalqueryformat"])
        querycolsstr = querycolsstr.replace("to_timestamp(D4U_RECVERDATE,'ddMMMyyyy:HH:mm:ss')","timestamp(D4U_RECVERDATE)")
        colnamesstr = ",".join(nc_df_pandas["name"])              
        spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")
        #global variable for metric capture
        global drop_row_count
        global new_records_count
        global updated_row_count
        # If no record exist in domain table, ingest full load data to table. If record exist, then load cumulative data to table
        if (nc_top_record.count() == 0):
            nc_inputdata = non_clinical_data.withColumn("HASH_VALUE",lit(md5(concat_ws("||",*non_cli_dom_cols)))).withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp')).withColumn("D4U_ISACTIVE", lit(True)).withColumn("D4U_ISDROP", lit(False))
            nc_inputdata.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_nc_tempview")        
            
            # Check duplicats in the initial load and notify user
            initial_dup_df = nc_inputdata.groupBy("HASH_VALUE").count().filter(col("count") > 1)
            initial_duprec_df =  nc_inputdata.join( initial_dup_df, nc_inputdata.HASH_VALUE ==  initial_dup_df.HASH_VALUE, "left_semi")
            #setting metric values for relrec
            drop_row_count = "n/a"
            # DJM 3/15/24 Remove debug code - print("if part")
            print(f"drop_row_count: {drop_row_count}")
            new_records_count = nc_inputdata.count()
            updated_row_count = "n/a"
            
            dbutils.jobs.taskValues.set(key   = "drop_records_count",value = drop_row_count)
            dbutils.jobs.taskValues.set(key   = "new_records_count",value = new_records_count)
            dbutils.jobs.taskValues.set(key   = "updated_records_count",value = updated_row_count)
            if initial_duprec_df.count()!=0:                 
                notify ("Initial_Load",initial_duprec_df)        
            nc_full_load_query = f"INSERT INTO `{catalog_silver}`.`{study_schema_name}`.{non_clinical_table}({colnamesstr}) SELECT {querycolsstr} FROM {temp_study_id}_{nc_domain}_nc_tempview"
            spark.sql(nc_full_load_query) 
        else :
            # Ingesting cumulative load for non_clinical domain and querying silver layer 
            incr_inputdata = non_clinical_data.withColumn("HASH_VALUE",lit(md5(concat_ws("||",*non_cli_dom_cols)))).withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp')).withColumn("D4U_ISACTIVE", lit(True)).withColumn("D4U_ISDROP", lit(False))
            incr_inputdata.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_incr_tempview") 
    
            # scenario 1 
            # Identify new records in incoming non-duplicate file for cumulative load 
            nc_new_record = spark.sql (f"select u.HASH_VALUE, count(*) from `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` as s right join {temp_study_id}_{nc_domain}_incr_tempview u on s.HASH_VALUE = u.HASH_VALUE where s.HASH_VALUE IS NULL group by u.HASH_VALUE having count(u.HASH_VALUE) = 1")
            nc_new_record.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_nc_newrecord")
            # New record query
            insert_newrecords = spark.sql(f"select u.* from {temp_study_id}_{nc_domain}_incr_tempview as u inner join {temp_study_id}_{nc_domain}_nc_newrecord as n on u.HASH_VALUE = n.HASH_VALUE")
            #capture for insert
            new_records_count = insert_newrecords.count()
            insert_newrecords.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_new")
            # scenario 2 Records existing in silver layer and in cumulative load are untouched  

            # scenario 3
            # Identifying drop recodrs in cumulative load
            nc_drop_df = spark.sql(f"select * from `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` where D4U_ISACTIVE=True and D4U_ISDROP = False")
            nc_drop_df = nc_drop_df.drop("D4U_RECVERDATE", "D4U_ISACTIVE", "D4U_ISDROP")
            drop_records = spark.sql(f"select HASH_VALUE from (select op.HASH_VALUE as HASH_VALUE, ip.HASH_VALUE as input_HASH_VALUE from `{catalog_silver}`.`{study_schema_name}`.{non_clinical_table} as op left join {temp_study_id}_{nc_domain}_incr_tempview ip on  op.HASH_VALUE = ip.HASH_VALUE)src where src.input_HASH_VALUE IS NULL")
            drop_df = drop_records.join(nc_drop_df,["HASH_VALUE"], how="inner").distinct()
            drop_hash_list = [row[0] for row in drop_df.select("HASH_VALUE").collect()]
            # list of dropped hash values
            drop_hash = str(drop_hash_list)
            drop_hash=drop_hash.replace("[","").replace("]","")
            col_list = drop_df.columns
            nc_col_list = col_list[1:]+ col_list[:1]
            drop_df = drop_df.select(nc_col_list).withColumn("D4U_RECVERDATE",lit(load_timestamp).cast('timestamp')). \
                      withColumn("D4U_ISACTIVE",lit(True)).withColumn("D4U_ISDROP",lit(True))
            drop_df.write.mode("overwrite").format("delta").saveAsTable(f"`{catalog_marvel}`.`default`.`{temp_study_id}_nc_drop_temp`")
            drop_row_count = drop_df.count()
            if len(drop_hash)!=0:
                drop_hashquery = f"update `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` set D4U_ISACTIVE = false where HASH_VALUE in ({drop_hash})"
                spark.sql(drop_hashquery)     
        
            #scenario 4
            dup_df = spark.sql(f"select u.HASH_VALUE, count(*) from `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` as s right join {temp_study_id}_{nc_domain}_incr_tempview u on s.HASH_VALUE = u.HASH_VALUE where s.HASH_VALUE IS NULL group by u.HASH_VALUE having count(u.HASH_VALUE) > 1")
            dup_df.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_dup_tempview")       
            duplicate_records_df = spark.sql(f"select u. * from {temp_study_id}_{nc_domain}_incr_tempview as u inner join {temp_study_id}_{nc_domain}_dup_tempview as d on u.HASH_VALUE = d.HASH_VALUE") 
            duplicate_records_df.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_duplicate")
            distint_hashval_count = duplicate_records_df.select("HASH_VALUE").distinct().count()
            new_records_count = new_records_count + distint_hashval_count
            # write duplicate records to csv and save on s3 , send notification to admin group
            if duplicate_records_df.count()!=0:                 
                notify ("Cumulative_Load",duplicate_records_df)      
    
            # scenario 5
            # Identify duplicates in silver layer and incoming file
            resolve_df = spark.sql (f"select HASH_VALUE, count(*) from `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` group by HASH_VALUE having count(HASH_VALUE) >1")
            resolve_incr_df = spark.sql(f"select HASH_VALUE, count(*) from `{temp_study_id}_{nc_domain}_incr_tempview` group by HASH_VALUE having count(HASH_VALUE) = 1")
            # Duplicates in silver layer and matching single record in incoming file
            resolve_dup_df = resolve_incr_df.join(resolve_df,["HASH_VALUE"], how="inner").drop("count(1)")        
            resolve_dup_df.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_resolve")
            resolve_final_df  = spark.sql(f"select u.* from `{temp_study_id}_{nc_domain}_incr_tempview` as u inner join `{temp_study_id}_{nc_domain}_resolve` as t on u.HASH_VALUE = t.HASH_VALUE")
            resolve_final_df.createOrReplaceTempView(f"{temp_study_id}_{nc_domain}_resolve_final")
            #capture for metric
            updated_row_count = resolve_final_df.count()

            # Insertions and updation to the silver table for all the scenarios
            # Inserting new records to silver table
            spark.sql(f"insert into `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` select {querycolsstr} from `{temp_study_id}_{nc_domain}_new`")
            # Insert dropped records to silver layer
            spark.sql(f"insert into `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` select {querycolsstr} from `{catalog_marvel}`.`default`.`{temp_study_id}_nc_drop_temp`")
            spark.sql(f"drop table if exists `{catalog_marvel}`.`default`.`{temp_study_id}_nc_drop_temp`")
    
            # Inserting duplicate HASH in incoming file which are not in silver layer  
            spark.sql(f"insert into `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` select {querycolsstr} from `{temp_study_id}_{nc_domain}_duplicate`")
    
            # Duplicate HASH in silver and matching single HASH in incoming file                                                                
            spark.sql(f"merge into`{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}`  as s using {temp_study_id}_{nc_domain}_resolve_final as t on s.HASH_VALUE = t.HASH_VALUE when matched then update set s.D4U_ISDROP = True, s.D4U_ISACTIVE = False")
            spark.sql(f"insert into `{catalog_silver}`.`{study_schema_name}`.`{non_clinical_table}` select {querycolsstr} from `{temp_study_id}_{nc_domain}_resolve_final`")
            dbutils.jobs.taskValues.set(key   = "drop_records_count",value = drop_row_count)
            dbutils.jobs.taskValues.set(key   = "new_records_count",value = new_records_count)
            dbutils.jobs.taskValues.set(key   = "updated_records_count",value = updated_row_count)
            
    except Exception as p:
        global nc_error_process
        global nc_error_table
        nc_error_process = "ingest_study_data_silver_non_clinical"       
        nc_error_table = f"{catalog_silver}.{study_schema_name}.{study_domain_model}_{nc_domain}"
        raise p


# COMMAND ----------

try:
    if len(non_clinical_domains) > 0:
        logger.info("Non Clinical Domains Tables insertion started at  Silver Layer")
        study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
        parallel_runs = ThreadPool(4)
        parallel_runs.starmap(nc_populate_silver_tables,zip(non_clinical_domains,repeat(study_domain_model),                                                                                            repeat(catalog_silver),repeat(study_schema_name),repeat(study_extraction_path),repeat(non_clinical_domains),repeat(temp_study_id)))
except Exception as e:
        logger.error("Non Clinical Domains Tables insertion Failed at  Silver Layer")
        logger.error(e)
        log_file_data=read_log_file(p_filename)      
        write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,metadata_log_file
        ,ingest_silver_log_file,log_file_data,"","","",log_file)
        handle_error(e,nc_error_process,nc_error_table)

# COMMAND ----------

# DBTITLE 1,non_clinical gold layer process
def nc_populate_gold_tables(nc_domain,study_domain_model,study_schema_name,catalog_silver,catalog_gold):
    try:
        nc_domain_table_name = study_domain_model + "_" + nc_domain + ""     
        nc_metadata_domain_table = study_domain_model + "_" + nc_domain + "_meta" 
        latest_records_query = "SELECT DISTINCT HASH_VALUE, * FROM `{0}`.`{1}`.`{2}` where D4U_ISACTIVE = True AND D4U_ISDROP = False".format(catalog_silver, study_schema_name, nc_domain_table_name)
        latest_metadata_query = "SELECT * FROM `{0}`.`{1}`.`{2}` where d4u_isactive = True".format(catalog_silver, study_schema_name, nc_metadata_domain_table)
        df_meta = spark.sql(latest_metadata_query)
        df_meta = df_meta.drop("D4U_RECVERDATE","d4u_isactive")
        df = spark.sql(latest_records_query)
        #query = "DROP TABLE IF EXISTS `{0}`.`{1}`.{2}".format(catalog_gold, study_schema_name, nc_domain_table_name)
        #spark.sql(query)
        nc_df = df.drop("HASH_VALUE","D4U_RECVERDATE","D4U_ISACTIVE","D4U_ISDROP")
        df_meta.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable("`" + catalog_gold + "`.`" + study_schema_name + "`." + nc_metadata_domain_table)
        nc_df.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable("`" + catalog_gold + "`.`" + study_schema_name + "`." + nc_domain_table_name)    
    except Exception as p:
        global nc_error_process
        global nc_error_table
        nc_error_process = "ingest_study_data_gold_non_clinical"       
        nc_error_table = f"{catalog_gold}.{study_schema_name}.{study_domain_model}_{nc_domain}"
        raise p        

# COMMAND ----------

try:
    logger.info("Non Clinical Domains Tables insertion started at Gold Layer")
    if len(non_clinical_domains) > 0:
        parallel_exec = ThreadPool(4)
        parallel_exec.starmap(nc_populate_gold_tables,zip(non_clinical_domains,repeat(study_domain_model),
                                                   repeat(study_schema_name),repeat(catalog_silver),repeat(catalog_gold)))
except Exception as e:
        logger.error("Non Clinical Domains Tables insertion Failed at  Gold Layer")
        logger.error(e)
        log_file_data=read_log_file(p_filename)      
        write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,metadata_log_file
        ,ingest_silver_log_file,log_file_data,"","","",log_file)
        handle_error(e,nc_error_process,nc_error_table)

# COMMAND ----------

try:
    logger.info("Processing of Non Clinical Domains Completed")
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "nonclinicdom_log_file", value = log_file_data)
except Exception as e:
    raise e
