# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

# domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_domains",default = "error", debugValue = "")
domains = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes_silver",key = "clinical_domains",default = "error", debugValue = "")
non_clinical_domains = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes_silver",key = "non_clinical_domains",default = "error", debugValue = "")
initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")
ingest_silver_log_file = dbutils.jobs.taskValues.get(taskKey = "ingest_study_data_silver", key = "ingest_silver_log_file", default = "", debugValue = "")
domain_comparison_log_file = dbutils.jobs.taskValues.get(taskKey = "domain_comparison", key = "domain_comparison_log_file", default = "", debugValue = "")
nonclinicdom_log_file = ""

# COMMAND ----------

domains = domains + non_clinical_domains

# COMMAND ----------

try:
    logger.info("Gold Layer Domain Lables Table Insertion Started")
    label_table_name =  study_domain_model + "_labels"
    #spark.sql("DROP TABLE IF EXISTS `" + catalog_gold + "`." + study_schema_name + "." + study_domain_model + "_labels")
    latest_label_query="SELECT * FROM `{0}`.`{1}`.`{2}` WHERE d4u_isactive = True AND d4u_isdrop = False".format(catalog_silver, study_schema_name,label_table_name)
    df_labels=spark.sql(latest_label_query)
    df_labels=df_labels.drop("d4u_isactive","d4u_isdrop") 
    df_labels.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"`{catalog_gold}`.`{study_schema_name}`.`{study_domain_model}_labels`")
    logger.info("Gold Layer Domain Lables Table Insertion Completed")
except Exception as e:
    error_process = "populate_domain_labels"       
    error_table = f"{catalog_gold}.{study_schema_name}.{study_domain_model}_{domain}"
    logger.error("Gold Layer Domain Lables Table Insertion Failed")
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,metadata_log_file,
    ingest_silver_log_file,log_file_data,"","",log_file)
    handle_error(e,error_process,error_table)

# COMMAND ----------

def populate_gold_tables(domain,study_domain_model,study_schema_name,catalog_silver,catalog_gold):
    try:
        domain_table_name = domain + ""     
        metadata_domain_table_name = domain + "_meta" 
        latest_records_query="SELECT * FROM `{0}`.`{1}`.`{2}` where D4U_ISACTIVE = True AND D4U_ISDROP = False".format(catalog_silver, study_schema_name, domain_table_name)
        latest_metadata_query="SELECT * FROM `{0}`.`{1}`.`{2}` where d4u_isactive = True".format(catalog_silver, study_schema_name, metadata_domain_table_name)
        df_meta=spark.sql(latest_metadata_query)
        df_meta=df_meta.drop("d4u_recverdate","d4u_isactive")
        df=spark.sql(latest_records_query)
        #query = "DROP TABLE IF EXISTS `{0}`.{1}.{2}".format(catalog_gold, study_schema_name, domain_table_name)
        #spark.sql(query)
        df=df.drop("D4U_ISACTIVE","D4U_ISDROP")
        df = df.select(df.colRegex("`^(?!D4U_ARCHIVE).*`"))
        df = df.dropDuplicates(["D4U_RECID"])
        df_meta.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(f"`{catalog_gold}`.`{study_schema_name}`.`{metadata_domain_table_name}`")
        df.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(f"`{catalog_gold}`.`{study_schema_name}`.`{domain_table_name}`")
        gold_df_count = df.count()
        print(f"Gold Count:{gold_df_count}")
        if (df.count()==0):
            error_msg =f"All records in {domain_table_name} table has been dropped."
            errant_tables = "N/A"
            domainstats={}
            message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
            send_notification(study_id,study_environment,"Warning",admin_user_recipients,message,vpc_name,"NA","","","","")
        
        
    except Exception as p:
        global error_process
        global error_table
        error_process = "overwrite_domain_tables_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{study_domain_model}_{domain}"
        raise p
  

# COMMAND ----------

try:
    logger.info("Gold Layer Tables Insertion Started")
    parallel_exec = ThreadPool(thread_count)
    parallel_exec.starmap(populate_gold_tables,zip(domains,repeat(study_domain_model),repeat(study_schema_name),repeat(catalog_silver),repeat(catalog_gold)))
    logger.info("Inserting records into Gold Layer Tables completed")
except Exception as e:
        logger.error("Gold Layer Tables Insertion Failed")
        logger.error(e)
        log_file_data=read_log_file(p_filename)      
        write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,metadata_log_file,
               ingest_silver_log_file,log_file_data,"","",log_file)
        handle_error(e,error_process,error_table)

# COMMAND ----------

try:
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "overwrite_gold_log_file", value = log_file_data)
except Exception as e:
    raise e

