# Databricks notebook source
from pyspark.sql.functions import * 
import pandas as pd

# COMMAND ----------

pipeline_environment = dbutils.widgets.get("pipeline_environment")
study_id = dbutils.widgets.get("study_id")
environment = dbutils.widgets.get("environment")
batch_id = dbutils.widgets.get("batchId")
job_id = dbutils.widgets.get("job_id")
run_id = dbutils.widgets.get("run_id")
data_model = dbutils.widgets.get("data_model").upper()
catalog_silver = f"marvel-{environment}-silver"
catalog_gold = f"marvel-{environment}-gold"



# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

try:
    df_src = spark.sql("select * from `marvel`.default.`study_filter_config_datamart`")
    df_src =df_src.filter(df_src["Data_model"] == data_model)

    src_table = df_src.collect()[0][2].lower()
    print(src_table)
    config_dict ={}
    for row in df_src.collect():
        target_column = row["Filter_name"]
        source_column = row["Source_Column"]
        config_dict[target_column] = source_column
    print(config_dict)
    df_src = df_src.withColumn("Data_Type",lit("string")).withColumn("notnull",lit("no"))#.withColumnRenamed("Filter_name","comment")
    df_src = df_src.select("Filter_name","Data_Type","notnull")
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    raise e
    

# COMMAND ----------

try:
    df=spark.sql(f"select * from `{catalog_gold}`.`{study_id}`.`{src_table}` limit 1")
    drm_dm_collist=df.columns
    src_column_list = []    
    for key in config_dict:
        src_column_list.append(config_dict[key])
    allcol_exists=all(x in src_column_list for x in drm_dm_collist)
    query_colstr = ""
    if allcol_exists:       
        for key in config_dict:    
            query_colstr += config_dict[key] + " AS " + key + ","    
    else:    
        for key in config_dict:
            for i in src_column_list:
                if not i in drm_dm_collist:
                    if config_dict[key] == i:
                        query_colstr += 'null' + " AS " + key + ","
                else:
                    if config_dict[key] == i:
                        query_colstr +=  config_dict[key] + " AS " + key + ","
    query_colstr = query_colstr[0:(len(query_colstr)-1)]
    print(query_colstr)
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    raise e

# COMMAND ----------

try:
    def tableExists(catalog_name,study_schema_name,table_name):
        return spark.sql(f'show tables in `{catalog_name}`.`{study_schema_name}`').selectExpr(f"any(tableName =='{table_name}')").collect()[0][0]
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    raise e 

# COMMAND ----------

try:
    df_pandas = df_src.toPandas()
    df_pandas["notnull"] = df_pandas["notnull"].replace("no","").replace("yes"," not null")
    column_array = df_pandas.values
    querystr = ""
    for i in range(0,len(column_array)):
        querystr = querystr + str(column_array[i][0]) + " " + str(column_array[i][1]) + str(column_array[i][2]) + ","
    querystr = querystr[0:len(querystr)-1]
    if tableExists(catalog_gold,study_id,src_table):
        query = f"CREATE TABLE IF NOT EXISTS `{catalog_gold}`.`{study_id}`.`{data_model}_whiteboard_filter_table` ({querystr})"
        spark.sql(query)
        query_1 = f"select * from `{catalog_gold}`.`{study_id}`.`{data_model}_whiteboard_filter_table` limit 1"
        df_schema = spark.sql(query_1)
        df_schema = df_schema.withColumn("SUBJID", df_schema["SUBJID"].cast(StringType()))
        df_schema = df_schema.withColumn("SITEID", df_schema["SITEID"].cast(StringType()))
        schema = df_schema.columns
        df_data = spark.sql(f"SELECT  {query_colstr}  from `{catalog_gold}`.`{study_id}`.`{src_table}`")
        df_data = df_data.withColumn("SUBJID", df_data["SUBJID"].cast(StringType()))
        df_data = df_data.withColumn("SITEID", df_data["SITEID"].cast(StringType()))
        df_data = df_data.select(schema)
        df_data.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(f"`{catalog_gold}`.`{study_id}`.`{data_model}_whiteboard_filter_table`")
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    raise e


# COMMAND ----------

try:
    job_status = "SUCCESS"
    # Update audit log
    update_audit_log(batch_id, job_id, run_id, study_id, environment, job_status, "Load Whiteboard Filter Job has been executed successfully")
except Exception as e:
    raise e
