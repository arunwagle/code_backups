# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_domains",default = "error", debugValue = "")
initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")


# COMMAND ----------

try:
    logger.info("Creation of Lables Table if not Exists")
    spark.sql("CREATE TABLE IF NOT EXISTS `" + catalog_silver + "`.`" + study_schema_name + "`.`" + study_domain_model + "_labels` \
    ( \
    studyid string, \
    domain_model string, \
    domain string, \
    name string, \
    label string, \
    load_date string, \
    d4u_isactive boolean, \
    d4u_isdrop boolean \
    )")
    
except Exception as e:    
    error_process = "populate_domain_labels"       
    error_table = f"{catalog_silver}.{study_schema_name}.{study_domain_model}_{domain}"
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,"",log_file_data,"","","","",log_file)
    handle_error(e,error_process,error_table)

# COMMAND ----------

logger.info("Silver Layer Domain Lables Table Insertion Started")
for domain in domains:
    try:
        meta_file = study_domain_model + "_" + domain + "-meta.csv"
        print(f"Meta File: {meta_file}")
        labels_table_name = study_domain_model + "_labels"
        study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
        df = spark.read.option("header","true").option("delimiter",",").option("ignoreLeadingWhiteSpace","true").csv(study_extraction_path + "/" + meta_file + "")
        df = df.na.drop("all") 
        df_labels = df.select("name","label")
        df_labels = df_labels.withColumn("domain",lit(domain)) \
                  .withColumn("study_id",lit(study_id)) \
                  .withColumn("domain_model",lit(study_domain_model)) \
                  .withColumn("load_date",current_timestamp()) \
                  .withColumn("d4u_isactive",lit(True)) \
                  .withColumn("d4u_isdropped",lit(False))
        df_labels = df_labels.select("study_id","domain_model","domain","name","label","load_date","d4u_isactive","d4u_isdrop")
        ingest_domain_labels(df_labels, catalog_silver, study_schema_name, labels_table_name, domain,temp_study_id)
    except Exception as e:
        error_process = "populate_domain_labels"       
        error_table = f"{catalog_silver}.{study_schema_name}.{study_domain_model}_{domain}" 
        logger.error("Silver Layer Domain Table Insertion Failed")
        logger.error(e)
        log_file_data=read_log_file(p_filename)      
        write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,"",
        log_file_data,"","","","",log_file)
        handle_error(e,error_process,error_table)
logger.info("Silver Layer Domain Lables Table Insertion Completed")

# COMMAND ----------

#populating study_lable table in Gold Layer
try:
    logger.info("Gold Layer Domain Lables Table Insertion Started")
    label_table_name =  study_domain_model + "_labels"
    #spark.sql("DROP TABLE IF EXISTS `" + catalog_gold + "`." + study_schema_name + "." + study_domain_model + "_labels")
    latest_label_query="SELECT * FROM `{0}`.`{1}`.`{2}` WHERE is_active = True AND is_dropped = False".format(catalog_silver, study_schema_name,label_table_name)
    df_labels=spark.sql(latest_label_query)
    df_labels=df_labels.drop("load_date","d4u_isactive","d4u_isdrop") 
    df_labels.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"`{catalog_gold}`.`{study_schema_name}`.`{study_domain_model}_labels`")
    logger.info("Gold Layer Domain Lables Table Insertion Completed")
except Exception as e:
    error_process = "populate_domain_labels"       
    error_table = f"{catalog_gold}.{study_schema_name}.{study_domain_model}_{domain}"
    logger.error("Gold Layer Domain Lables Table Insertion Failed")
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,"",log_file_data,"","","","",log_file)
    handle_error(e,error_process,error_table)

# COMMAND ----------

try:
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "domain_lable_log_file", value = log_file_data)
except Exception as e:
    raise e

