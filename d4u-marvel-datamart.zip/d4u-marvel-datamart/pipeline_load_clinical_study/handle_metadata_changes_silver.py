# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

#getting the accept metadata flag for repair run
accept_metadata_change = dbutils.widgets.get("accept_metadata_change")
initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
domain_comparison_log_file = dbutils.jobs.taskValues.get(taskKey = "domain_comparison", key = "domain_comparison_log_file", default = "", debugValue = "")
# config_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_dict",default = "error", debugValue = "")

create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
non_clinic_file = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "non_clinic_file_name",default = "error", debugValue = "")
global error_process
global error_table
error_process = ""
error_table = ""
domains = dbutils.jobs.taskValues.get(taskKey  = "domain_comparison",key = "available_domains",default = "error", debugValue = "")
special_domains = dbutils.jobs.taskValues.get(taskKey  = "domain_comparison",key = "non_clinical_domains",default = "error", debugValue = "")
config_domain_dict = dbutils.jobs.taskValues.get(taskKey  = "domain_comparison",key = "config_domain_dict",default = "error", debugValue = "")
config_dict = spark.sql(f"select * from `{catalog_marvel}`.`default`.`config_dict_table_{run_id}`")
config_dict = config_dict.select("*").toPandas()
config_dict = config_dict.set_index('table').to_dict('index')
non_clinical_domains = special_domains
print(f"accept_metadata_change: {accept_metadata_change}")

# COMMAND ----------

try:
    logger.info("Creation of Lables Table if not Exists")
    spark.sql(f"CREATE TABLE IF NOT EXISTS `" + catalog_silver + "`.`" + study_schema_name + "`.`" + study_domain_model + "_labels` \
    ( \
    studyid string, \
    domain_model string, \
    domain string, \
    name string, \
    label string, \
    load_date string, \
    d4u_isactive boolean, \
    d4u_isdrop boolean \
    ) PARTITIONED BY (studyid,domain)" )
    
except Exception as e: 
    logger.error("Creation of Lables Table Failed")
    error_process = "handle_metadata_changes_silver"       
    error_table = f"{catalog_silver}.{study_schema_name}.{study_domain_model}_lables"
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,log_file_data,"","","","",log_file)
    handle_error(e,error_process,error_table)

# COMMAND ----------

def create_table(domain,study_domain_model,study_id,study_extraction_path,catalog_silver,catalog_gold,special_domains,temp_study_id,config_domain_dict):
    print("create_table function is called...")
    global error_table_suffix 
    error_table_suffix= ""
    
    try:
        data_file = config_domain_dict[domain] + ".csv"
        meta_file = config_domain_dict[domain] + "-meta.csv"
        domain_table_name = domain
        print(f"Data File: {data_file}")
        print(f"Meta File: {meta_file}")
        print(f"Domain Table Name: {domain_table_name}")

        df_pandas = build_pandas_df(study_extraction_path, meta_file,domain, special_domains)      
        # print(df_pandas)
        column_array = df_pandas.values
        querystr = ""
        for i in range(0,len(column_array)):
            querystr = querystr + str(column_array[i][0]) + " " + str(column_array[i][1]) + str(column_array[i][3]) + " comment \"" + str(column_array[i][2]) + "\","
        querystr = querystr[0:len(querystr)-1]

        df = spark.read.option("header","true").option("delimiter",",").option("ignoreLeadingWhiteSpace","true").csv(study_extraction_path + "/" + meta_file + "")
        df = df.na.drop("all")
        # if domain in special_domains:
        #     non_clinical_colslist =["STUDYID","RDOMAIN","USUBJID","IDVAR","IDVARVAL","RELTYPE","RELID"]
        #     df = df.filter(df.name.isin(non_clinical_colslist))
        df.createOrReplaceTempView(f"{temp_study_id}_{domain}_metadata")

        if not (is_table_exist(catalog_silver, study_id, domain_table_name)):
            # Create Silver domain table if not exist in study schema
            spark.sql("CREATE TABLE `" + catalog_silver + "`.`" + study_id + "`.`" + domain_table_name + "` (" + querystr + ")")
        else:
            # METADATA COMPARISON
            new_schema = spark.createDataFrame(df_pandas)
            new_schema = new_schema.select(col("name").alias("col_name"),col("finalformat").alias("data_type"),col("label").alias("comment"),col("varnum"))
            
            old_schema = spark.sql(f"DESCRIBE TABLE `{catalog_silver}`.`{study_schema_name}`.`{domain}`")
            old_schema = old_schema.filter(~col('col_name').rlike("^D4U_ARCHIVE.*"))
            old_schema = old_schema.withColumn("old_varnum", lit(0))
            # display(old_schema)
            compare_df = new_schema.join(old_schema,new_schema.col_name == old_schema.col_name,"fullouter").select(old_schema.col_name.alias("old_column"),new_schema.col_name.alias("new_column"),old_schema.data_type.alias("old_dtype"),new_schema.data_type.alias("new_type"),when(new_schema["data_type"]==old_schema["data_type"],lit("pass")).otherwise(lit("fail")).alias("dtype_match"),old_schema.old_varnum.alias("old_varnum"),new_schema.varnum.alias("varnum"), new_schema.comment.alias("new_comment"),old_schema.comment.alias("comment"),when(new_schema["comment"]==old_schema["comment"],lit("pass")).otherwise(lit("fail")).alias("comment_match"))
            # display(compare_df)          
            dtype_changes_df = compare_df.filter((col("dtype_match") == "fail") & (col("old_column").isNotNull())&(col("new_column").isNotNull()))
            newcols_changes_df = compare_df.filter(col("old_column").isNull())
            newcols_changes_df = newcols_changes_df.withColumn('varnum',col('varnum').cast('int')).orderBy(col('varnum'))
            dropcols_changes_df = compare_df.filter(col("new_column").isNull())
            comment_changes_df = compare_df.filter((col("comment_match") == "fail") & (col("old_column").isNotNull())&(col("new_column").isNotNull()))
            
            new_columns_added = newcols_changes_df.collect()
            print(f"the new added: {new_columns_added}")
            columns_dropped = dropcols_changes_df.collect()
            dtype_changes = dtype_changes_df.collect()
            comment_changes = comment_changes_df.collect()
            #for including new columns
            
            for row in new_columns_added:
                column_name = row.new_column
                data_type = row.new_type
                
                label = row.new_comment
                add_new_column(catalog_silver, study_schema_name, study_domain_model,\
                     domain, column_name, data_type,label,temp_study_id)
            if((len(columns_dropped)>0) & \
                (accept_metadata_change == 'False')):
                dropped_cols = [row.old_column for row in columns_dropped]
                raise Exception(f"ERROR: {dropped_cols} is being dropped from the table {domain_table_name},Add the domain name in the flag accept_metadata_change to proceed.")
            elif((len(columns_dropped)>0) & \
                (domain_table_name not in accept_metadata_change)):
                dropped_cols = [row.old_column for row in columns_dropped]
                raise Exception(f"ERROR: {dropped_cols} is being dropped from the table {domain_table_name},Add the domain name in the flag accept_metadata_change to proceed.")
            else:
                pass
                                
            for row in columns_dropped:
                column_name = row.old_column
                #check if column drop is for recid or recversion
                for x in config_dict.keys():
                    if column_name in config_dict[x]['RecIdKeys']:                
                        raise Exception(f"ERROR: {column_name} is available in Recid and is being dropped")
                    elif column_name in config_dict[x]['RecverKey']:
                        raise Exception(f"ERROR: {column_name} is available in Recver and is being dropped")                      

                drop_column(catalog_silver, study_schema_name, study_domain_model, domain, column_name,temp_study_id,batch_id)

            #for changing the datatype of existing column
            for row in dtype_changes:
                column_name = row.old_column
                #check if datatype is changed for recid or recversion key
                for x in config_dict.keys():
                    if column_name in config_dict[x]['RecIdKeys']:                
                        raise Exception(f"ERROR: {column_name} is available in Recid and datatype is being changed")
                    elif column_name in config_dict[x]['RecverKey']:
                        raise Exception(f"ERROR: {column_name} is available in Recver and is datatype is being changed") 
                #limiting the target datatype to string only(for sprint 2)
                data_type = row.new_type
                print(data_type)
                logger.info(f"new_dtype {data_type}")
                if data_type in("date","timestamp","datetime","time"):
                    raise Exception(f"ERROR: {data_type} datatype is not supported for {column_name}")
                # data_type = "string"
                old_type = row.old_dtype
                label = row.comment
                modify_column_datatype(catalog_silver, study_schema_name, study_domain_model, domain, column_name, data_type,label,old_type,batch_id)
                #modify_column_datatype(catalog_gold, study_domain_model, study_schema_name, domain, column_name, data_type)
            for row in comment_changes:
                column_name = row.new_column
                #limiting the target datatype to string only(for sprint 2)
                #data_type = row.new_type
                data_type =row.new_type
                print(data_type) 
                label = row.new_comment
                modify_column_label(catalog_silver, study_schema_name, study_domain_model, domain, column_name, data_type,label)
        # Drop the metadata temp view created for current domain
        spark.sql(f"DROP VIEW {temp_study_id}_{domain}_metadata")



        try:
            # Populate domain meta data table
            ingest_domain_metadata(df,catalog_silver,study_domain_model,study_schema_name,domain,temp_study_id)
        except Exception as t:
            error_table_suffix = "_meta"
            raise t
        try:  
            # Populate domain lables table
            df_labels=df.select("name","label")
            labels_table_name = study_domain_model + "_labels"
            df_labels = df_labels.withColumn("domain",lit(domain)) \
                      .withColumn("studyid",lit(study_id)) \
                      .withColumn("domain_model",lit(study_domain_model)) \
                      .withColumn("load_date",current_timestamp()) \
                      .withColumn("d4u_isactive",lit(True)) \
                      .withColumn("d4u_isdrop",lit(False))
            df_labels = df_labels.select("studyid","domain_model","domain","name","label","load_date","d4u_isactive","d4u_isdrop")
            #ingest_domain_labels(df_labels, catalog_silver, study_schema_name, labels_table_name,domain,temp_study_id)
        except Exception as y:
            # global error_table
            error_process = "populate_domain_labels"       
            error_table = f"{catalog_silver}.{study_schema_name}.{study_domain_model}_lables"
            raise y
    except Exception as p:
        # global error_process
        # global error_table
        error_process = "handle_metadata_changes_silver"       
        error_table = f"{catalog_silver}.{study_schema_name}.{study_domain_model}_{domain}{error_table_suffix}"
        raise p



# COMMAND ----------

try:
    logger.info("Creation of Domain Tables in Silver Layer Started ")
    logger.info("Creation and Insertion of  Domain Metadata Tables in Silver Layer Started")
    logger.info("Domain Lables Table Insertion started at Silver Layer")
    study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"  
    parallels = ThreadPool(thread_count)
    parallels.starmap(create_table,zip(domains,repeat(study_domain_model),repeat(study_id),
                                   repeat(study_extraction_path),repeat(catalog_silver),repeat(catalog_gold),repeat(special_domains),repeat(temp_study_id),repeat(config_domain_dict)))
    logger.info("Creation of Domain Tables in Silver Layer Completed ")
    logger.info("Creation and Insertion of  Domain Metadata Tables in Silver Layer Completed")
    logger.info("Domain Lables Table Insertion completed at Silver Layer")
except Exception as e:
        logger.error("Error at handle_metadata_changes_silver Process")
        logger.error(e)
        log_file_data=read_log_file(p_filename)      
        write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,log_file_data,"","","","",log_file)
        handle_error(e,error_process,error_table)

# COMMAND ----------

# DBTITLE 1,Decouple non_clinical/special  domains from domains after meta tables are created
# non_clinical domains should be processed seperately after meta data tables created
clinical_domains_list = domains

for domain in non_clinical_domains:
    if domain in clinical_domains_list:
        clinical_domains_list.remove(domain)
        
dbutils.jobs.taskValues.set(key   = "clinical_domains", \
                            value = clinical_domains_list)
# dbutils.jobs.taskValues.set(key   = "config_domain_dict", value = config_domain_dict) 
  
dbutils.jobs.taskValues.set(key   = "non_clinical_domains", \
                            value = non_clinical_domains)  

# COMMAND ----------

try:  
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "metadata_log_file", value = log_file_data)
except Exception as e:
    raise e



# COMMAND ----------


