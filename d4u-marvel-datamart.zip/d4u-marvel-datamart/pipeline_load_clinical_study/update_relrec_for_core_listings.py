# Databricks notebook source
delta_lake = "gold"
catalog_marvel = "marvel"
schema_marvel = "default"
audit_log_table = "audit_log"

study_id = dbutils.widgets.get("studyId")
source_data_model = dbutils.widgets.get("data_model")
lifecycle = dbutils.widgets.get("environment")
batch_id = dbutils.widgets.get("batchId")
load_timestamp = dbutils.widgets.get("loadTimestamp")
job_id = dbutils.widgets.get("job_id")
run_id = dbutils.widgets.get("run_id")
accept_metadata_change = dbutils.widgets.get("accept_metadata_change")
accept_domain_change = dbutils.widgets.get("accept_domain_change")
study_environment=lifecycle
pipeline_environment = lifecycle


# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------



# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------



# COMMAND ----------

# MAGIC %run ../utils/lineage_utils

# COMMAND ----------


from datetime import datetime as dt
from pyspark.sql import functions as F
import pandas as pd
from multiprocessing.pool import ThreadPool
from itertools import repeat

catalog_name = f"{catalog_marvel}-{lifecycle}-{delta_lake}"
relrec_table_name = f"{source_data_model}_relrec"
relrec_full_table_name = f"`{catalog_name}`.`{study_id}`.`{relrec_table_name}`"
relationship_full_table_name = f"`{catalog_name}`.`{study_id}`.`{relationship_table_name}`" 


# COMMAND ----------

# Create d4u_lineage table
try:
    create_table(catalog_name, study_id, relationship_table_name)
except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    raise e

# COMMAND ----------

# Execute RELREC processing first
print("Core listing RELREC creation started..")
try:
    process_relrec_relationships(catalog_name, study_id, relrec_table_name, relationship_table_name, source_data_model)
  
except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    raise e
   

# COMMAND ----------


# Execute Core LINEAGE processing
print("Core listing LINEAGE creation started..")
try:
    records = get_marvel_study_listing_config(study_id, lifecycle, 'Core', source_data_model)
    core_listing_table_names = [row["listing_name"] for row in records]
    print(core_listing_table_names)

    if len(core_listing_table_names) > 0:
        manage_self_lineage_relationships(core_listing_table_names, catalog_name, study_id, relationship_table_name, source_data_model)
       
except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    raise e
