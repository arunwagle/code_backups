# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")
ingest_silver_log_file = dbutils.jobs.taskValues.get(taskKey = "ingest_study_data_silver", key = "ingest_silver_log_file", default = "", debugValue = "")
nonclinicdom_log_file =  ""
overwrite_gold_log_file = dbutils.jobs.taskValues.get(taskKey = "overwrite_domain_tables_gold", key = "overwrite_gold_log_file", default = "", debugValue = "")
domain_comparison_log_file = dbutils.jobs.taskValues.get(taskKey = "domain_comparison", key = "domain_comparison_log_file", default = "", debugValue = "")


# COMMAND ----------

# DBTITLE 1,Clean up Resources
try: 
    extraction_point = f"{s3_mountpoint}/{target_study_extraction_path}/"
    #Removing extracted csv files once the process completes
    print(extraction_point)
    result = dbutils.fs.rm(extraction_point,True)
    if (result):
        print(f"Extracted study files in path {extraction_point} have been purged")
        logger.info(f"Extracted study files in path {extraction_point} have been purged")
    else:
        print(f"Purging extracted study files in path {extraction_point} has failed")
        logger.error(f"Purging extracted study files in path {extraction_point} has failed")
except Exception as e:
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,\
        metadata_log_file,ingest_silver_log_file,\
        overwrite_gold_log_file,log_file_data,"",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "No Datamart tables applicable"
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
    dbutils.notebook.exit(error_msg)

# COMMAND ----------

try:
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key = "cleanupres_log_file", value = log_file_data)
except Exception as e:
    raise e
