# Databricks notebook source
# DBTITLE 1,Get pipeline task variables
# MAGIC %run ./pipeline_task_variables 

# COMMAND ----------

# MAGIC %run ../utils/custom_logging 

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
domain_comparison_log_file = dbutils.jobs.taskValues.get(taskKey = "domain_comparison", key = "domain_comparison_log_file", default = "", debugValue = "")

# COMMAND ----------

try:
            
    # Create Silver schema if not exist
    if not (is_schema_exist(catalog_silver, study_schema_name)):
        query = f"CREATE SCHEMA `{catalog_silver}`.`{study_schema_name}`"
        spark.sql(query)
        logger.info(f"{study_schema_name} Schema Created in Silver Layer")
    else:
        print("%s already exists in %s" % (study_schema_name, catalog_silver))
        logger.info(f"{study_schema_name} already exists in {catalog_silver}")
    # Create Gold Schema if not exist
    if not (is_schema_exist(catalog_gold, study_schema_name)):
        query = f"CREATE SCHEMA `{catalog_gold}`.`{study_schema_name}`"
        spark.sql(query)
        logger.info(f"{study_schema_name} Schema Created in Gold Layer")
    else:
        print("%s already exists in %s" % (study_schema_name, catalog_gold))
        logger.info(f"{study_schema_name} already exists in {catalog_gold}")
except Exception as e:
    logger.error("Error while creating the Schema")
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,log_file_data,"","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
    raise e
    #dbutils.notebook.exit(error_msg)
     


# COMMAND ----------

#pre execution snapshot
try:
    logger.info("Retrieving the version snapshots of the tables before loading data into silver and gold tables")
    spark.sql(f"drop table if exists `{catalog_marvel}`.default.`temp_table_restore_{catalog_silver}_{temp_study_id}`")
    spark.sql(f"drop table if exists `{catalog_marvel}`.default.`temp_table_restore_{catalog_gold}_{temp_study_id}`")      
    versionssilvertable = get_version_snapshot(catalog_silver,study_id,temp_study_id)
    versionsgoldtable = get_version_snapshot(catalog_gold,study_id,temp_study_id)
except Exception as e:
    logger.error("Error while retrieving the snapshots of the tables")
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,log_file_data,"","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

try:
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "create_schema_log_file", value = log_file_data)
except Exception as e:
    raise e
