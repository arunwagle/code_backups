# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

from datetime import datetime as dt
from pyspark.sql.functions import col, regexp_replace
from pyspark.sql.types import *
import requests
import json
import base64
from pathlib import Path, PurePath
import os

studyId=study_id

# COMMAND ----------

# MAGIC %run ../programmed_listing_notebooks/dre_utils

# COMMAND ----------

domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_domains",default = "error", debugValue = "")
initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")
ingest_silver_log_file = dbutils.jobs.taskValues.get(taskKey = "ingest_study_data_silver", key = "ingest_silver_log_file", default = "", debugValue = "")
nonclinicdom_log_file = ""
overwrite_gold_log_file = dbutils.jobs.taskValues.get(taskKey = "overwrite_domain_tables_gold", key = "overwrite_gold_log_file", default = "", debugValue = "")
cleanupres_log_file = dbutils.jobs.taskValues.get(taskKey = "cleanup_resources", key = "cleanupres_log_file", default = "", debugValue = "")

domain_comparison_log_file = dbutils.jobs.taskValues.get(taskKey = "domain_comparison", key = "domain_comparison_log_file", default = "", debugValue = "")


zipfile_date = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "date_time_stamp_string",default = "error", debugValue = "")
data_source = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "dataModel",default = "error", debugValue = "")

spark.conf.set("spark.databricks.io.cache.enabled", "false")

# COMMAND ----------

try:
    print(f"date: {zipfile_date}")
    load_timestamp_drm_str = str(zipfile_date)

    load_timestamp_drm_datetime = dt.strptime(load_timestamp_drm_str, '%Y%m%dT%H%M%S')
    formatted_timestamp_str = load_timestamp_drm_datetime.strftime("%Y-%m-%dT%H:%M:%S")
    print(formatted_timestamp_str)
    df=spark.sql(f"show tables in `{catalog_marvel}`.`default`")
    spark.sql("set spark.sql.ansi.enabled = false")
    
    if (df.selectExpr(f"any(tableName =='temp_table_restore_{catalog_gold}_{temp_study_id}')").collect()[0][0]):

        # DJM 4/8/24 - JADF-23303 - The real fix was made in "main" branch and will be merged to release/GR2.0.0.  The old code is commented out for now and was a quick fix.
        # spark.sql(f"update `{catalog_marvel}`.`default`.`temp_table_restore_{catalog_gold}_{temp_study_id}` set `database` = replace(`database`,'`','')")
    
        check_df = spark.sql(f"select count(*),max(table) from `{catalog_marvel}`.`default`.`temp_table_restore_{catalog_gold}_{temp_study_id}`")
        check_condt = check_df.collect()
        if(check_condt[0][0] != 1 and check_condt[0][1] != "sdtm_checks"):
                                         
            meta_tables = spark.sql(f"select * from `{catalog_marvel}`.`default`.`temp_table_restore_{catalog_gold}_{temp_study_id}` where table like '%meta' ")
            meta_tables = meta_tables.collect()
            label_table = spark.sql(f"select * from `{catalog_marvel}`.`default`.`temp_table_restore_{catalog_gold}_{temp_study_id}` where table like '%labels' ")
            label_table = label_table.collect()
            type_change_query_string = ""
            for i in range(len(meta_tables)):
                type_change_query_string = type_change_query_string +f"""
                select replace('{meta_tables[i][2]}','_meta','') as table,name,string(collect_list(type)) as dtype from 
                (
                select name,concat('old_dtype:',type) as type from `{meta_tables[i][0]}`.`{meta_tables[i][1]}`.`{meta_tables[i][2]}` version as of {meta_tables[i][3]}
                union
                select name,concat('new_dtype:',type) as type from `{meta_tables[i][0]}`.`{meta_tables[i][1]}`.`{meta_tables[i][2]}` 
                ) 
                group by name
                having count(distinct(substring(type,10,length(type)))) = 2

                union all """
            meta_change = spark.sql(type_change_query_string[0:len(type_change_query_string)-11])
            new_col_query_string = ""
            for i in range(len(meta_tables)):
                new_col_query_string = new_col_query_string + f"""select replace('{meta_tables[i][2]}','_meta','') as table,name as columns,type as type from `{meta_tables[i][0]}`.`{meta_tables[i][1]}`.`{meta_tables[i][2]}` where name not in (select name from `{meta_tables[i][0]}`.`{meta_tables[i][1]}`.`{meta_tables[i][2]}` version as of {meta_tables[i][3]})
                union all """
            new_col_df = spark.sql(new_col_query_string[0:len(new_col_query_string)-11])
            drop_col_query_string = ""
            for i in range(len(meta_tables)):
                drop_col_query_string = drop_col_query_string + f"""select replace('{meta_tables[i][2]}','_meta','') as table,name as columns,type as type from `{meta_tables[i][0]}`.`{meta_tables[i][1]}`.`{meta_tables[i][2]}` version as of {meta_tables[i][3]} where name not in (select name from `{meta_tables[i][0]}`.`{meta_tables[i][1]}`.`{meta_tables[i][2]}` )
                union all """
            print(drop_col_query_string)
            drop_col_df = spark.sql(drop_col_query_string[0:len(drop_col_query_string)-11])
            # DJM 3/15/24 Performance Tweak - drop_col_df.show()
            label_change_query_string =f"""select concat(domain_model,'_',domain) as table,name,string(collect_list(label)) as label_change from
            (
            select domain_model,domain,name,concat('old_label:',coalesce(label,'null')) as label from `{label_table[0][0]}`.`{label_table[0][1]}`.`{label_table[0][2]}` version as of {label_table[0][3]}
            union
            select domain_model,domain,name,concat('new_label:',coalesce(label,'null')) as label from `{label_table[0][0]}`.`{label_table[0][1]}`.`{label_table[0][2]}`

            )
            group by domain_model,domain,name
            having count(distinct(substring(label,10,length(label)))) = 2

            """
            labels_df = spark.sql(label_change_query_string)
            new_col_tables = new_col_df.select(collect_set('table')).collect()[0][0]
            drop_col_tables =drop_col_df.select(collect_set('table')).collect()[0][0]
            meta_change_tables = meta_change.select(collect_set('table')).collect()[0][0]
            domain_tables = spark.sql(f"select * from `{catalog_marvel}`.default.`temp_table_restore_{catalog_gold}_{temp_study_id}` where table not like '%meta' and table not like '%labels' and table not like '%relrec'")
            domain_tables = domain_tables.filter(~col('table').isin(new_col_tables))
            domain_tables = domain_tables.filter(~col('table').isin(meta_change_tables))
            domain_tables = domain_tables.filter(~col('table').isin(drop_col_tables))
            m_count = domain_tables.count()
            domain_tables = domain_tables.collect()
            query_string = ""

            for i in range(len(domain_tables)):
                query_string = f"""
                    {query_string}
                    -- Count inserted records
                    SELECT 
                        COUNT(d4u_recid) as counts,
                        'insert' as task,
                        '{domain_tables[i][2]}' as table 
                    FROM `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}`
                    WHERE d4u_recid NOT IN (
                        SELECT d4u_recid 
                        FROM `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` 
                        VERSION AS OF {domain_tables[i][3]}) 

                    UNION ALL 

                    -- Count dropped records
                    SELECT 
                        COUNT(d4u_recid) as counts,
                        'drop' as task,
                        '{domain_tables[i][2]}' as table 
                    FROM `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` 
                    VERSION AS OF {domain_tables[i][3]} 
                    WHERE d4u_recid NOT IN (
                        SELECT d4u_recid 
                        FROM `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}`
                    )

                    UNION ALL 
                    
                    -- Count updated records
                    SELECT 
                        COUNT(d4u_recid) as counts,
                        'updated' as task,
                        '{domain_tables[i][2]}' as table 
                    FROM ( 
                        SELECT d4u_recid, d4u_recver
                        FROM `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` 
                        WHERE d4u_recid 
                        IN (
                            SELECT d4u_recid 
                            FROM `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` 
                            VERSION AS OF {domain_tables[i][3]} 
                        ) 
                        EXCEPT (
                            SELECT d4u_recid, d4u_recver
                            FROM `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` 
                            VERSION AS OF {domain_tables[i][3]}) 
                    ) 
                    UNION ALL """
            #print(query_string)
            relrec_metric = spark.sql(f"select '' as table,'' as drop,'' as insert,'' as updated")

            if(m_count != 0):
                # Remove the last UNION ALL from string
                metrics_df = spark.sql(query_string[0:len(query_string)-11])
                metrics_df = metrics_df.groupBy("table").pivot("task").sum("counts")
                metrics_df = relrec_metric.union(metrics_df)
            else:
                metrics_df = relrec_metric                 

            subtract_tables = metrics_df.select(collect_set("table")).collect()[0][0]
            domain_tables = spark.sql(f"show tables in `{catalog_gold}`.`{study_schema_name}`").filter((col("tableName").like("drm%"))|(col("tableName").like("relrec%"))|(col("tableName").like("sdtm%"))) 
            domain_tables = domain_tables.filter((~col("tableName").like("%whiteboard%")))
            domain_tables = domain_tables.filter((~col("tableName").like("%meta"))&(~col("tableName").like("%labels"))&(~col("tableName").isin(subtract_tables))).select("tableName")
            domain_tables = domain_tables.filter(~col('tableName').isin(new_col_tables))
            domain_tables = domain_tables.filter(~col('tableName').isin(meta_change_tables))
            domain_tables = domain_tables.filter(~col('tableName').isin(drop_col_tables))

            d_count = domain_tables.count()
            domain_tables = domain_tables.collect()
            newtable_string = ""
            for i in range(len(domain_tables)):
                newtable_string = newtable_string + f"select '{domain_tables[i][0]}' as table,'n/a' as drop,count(*) as insert,'n/a' as updated from `{catalog_gold}`.`{study_schema_name}`.`{domain_tables[i][0]}` union all "

                #print(newtable_string)
            if(d_count != 0):
                new_table_metric_df = spark.sql(newtable_string[0:len(newtable_string)-11])
                metrics_df = metrics_df.union(new_table_metric_df)
            else:
                pass

            domain_tables = spark.sql(f"select * from `{catalog_marvel}`.default.`temp_table_restore_{catalog_gold}_{temp_study_id}` where table not like '%meta' and table not like '%labels' and table not like '%relrec'")
            domain_tables = domain_tables.filter(col('table').isin(new_col_tables) | col('table').isin(meta_change_tables)|col('table').isin(drop_col_tables))        

            d_count = domain_tables.count()
            domain_tables = domain_tables.collect()

            meta_change_string = ""
            for i in range(len(domain_tables)):
                meta_change_string = meta_change_string + f"""select count(d4u_recid) as counts,'insert' as task,'{domain_tables[i][2]}' as table from `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` where d4u_recid not in (select d4u_recid from `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` version as of {domain_tables[i][3]}) union all select count(d4u_recid) as counts,'drop' as task,'{domain_tables[i][2]}' as table from `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` version as of {domain_tables[i][3]} where d4u_recid not in (select d4u_recid from `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}`) union all select count(d4u_recid)
                as counts,'updated' as task, '{domain_tables[i][2]}' as table from (select d4u_recid from `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}` version as of {domain_tables[i][3]} intersect select  d4u_recid from `{domain_tables[i][0]}`.`{domain_tables[i][1]}`.`{domain_tables[i][2]}`) union all """

            if(d_count != 0):
                meta_change_nw_table_df = spark.sql(meta_change_string[0:len(meta_change_string)-11])

                meta_change_nw_table_df=meta_change_nw_table_df.groupBy("table").pivot("task").sum("counts")
                metrics_df = metrics_df.union(meta_change_nw_table_df)
            else:
                pass

            #labels_df.write.mode("overwrite").format("delta").saveAsTable(f"`{catalog_marvel}`.default.`temp_table_labels_df_{catalog}_{study_id}`")
            #metrics_df.write.mode("overwrite").format("delta").saveAsTable(f"`{catalog_marvel}`.default.`temp_table_metrics_df_{catalog}_{study_id}`")
            #new_col_df.write.mode("overwrite").format("delta").saveAsTable(f"`{catalog_marvel}`.default.`temp_table_new_col_df_{catalog}_{study_id}`")
            #meta_change.write.mode("overwrite").format("delta").saveAsTable(f"`{catalog_marvel}`.default.`temp_table_meta_change_{catalog}_{study_id}`")
            new_col_df = new_col_df.groupBy("table").agg(collect_set("columns"))
            new_col_df = new_col_df.select(col('table'),col('collect_set(columns)').cast('string').alias("new_cols"))
            drop_col_df = drop_col_df.groupBy("table").agg(collect_set("columns"))
            drop_col_df = drop_col_df.select(col('table'),col('collect_set(columns)').cast('string').alias("drop_cols"))
            meta_change = meta_change.select('table',concat_ws(':','name','dtype').alias('dtype_change'))
            meta_change = meta_change.groupBy("table").agg(collect_set("dtype_change"))
            meta_change = meta_change.select(col('table'),col('collect_set(dtype_change)').cast('string').alias("dtype_change"))
            labels_df = labels_df.select('table',concat_ws(':','name','label_change').alias('labels_change'))
            labels_df = labels_df.groupBy("table").agg(collect_set("labels_change"))
            labels_df = labels_df.select(col('table'),col('collect_set(labels_change)').cast('string').alias("labels_change"))
            final_stats_temp = metrics_df.alias('metric').join(new_col_df,metrics_df.table == new_col_df.table,'left').join(drop_col_df,metrics_df.table == drop_col_df.table,'left').join(meta_change,metrics_df.table == meta_change.table,'left').join(labels_df,metrics_df.table == labels_df.table,'left').select('metric.table','drop','insert','updated','new_cols','drop_cols','dtype_change','labels_change')
            final_stats_temp = final_stats_temp.fillna("no change")
            final_stats_temp.createOrReplaceTempView("final_stats")
            final_stats_df = spark.sql("select table,cast(drop as string),cast(insert as string),cast(updated as string),concat('NEW_COLUMNS:',new_cols,' ','DROP_COLUMN:',drop_cols,' ','DATATYPE_CHANGE:',dtype_change,' ','LABELS_CHANGE:',labels_change) as metadata_change from final_stats")
            #final_stats_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"`{catalog_marvel}`.default.`temp_table_stats_{study_id}`")
        else:
            print("new study")
            domain_tables = spark.sql(f"show tables in `{catalog_gold}`.`{study_schema_name}`").filter((col("tableName").like("drm%"))|(col("tableName").like("relrec%"))|(col("tableName").like("sdtm%")))
            domain_tables = domain_tables.filter((~col("tableName").like("%whiteboard%")))
            domain_tables = domain_tables.filter((~col("tableName").like("%meta"))&(~col("tableName").like("%labels"))).select("tableName")
            domain_tables = domain_tables.collect()
            newstudy_string = ""
            for i in range(len(domain_tables)):
                newstudy_string = newstudy_string + f"select '{domain_tables[i][0]}' as table,'n/a' as drop,count(*) as insert,'n/a' as updated ,'n/a' as metadata_change from `{catalog_gold}`.`{study_schema_name}`.`{domain_tables[i][0]}` union all "
                             
            final_stats_df = spark.sql(newstudy_string[0:len(newstudy_string)-11])
    else:
        print("new study")
        domain_tables = spark.sql(f"show tables in `{catalog_gold}`.`{study_schema_name}`").filter((col("tableName").like("drm%"))|(col("tableName").like("relrec%"))|(col("tableName").like("sdtm%")))
        domain_tables = domain_tables.filter((~col("tableName").like("%whiteboard%")))
        domain_tables = domain_tables.filter((~col("tableName").like("%meta"))&(~col("tableName").like("%labels"))).select("tableName")
        domain_tables = domain_tables.collect()
        newstudy_string = ""
        for i in range(len(domain_tables)):
            newstudy_string = newstudy_string + f"select '{domain_tables[i][0]}' as table,'n/a' as drop,count(*) as insert,'n/a' as updated ,'n/a' as metadata_change from `{catalog_gold}`.`{study_schema_name}`.`{domain_tables[i][0]}` union all "

        final_stats_df = spark.sql(newstudy_string[0:len(newstudy_string)-11])
except Exception as e:
    logger.error(f"Capturing of Metrics failed for {study_id} ")
    logger.error(e)
    log_file_data=read_log_file(p_filename)
    write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,metadata_log_file,
    ingest_silver_log_file,overwrite_gold_log_file,
    cleanupres_log_file,log_file_data,log_file)
    error_process = "stats creation"     
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "No Datamart tables applicable"
    domainstats={}
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,data_source,error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","", "", "")
    raise e
    dbutils.notebook.exit(error_msg)

# COMMAND ----------

try:
    if data_source.lower() == "sdtm":
        final_stats_df = final_stats_df.filter(col("table").like("sdtm%"))
    else:
        final_stats_df = final_stats_df.filter(col("table").like("drm%"))
        
    logger.info(f"Metrics are Captured for {study_id}")
except Exception as e:
    raise e

# COMMAND ----------

updated_tables = final_stats_df.filter(expr("cast(updated as int) > 0 and cast(updated as int) is not null and table not like '%relrec'"))
tables_array = []
updated_tables = updated_tables.select("table").collect()
for table in updated_tables:
    tables_array.append(table[0])
print(updated_tables)

# COMMAND ----------

spark.sql(f"drop table if exists `{catalog_marvel}`.default.`temp_table_restore_{catalog_silver}_{temp_study_id}`")
spark.sql(f"drop table if exists `{catalog_marvel}`.default.`temp_table_restore_{catalog_gold}_{temp_study_id}`")
spark.sql(f"drop table if exists  `{catalog_marvel}`.default.`temp_table_stats_{study_id}`")

# COMMAND ----------

errant_tables = "N/A"
s3_file_location = ""
bucket_name = f"{s3_bucket_name}"
metrics_file_name = ""
msg = "Success: The load file for Study Id - {0} has been processed successfully".format(study_id)
domainstats = build_domain_statistics_dictionary(final_stats_df)
#message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,msg)
message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,formatted_timestamp_str,data_source,msg,domainstats)
 
send_notification(study_id,study_environment,"Success",business_user_recipients,message,vpc_name,s3_file_location,bucket_name,metrics_file_name,tables_array,load_timestamp)
logger.info(f"Domains that were successfully processed are :  {domains}")
logger.info(msg)

# COMMAND ----------

try:
    log_file_data=read_log_file(p_filename)
    write_log_file(initiate_process_log_file,study_zip_log_file,domain_comparison_log_file,create_schema_log_file,metadata_log_file,
    ingest_silver_log_file,overwrite_gold_log_file,
    cleanupres_log_file,log_file_data,log_file)
except Exception as e:
    raise e

# COMMAND ----------

# DBTITLE 1,Trigger Filter Job

# import requests

# try:
#     auth_header = f"Bearer {databricks_api_token}"
#     headers = {
#             'Authorization': auth_header,
#             'Content-Type': 'application/json'
#                     }
# except Exception as e:
#     raise e

# COMMAND ----------

# DBTITLE 1,trigger submit basic listing job
try:
    print(study_id,study_environment,data_source) 
    records=get_basic_listing_config(study_id, study_environment, data_source)
    if len(records) > 0:
        source_job_name = "submit_process_basic_listings"
        listing_job_id = dbutils.widgets.get("basic_prog_listing_jobid")
        #pipeline_environment = 'release'
        lifecycle=study_environment
        devMode="True"
        dataModel=data_source
        api_call = api_submit_job()  
    else:
        logger.info("No baic listing found for study : {study_id}")
        print(f"No basic listing found for study : {study_id}")
    # load_timestamp = dt.now().isoformat()

    # basic_prog_listing_jobid = dbutils.widgets.get("basic_prog_listing_jobid")

    # print(f'Using job id: {basic_prog_listing_jobid}')

    # submit_job_batch_id = create_audit_log(basic_prog_listing_jobid, basic_listing_job_name, study_id, study_environment, load_timestamp) 
    # devMode = "True"
    # lifecycle = study_environment

    # data = {
    #     "job_id":basic_prog_listing_jobid,
    #     "notebook_params": {"study_id" :study_id ,"environment" : study_environment,"pipeline_environment":pipeline_environment,"batchId": submit_job_batch_id,"source_job_name":job_name,"lifecycle":lifecycle,"devMode":devMode,"data_model": data_source,"date_time_stamp_string":formatted_timestamp_str,"listingType" : "basic"}
    #         }
    # jobs_response = requests.post(databricks_run_job_api, headers=headers, json=data)
    # print(f"File: API Response: {json.dumps(jobs_response.json(), indent=2)}") 
    
    # if(jobs_response.status_code == 200):
        
    #     print("Job has been triggered successfully")
    #     runs_response = requests.get(databricks_runs_list_api, params={"job_id": basic_prog_listing_jobid}, headers = headers)
        
    #     if(runs_response.status_code == 200):
            
    #         runs_response_json = runs_response.json()
    #         if "runs" in runs_response_json:
                
    #             response_list=runs_response_json["runs"]
    #             print(f'Found {len(response_list)} runs in response')
                
    #             current_run_id = None
    #             for i in response_list:
    #                 current_run_id = i["run_id"]
    #                 break

    #             if current_run_id is None:
    #                 raise Exception('Could not find run_id in response')
                
    #             print(f"Job submitted for study {study_id} with run_id: {current_run_id}")
    #             # Update run id into audit log table
    #             update_audit_log_run_id(submit_job_batch_id, current_run_id, "STARTED")               
    #         else:
    #             print("No active runs exist")
    #     else:
    #         print("Get active runs API call is not successful")
    # else:
    #     print(f"Submit job run for study {study_id} is not successful")
    #     update_audit_log_by_batch_id(submit_job_batch_id,"FAILED", "API call to submit job has failed")

except Exception as e:
    raise e

# COMMAND ----------

job_status = "SUCCESS"
message = "Pipeline Job %s has been executed successfully" % (job_name)
# Update audit log
update_audit_log(batch_id, job_id, run_id, study_id, study_environment, job_status, "Job has been executed successfully")
logger.info("Updating process end timstamp in checkpoint table ")

# COMMAND ----------

checkpoint_update_query = f"UPDATE {checkpoint_table} SET process_end_timestamp = CURRENT_TIMESTAMP() WHERE run_id = {run_id} AND study_id = '{study_id}' AND environment='{study_environment}'"
execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")
#spark.sql(checkpoint_update_query)
logger.info("Updating audit log table")

# COMMAND ----------

import psycopg2

def update_refresh_timestamp(study_id, lifecycle, source, refresh_timestamp):
    # Define the PostgreSQL connection string
    connection_string = f"postgresql://{dbMarvelUser}:{dbMarvelPwd}@{dbMarvelHost}:{dbMarvelPort}/{dbMarvelName}"

    # Establish a connection to the PostgreSQL database
    conn = psycopg2.connect(connection_string)

    cursor = conn.cursor()
 
    # Execute the SQL query
    update_query = f"""
       SELECT * from dre.update_study_lifecycle_source_refresh_time('{study_id}', '{lifecycle}', '{source}', '{refresh_timestamp}')
    """

    print(f"Executing query for study_id: {study_id}")
    print(f"Query: {update_query}")

    cursor.execute(update_query)

    # Commit the transaction
    conn.commit()
    
    # Close the cursor and connection
    cursor.close()
    conn.close()

# COMMAND ----------

rave_refresh_timestamp = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "rave_extract_timestamp", default = "", debugValue = "")
study_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "study_id", default = "", debugValue = "")
lifecycle = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "environment", default = "", debugValue = "")
source = "RAVE RAW"

if rave_refresh_timestamp:
    update_refresh_timestamp(study_id, lifecycle, source, rave_refresh_timestamp)
else:
    logger.info(f"Looks like rave_extract_time.csv is not present in the {study_id} zip file, skipping the update to RAVE RAW source..")


    
