# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

#get accept_domain_flag for repair run
accept_domain_change = dbutils.widgets.get("accept_domain_change")

# domains get values from study_zip_extract
domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_domains",default = "error", debugValue = "")

# config_domain_dict gets values from postgress_db 
config_domain_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_domain_dict",default = "error", debugValue = "")


special_domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "non_clinical_domains",default = "error", debugValue = "")

# config_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_dict",default = "error", debugValue = "")


initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")

study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")

# COMMAND ----------

# Converting the list of domains to a set for faster checking

try:
    domain_set = set(domains).union(set(special_domains))
    missing_domains = []
    for domain in config_domain_dict:
        if domain not in domain_set:
            missing_domains.append(domain)
    print(f"missing_domains list:{missing_domains}")
    # Find new domains that are not in the config_dict
    new_domains = [domain for domain in domain_set if domain not in config_domain_dict]
    print(f"new_domains list:{new_domains}")
except Exception as e:    
    logger.error(e)
    errormsg=str(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,log_file_data,"","","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", errormsg)
    errant_tables = "N/A" 
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",errormsg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
    raise Exception(errormsg)


# COMMAND ----------

#when accept_domain_change is true get configuration again
if(accept_domain_change == 'True'):
    try:
        records = get_marvel_study_listing_config(study_domain_model.upper(), study_id.lower(),study_environment.lower())
        if len(records) > 0:
            print('Study associated listing configuration present.')
        else:
   
            print('Study associated listing configuration is not present. Get listing configuration from template catalog')
 
            print('Study associated listing configuration is not present.')
    
        
        if len(records):
            config_dict={}
            for row in records:
                config=row[3]
                tableName=row[1]
                is_active = row[4]
                # print(is_active)
                columns_list=config['columns']
                recid_list=[]
                recver_list=[]
                all_cols_list=[]
                remove_cols=["D4U_RECID","D4U_RECVER","D4U_RECVERDATE"]
                if (is_active != False ):
                # if is_active is True or is_active is None:
                    print("entered the loop")
                    for key in columns_list:
                        all_cols_list.append(key['name'])
                        if key['isRecIdKey']==True:
                            recid_list.append(key['name'])
                        if key['isRecVersionKey']==True:
                            recver_list.append(key['name'])
                all_cols_list = list(set(all_cols_list)-set(remove_cols))
                combined_dict = dict(RecIdKeys= recid_list,all_cols=all_cols_list, RecverKey = recver_list)
                config_dict[tableName] = combined_dict
            # print(config_dict)
            config_domain_dict = {}
            for row in records:
                config=row[3]
                domain_name=row[2]
                domain_str = f"{domain_name}"
                config_domain_dict[domain_str] = row[1] #config['tableName']
            print(f"new configration for repair run:{config_domain_dict}")
            if new_domains:
                new_domains_check = [domain for domain in new_domains if domain not in config_domain_dict]
                new_domains_check_str = ' '.join(new_domains_check)
                if new_domains_check:
                    raise Exception(f"ERROR:New Domains detected but not in config_domain_dict(Postgress):{new_domains_check_str}")

            dbutils.jobs.taskValues.set(key = "config_domain_dict",value = config_domain_dict)
            config_dict_pandas_df = pd.DataFrame.from_dict(config_dict,'index')
            config_dict_pandas_df.index.name = "table" 
            config_dict_pandas_df.reset_index(inplace=True)            
            schema = StructType([StructField('table',StringType()),
                                StructField('RecIdKeys',ArrayType(StringType())),\
                StructField('all_cols',ArrayType(StringType())),\
                StructField('RecverKey',ArrayType(StringType()))\
                ])
            
            config_dict_spark_df = spark.createDataFrame(config_dict_pandas_df,schema=schema)
            # config_dict_spark_df.createOrReplaceGlobalTempView(f"config_dict_table_{run_id}")
            config_dict_spark_df.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(f"`{catalog_marvel}`.`default`.`config_dict_table_{run_id}`") 
                        
            dbutils.jobs.taskValues.set(key = "config_domain_dict",value = config_domain_dict)            

        else:
            raise Exception(f"ERROR: {study_domain_model.upper()} Configuration for Study - {study_id} does not exist in DRE Marvel. Job could not proceed")

    except Exception as e:
        error_msg = str(e)
        error_msg = error_msg.replace("'","").replace("\"","")
        update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
        log_file_data=read_log_file(p_filename)
        write_log_file(initiate_process_log_file,study_zip_log_file,log_file_data,"","","","","","",log_file)
        errant_tables = "N/A"
        domainstats ={} 
        message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,study_domain_model.upper(),error_msg,domainstats)
        send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
        raise e
    else:
        dbutils.jobs.taskValues.set(key = "config_domain_dict",value = config_domain_dict)

# COMMAND ----------

config_dict = spark.sql(f"select * from `{catalog_marvel}`.`default`.`config_dict_table_{run_id}`")
config_dict = config_dict.select("*").toPandas()
config_dict = config_dict.set_index('table').to_dict('index')


# COMMAND ----------

# Check if each key in the config_dict exists in the domain_set
try:
    # If there are missing domains, raise an exception with the list of missing domains
    if missing_domains:
        missing_domains_str = ' '.join(missing_domains)
        error_message = f"Update the study configuration for these domians {missing_domains_str}"
        errant_tables = "N/A"
        domainstats ={}
        message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_message,domainstats)
        print(message)
        send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
        if((study_environment == 'prod') & \
            (accept_domain_change == 'False')): 
            raise Exception(f"Update the study configuration for these domains: {missing_domains_str} or set accept_domain_change to True in repair run parameters")
        else:
            pass
            
            
        
    if new_domains:
        new_domains_str = ' '.join(new_domains)
        error_message = f"New Domains detected but not in config_domain_dict(Postgress) {new_domains_str}"
        errant_tables = "N/A"
        domainstats ={}
        message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_message,domainstats)
        send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
        if(accept_domain_change == 'False'): 
            raise Exception(f"New Domains detected but not in config_domain_dict(Postgress): {new_domains_str} add and set accept_domain_change to true in domain_comaprison task")
        else:
            pass
           


        
    if not new_domains and not missing_domains:
        # If all Domains are found in the domains list and there are no new or missing domains, continue with the job
        print("All Domains in config_dict are present in the domains list. Continuing with the job.")

except Exception as e:    
    logger.error(e)
    errormsg=str(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,study_zip_log_file,log_file_data,"","","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", errormsg)
    errant_tables = "N/A" 
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",errormsg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
    raise Exception(errormsg)



# COMMAND ----------

domains = list(set(domains)-set(missing_domains))
special_domains =  list(set(special_domains)-set(missing_domains))
domains = [config_domain_dict[x] for x in domains]
config_domain_dict = dict([(value, key) for key, value in config_domain_dict.items()])
non_clinical_domains = [config_domain_dict[x] for x in special_domains]



# COMMAND ----------

dbutils.jobs.taskValues.set(key   = "available_domains", \
                            value = domains)
dbutils.jobs.taskValues.set(key   = "non_clinical_domains", \
                            value = non_clinical_domains)
dbutils.jobs.taskValues.set(key   = "config_domain_dict", value = config_domain_dict)





# COMMAND ----------

try:  
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "domain_comparison_log_file", value = log_file_data)
except Exception as e:
    raise e
