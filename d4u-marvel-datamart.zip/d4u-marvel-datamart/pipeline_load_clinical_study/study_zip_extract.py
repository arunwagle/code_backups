# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")

# COMMAND ----------

# DBTITLE 1,Unzipping File and extracting CSV files from zip to Extraction Point Folder
try:
    trim_string = "%s/" % (s3_mountpoint)
    trimmed_study_folder_path = study_data_path.replace(trim_string, "")
    trimmed_study_source_path = "%s/%s" % (trimmed_study_folder_path, study_data_file)
    
    s3_study_folder_name = study_data_file.replace(".zip", "")
    s3_study_folder_path_part = f"{s3_unzipped_folder}{s3_study_folder_name}"
    
    # Create study folder
    s3_target_extraction_full_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
    result = dbutils.fs.mkdirs(s3_target_extraction_full_path)
    if (result):
        # Extract zip file content
        extract_zip_file(trimmed_study_source_path, f"{target_study_extraction_path}", s3_bucket_name,s3_marvel_assets_bucket)
        logger.info(f"Domain Data Files Extracted Succesfully from {study_data_file} file")
    else:
        print(f"S3 folder creation failed for path - {study_folder_path}")
        logger.error(f"ERROR - S3 folder creation failed for path {study_folder_path}. Study file could not be extracted and pipeline execution is aborted.")
        raise Exception(f"ERROR - S3 folder creation failed for path {study_folder_path}. Study file could not be extracted and pipeline execution is aborted.")
except Exception as e:
    logger.error("Error while Extracting the zip file")
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,log_file_data,"","","","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "N/A" 
    domainstats={}
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

# DBTITLE 1,load non_clinical data json
nc_df = spark.read.option("multiline","true").json(s3_nonclinical_domains_file)
nc_df1 = nc_df.select(nc_df.domains,explode(nc_df.domains)).drop("domains").withColumnRenamed("col","domains")
nc_df2 = nc_df1.withColumn("domain",nc_df1.domains.domain_name).withColumn("table_name",nc_df1.domains.table_name).withColumn("col_list",nc_df1.domains.column_list).drop("domains")
nc_domains = nc_df2.select(nc_df2[0]).collect()
nonclinical_domains = [dom.domain for dom in nc_domains]
non_clinic_domain = nonclinical_domains[0]

# COMMAND ----------

# DBTITLE 1,Listing Files from DBFS and fetching the domain names
try:
    domain_files = dbutils.fs.ls(s3_target_extraction_full_path)
    if domain_files:
        df_domain_files = pd.DataFrame(domain_files)
        list_file_names = list(df_domain_files["name"])
        non_clinic_dom= all(x in list_file_names for x in [study_domain_model+"_"+non_clinic_domain+".csv",non_clinic_domain+".csv"])
        if non_clinic_dom:
            raise Exception("ERROR:Study Zip File Contains both relrec and drm_relrec files.Study process job has been aborted.")
        else:
            non_clc_domain=any(x in list_file_names for x in [non_clinic_domain+"-meta.csv"])
            if non_clc_domain:
                non_clinic_file_name= non_clinic_domain    
            else:
                non_clinic_file_name= study_domain_model +"_"+ non_clinic_domain
            dbutils.jobs.taskValues.set(key = "non_clinic_file_name", value = non_clinic_file_name)
            print(non_clinic_file_name)
            pattern_string = "[a-zA-Z]*[_]*[a-zA-Z]+-meta\.csv"
            pattern = re.compile(pattern_string)
            meta_files = [x for x in list_file_names if pattern.match(x)]
            # domains =[x.split("-")[0].replace(study_domain_model+"_","") for x in meta_files]
            domains = [x.split("-")[0] for x in meta_files]
           
            if domains:
                dbutils.jobs.taskValues.set(key   = "available_domains", \
                                        value = domains)
                logger.info(f"Available Domains under {study_id} zip file are:{domains}")                                    
            else:
                raise Exception("ERROR:Study Zip File Compression is incorrect")

        # Extract rave_extract_timestamp.csv and configure the task param with value
        list_file_paths = list(df_domain_files["path"])
        rave_file_path = [x for x in list_file_paths if x.endswith("rave_extract_time.csv")]
        print(rave_file_path)

        if len(rave_file_path) > 0:
            refresh_timestamp = spark.read\
                .option('header','true')\
                .option('delimiter',',')\
                .option("ignoreLeadingWhiteSpace","true")\
                .option('quote',None)\
                .option('escape','"')\
                .option('multiline',True)\
                .csv(rave_file_path[0])
            print(refresh_timestamp.collect()[0]["rave_extract_time"])
            dbutils.jobs.taskValues.set(key   = "rave_extract_timestamp", \
                                        value = refresh_timestamp.collect()[0]["rave_extract_time"])
            logger.info(f"Rave timestamp from {study_id} zip file is:{refresh_timestamp.collect()[0]['rave_extract_time']}")
        else:
            logger.info(f"The rave_exract_time.csv file not found in {study_id}")
            dbutils.jobs.taskValues.set(key   = "rave_extract_timestamp", \
                                        value = '')
    else:
        raise Exception("ERROR:Study Zip File is Empty")    
except Exception as e:
    logger.error("Error occured at while fecthing the domain names")
    logger.error(e)
    log_file_data=read_log_file(p_filename)      
    write_log_file(initiate_process_log_file,log_file_data,"","","","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats={}
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
    dbutils.notebook.exit(error_msg)



# COMMAND ----------

# DBTITLE 1,Check for special domains presence 
special_domains = []
for domain in nonclinical_domains:
    if "drm_" + domain in domains:
        special_domains.append("drm_" + domain)
        print(special_domains)
#         print(domains)        
dbutils.jobs.taskValues.set(key   = "non_clinical_domains", \
                            value = special_domains)

# COMMAND ----------

try:
    log_file_data=read_log_file(p_filename)
    dbutils.jobs.taskValues.set(key   = "study_zip_log_file", value = log_file_data)
except Exception as e:
    raise e

