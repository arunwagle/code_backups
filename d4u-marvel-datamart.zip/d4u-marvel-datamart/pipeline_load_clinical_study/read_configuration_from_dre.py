# Databricks notebook source
pipeline_environment = dbutils.widgets.get("pipelineEnvironment")
batch_id = dbutils.widgets.get("batchId")
study_id = dbutils.widgets.get("studyId")
dataModel= dbutils.widgets.get("data_model")
environment = dbutils.widgets.get("environment")
load_timestamp = dbutils.widgets.get("loadTimestamp")
job_id = dbutils.widgets.get("job_id")
run_id = dbutils.widgets.get("run_id")
accept_metadata_change = dbutils.widgets.get("accept_metadata_change")
accept_domain_change = dbutils.widgets.get("accept_domain_change")
studyId=study_id.upper()
dataModel=dataModel.upper()
date_time_stamp_string = dbutils.widgets.get("date_time_stamp_string")


# COMMAND ----------

# pipeline_environment = 'release'

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run  ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------



# COMMAND ----------

try:
    # records= get_marvel_study_listing_config('DRM','testdamart301','DEV')
    records = get_marvel_study_listing_config(dataModel, studyId,environment)
    
    rec_count = len(records)
    
    if rec_count > 0:
        print('Study associated listing configuration present.')
    else:
        print('Study associated listing configuration is not present. Get listing configuration from template catalog.')

        # records = get_marvel_study_listing_config(dataModel)
        #records = get_marvel_study_listing_config("DRM")

    print(f"Study associated listing configuration count: {rec_count}")
    
    if rec_count:
        config_dict={}
        
        for row in records:
            config=row[3]
            tableName=row[1]
            is_active = row[4]
            # print(is_active)
            columns_list=config['columns']
            recid_list=[]
            recver_list=[]
            all_cols_list=[]
            remove_cols=["D4U_RECID","D4U_RECVER","D4U_RECVERDATE"]
            
            is_active = row[4]
            if is_active == False:
                print(f"Skipping an inactive listing, {row[1]}")
                continue


            for key in columns_list:
                all_cols_list.append(key['name'])
                if key['isRecIdKey']==True:
                    recid_list.append(key['name'])
                if key['isRecVersionKey']==True:
                    recver_list.append(key['name'])
            all_cols_list = list(set(all_cols_list)-set(remove_cols))
            combined_dict = dict(RecIdKeys= recid_list,all_cols=all_cols_list, RecverKey = recver_list)
            config_dict[tableName] = combined_dict
        print(config_dict)
        
        config_domain_dict = {}
        for row in records:
            config=row[3]
            domain_name=row[2]
            domain_str = f"{domain_name}"
            config_domain_dict[domain_str] = row[1] #config['tableName']
        print(config_domain_dict)

        dbutils.jobs.taskValues.set(key = "config_domain_dict",value = config_domain_dict)
        config_dict_pandas_df = pd.DataFrame.from_dict(config_dict,'index')
        config_dict_pandas_df.index.name = "table" 
        config_dict_pandas_df.reset_index(inplace=True)            
        schema = StructType([StructField('table',StringType()),
                             StructField('RecIdKeys',ArrayType(StringType())),\
            StructField('all_cols',ArrayType(StringType())),\
            StructField('RecverKey',ArrayType(StringType()))\
            ])
        
        config_dict_spark_df = spark.createDataFrame(config_dict_pandas_df,schema=schema)
        # config_dict_spark_df.createOrReplaceGlobalTempView(f"config_dict_table_{run_id}")
        config_dict_spark_df.write.mode("overwrite").format("delta").option("overwriteSchema", "true").saveAsTable(f"`{catalog_marvel}`.`default`.`config_dict_table_{run_id}`")

        
        
        

        # dbutils.jobs.taskValues.set(key   = "config_dict", \
                                                # value = config_dict)
        #dbutils.jobs.taskValues.set(key = "config_domains",value = config_domains_array)
        dbutils.jobs.taskValues.set(key = "date_time_stamp_string", value = date_time_stamp_string)
        dbutils.jobs.taskValues.set(key = "dataModel", value = dataModel)
        dbutils.jobs.taskValues.set(key = "config_domain_dict",value = config_domain_dict)
        dbutils.jobs.taskValues.set(key = "accept_metadata_change",value = accept_metadata_change)
        dbutils.jobs.taskValues.set(key = "accept_domain_change",value = accept_domain_change)
    else:
        raise Exception(f"ERROR: {dataModel} Configuration for Study - {studyId} does not exist in DRE Marvel. Job could not proceed")

except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,environment,job_id,run_id,load_timestamp,dataModel,error_msg,domainstats)
    send_notification(study_id,environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------


