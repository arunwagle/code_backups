# Databricks notebook source
# MAGIC %run ../init_scripts/init_load_rmcm

# COMMAND ----------

import pandas as pd
import re
from pyspark.sql.functions import col,expr,when,lit,explode,to_json,create_map,array,StructType
import datetime
from datetime import datetime as dt
from pyspark.sql.functions import col, lit,current_timestamp
import boto3 
import zipfile 
from io import BytesIO 
import json 
import re 
import time
from delta.tables import *
from multiprocessing.pool import ThreadPool
from itertools import repeat
from pyspark.sql.functions import concat,lit,col,collect_list,concat_ws,md5,collect_set,collect_list,min
from pyspark.sql.functions import desc
import os

base_path =f"dbfs:{s3_mountpoint}/rmcm/"

# COMMAND ----------

def tableExists(catalog_name,study_schema_name,table_name):
    return spark.sql(f'show tables in `{catalog_name}`.`{study_schema_name}`').selectExpr(f"any(tableName =='{table_name}')").collect()[0][0]



# COMMAND ----------

def createTableIfNotExist(catalog_name,study_schema_name,  tableName,  schema):
    
    if tableExists(catalog_name,study_schema_name,tableName):
        print(f'Table {tableName} already exist.')
    else:
        
        emptyDF = spark.createDataFrame([], schema)
        emptyDF \
            .write \
            .mode("overwrite") \
            .format("delta") \
            .option("delta.columnMapping.mode", "name") \
            .option("delta.minReaderVersion", "2") \
            .option("delta.minWriterVersion", "5") \
            .saveAsTable(f"`{catalog_name}`.`{study_schema_name}`.`{tableName}`")

        #spark.sql(f"""COMMENT ON TABLE {str(tableName)} IS '{tableTitle}'""")
        
        print(f'Created new table {tableName}')

    return f"`{catalog_name}`.`{study_schema_name}`.`{tableName}`"

# COMMAND ----------

def delete_file(s3_access_key, s3_secret_key, aws_region, s3_bucket_name, s3_folder, old_file_name):
    try:
        s3 = boto3.client('s3', aws_access_key_id=s3_access_key, aws_secret_access_key=s3_secret_key, region_name=aws_region)
        
        # Check if the file exists in the S3 folder
        response = s3.list_objects_v2(Bucket=s3_bucket_name, Prefix=f"{s3_folder}/{old_file_name}")
        if 'Contents' in response:
            # File exists, delete it
            timestamp_str = dt.utcnow().strftime('%Y%m%dT%H%M%S')
            s3.delete_object(Bucket=s3_bucket_name, Key=f"{s3_folder}/{old_file_name}")
            print(f"File {old_file_name}  was deleted")
    except Exception as e:
        print(f'Error: {e}')
        raise e

# COMMAND ----------

# DBTITLE 1, file renamer
import boto3
from botocore.exceptions import NoCredentialsError

def rename_file(s3_access_key, s3_secret_key, aws_region, s3_bucket_name, s3_folder, old_file_name, message, file_ext):
    try:
        s3 = boto3.client('s3', aws_access_key_id=s3_access_key, aws_secret_access_key=s3_secret_key, region_name=aws_region)
        
        # Check if the file exists in the S3 folder
        response = s3.list_objects_v2(Bucket=s3_bucket_name, Prefix=f"{s3_folder}/{old_file_name}")
        if 'Contents' in response:
            # File exists, rename it
            timestamp_str = dt.utcnow().strftime('%Y%m%dT%H%M%S')
            s3.copy_object(Bucket=s3_bucket_name, CopySource={'Bucket': s3_bucket_name, 'Key': f"{s3_folder}/{old_file_name}"}, Key=f"{s3_folder}/{message}_{jobId}_{timestamp_str}.{file_ext}")
            s3.delete_object(Bucket=s3_bucket_name, Key=f"{s3_folder}/{old_file_name}")
            print(f"File {old_file_name}  renamed to {message}_{jobId}_{timestamp_str}.{file_ext} in S3 path: {s3_folder}")
        else:
            print(f"File {old_file_name} not found in S3 path: {s3_folder}")

    except NoCredentialsError:
        print('Credentials not available')
    except Exception as e:
        print(f'Error: {e}')
        raise

# COMMAND ----------

# DBTITLE 1, Used to change the .trg file extension to .ipr file extension.
import boto3
from botocore.exceptions import NoCredentialsError

def rename_if_file_exists(s3_access_key, s3_secret_key, aws_region, s3_bucket_name, s3_folder, old_file_name, new_file_name):
    try:
        s3 = boto3.client('s3', aws_access_key_id=s3_access_key, aws_secret_access_key=s3_secret_key, region_name=aws_region)
        
        # Check if the file exists in the S3 folder
        response = s3.list_objects_v2(Bucket=s3_bucket_name, Prefix=f"{s3_folder}/{old_file_name}")
        if 'Contents' in response:
            # File exists, rename it
            s3.copy_object(Bucket=s3_bucket_name, CopySource={'Bucket': s3_bucket_name, 'Key': f"{s3_folder}/{old_file_name}"}, Key=f"{s3_folder}/{new_file_name}")
            s3.delete_object(Bucket=s3_bucket_name, Key=f"{s3_folder}/{old_file_name}")
            print(f"File {old_file_name} renamed to {new_file_name} in S3 path: {s3_folder}")
        else:
            print(f"File {old_file_name} not found in S3 path: {s3_folder}")

    except NoCredentialsError:
        print('Credentials not available')
    except Exception as e:
        print(f'Error: {e}')
        raise




# COMMAND ----------

# DBTITLE 1,Roll back 
def rollback_table_to_timestamp(catalog_name, matching_values, load_timestamp):
    
    for schema, table_name in matching_values:
        table_path = f"{catalog_name}.{matching_values}"

        # Roll back the table to the desired loadTimestamp using AS OF
        rollback_query = f"RESTORE TABLE {table_path} TO TIMESTAMP AS OF '{load_timestamp}'"
        spark.sql(rollback_query)

        print(f"Table {table_path} rolled back to loadTimestamp {load_timestamp}")


def drop_tables(catalog_name, drop_values):
    for drop_value in drop_values:
        
        table_path = drop_value.replace('New Value: (', '').replace(')', '')
        
        schema, table_name = [part.strip('`') for part in table_path.split('.')]

        spark.sql(f"USE {catalog_name}.{schema}")

        # Check if the table exists
        exists_query = f"SHOW TABLES LIKE '{table_name}';"
        table_exists = spark.sql(exists_query).count() > 0

        if table_exists:
            # Drop the table
            drop_query = f"DROP TABLE IF EXISTS {table_name};"
            spark.sql(drop_query)
            print(f"Dropped table: {schema}.{table_name}")
        else:
            print(f"Table does not exist: {schema}.{table_name}")


# COMMAND ----------

# DBTITLE 1,incremental_functions
def get_dir_content(ls_path):
  finalList=[]
  dir_paths = dbutils.fs.ls(ls_path)
  #print(f"dir_path: ", dir_paths)
  subdir_paths = [get_dir_content(p.path) for p in dir_paths if p.isDir() and p.path != ls_path]
  #print(f"subdir_paths: ", subdir_paths)
  flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
  #print(f"flat_subdir_paths: ", flat_subdir_paths)
  #return list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths
  #print(f"list path: ", list(map(lambda p: p.path, dir_paths)))
  #return flat_subdir_paths
  list_without_zip = [ x for x in list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths if x.endswith('.parquet.gzip') ]
  return list_without_zip

# Get current year

def get_current_year():
    date = datetime.now().date
    month = datetime.now().month
    year = datetime.now().year

    print("Current date: ", date)
    print("Current month: ", month)
    print("Current year: ", year)
    return year;

# COMMAND ----------

# create dataframe from list
def pathInfo_df(batch_id, path_list, domain):
    df=spark.createDataFrame(path_list, StringType())
    pathInfo_df=df.withColumn("batch_id", lit(batch_id)) \
        .withColumn("path_hash", md5((df['value']))) \
        .withColumn("domain", lit(domain)) \
        .withColumn("year", regexp_extract('value', 'snapshotdate_year=([0-9]{4})', 1).cast(StringType()))\
        .withColumn("month", regexp_extract('value', 'snapshotdate_month=([0-9]{2})', 1).cast(StringType()))\
        .withColumn("date", regexp_extract('value', 'snapshotdate_day=([0-9]{2})', 1).cast(StringType()))\
        .withColumnRenamed("value", "path")
    # print("path df")
    # display(pathInfo_df)
    return pathInfo_df

# COMMAND ----------

def compare_file_processed(year_list,table,batch_id,domain,file_processed_table,schema):
    final_pathInfo_df=spark.createDataFrame([],schema=schema)
    for year_iter in year_list:
        path_list=get_dir_content(f"{base_path}/{table}/snapshotdate_year={year_iter}/")
        # print(f"path list {path_list}")
        path_df=pathInfo_df(batch_id,path_list,domain)
        #final_pathInfo_df.unionByName(path_df, allowMissingColumns=True)
        final_pathInfo_df=final_pathInfo_df.unionAll(path_df)
        # print("inside for loop")
        # display(final_pathInfo_df)

    #Compare final_pathInfo with file_processed audit table
    #Create tabel if not exists
    delim = ","
    years = delim.join(map(str, year_list))
    #print(years)
    #spark.sql(f"select * from {file_processed_table} where year in ({years})").show()
    file_processed_query =f"""select * from `marvel-prod-gold`.`rmcm`.`file_processed_audit` where year in ({years})"""
    # print("final_pathInfo_df : ")
    # display(final_pathInfo_df)
    #final_pathInfo_df.count()
    file_processed_df = spark.sql(file_processed_query)
    if(file_processed_df.count()==0):
        process_df = final_pathInfo_df
    else:
        process_df = final_pathInfo_df.join(file_processed_df, final_pathInfo_df["path_hash"] == file_processed_df["path_hash"], "left_anti")
    return process_df

# COMMAND ----------

def create_delta_table(folder_name, folder_path):
    global record_count
        
    df = spark.read.parquet(folder_path)
    # before_ingestion =  df.count()
    # print(before_ingestion)
    df = (
        df.dropDuplicates()
        .withColumn('D4U_RECID', F.md5(F.concat_ws("||", *df.columns)))
        .withColumn('D4U_RECVERDATE', F.current_date())
        .withColumn('D4U_RECVER', F.md5(F.lit('')))
    )

    table_name = f"rmcm_{folder_name}" if not folder_name.startswith("rmcm") else folder_name
    # cleaned_columns = [col.replace(' ', '_').replace(';', '_').replace(',', '_') for col in df.columns]
    # df = df.toDF(*cleaned_columns)

    # Write the DataFrame as a Delta table
    df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"`{catalog_name}`.`{schema_name}`.`{table_name}`")

    # Get the count of records inserted
    record_count = df.count()
    print(f"{table_name}: Total records inserted: {record_count}")

  
       


# COMMAND ----------

# DBTITLE 1,incremental_functions
def initial_load():

    folder_path_list=[str(base_path)+ "bv_ora_eccdb_v_ora_missing_pages_hist/",str(base_path)+"co_missing_pages_hist/"]
    folder_name_list= ["bv_ora_eccdb_v_ora_missing_pages_hist","co_missing_pages_hist"]
    with ThreadPoolExecutor(max_workers=len(folder_name_list)) as executor:
    # Submit each folder and folder_path to the executor
        futures = [executor.submit(create_delta_table, folder_name, folder_path) for folder_name, folder_path in zip(folder_name_list, folder_path_list)]

    bv_list=get_dir_content(str(base_path)+"bv_ora_eccdb_v_ora_missing_pages_hist/")
    bv_hist_path_df = pathInfo_df(batch_id, bv_list, "bv_hist")

    co_list=get_dir_content(str(base_path)+"co_missing_pages_hist/")
    co_hist_path_df = pathInfo_df(batch_id, co_list, "co_hist")

    processed_df = bv_hist_path_df.union(co_hist_path_df)
    processed_df.write.format("delta").mode("append").saveAsTable(f"`{catalog_name}`.`{schema_name}`.`{file_processed_table}`")

#Wite data in table

def ingest_delta_table(folder_name, folder_path):
    try:
        # Read parquet file into DataFrame
        df = spark.read.parquet(folder_path)

        
        df = (
            df.dropDuplicates()
            .withColumn('D4U_RECID', F.md5(F.concat_ws("||", *df.columns)))
            .withColumn('D4U_RECVERDATE', F.current_date())
            .withColumn('D4U_RECVER', F.md5(F.lit('')))
        )

        # Define the Delta table name
        table_name = f"rmcm_{folder_name}" if not folder_name.startswith("rmcm") else folder_name
        delta_table = f"`{catalog_name}`.`{schema_name}`.`{table_name}`"

        

        # Define the conditions for the MERGE statement
        
        merge_conditions = """
        ON existing.D4U_RECID = updates.D4U_RECID
        WHEN NOT MATCHED THEN 
        INSERT *
        """

        # Merge statement
        spark.sql(f"""
            MERGE INTO {delta_table} AS existing
            USING `marvel-prod-gold`.`rmcm`.`file_processed_audit` AS updates
            {merge_conditions}
        """)


        print("Upsert into Delta table completed successfully.")

        # Get the count of records inserted
        record_count = df.count()
        print(f"{table_name}: Total records inserted: {record_count}")

    except Exception as e:
        print(f"Error: {str(e)}")
        update_audit_log(batch_id, jobId, runId, studyId, studyEnvironment, job_status="ERROR")
        # Raise an exception to terminate the pipeline
        raise RuntimeError(f"Error processing folder {folder_name}: {str(e)}")

# COMMAND ----------

# DBTITLE 1,Extracting schema from parquet file
from pyspark.sql.types import StructField, StringType

def read_parquet_and_store_details(full_paths, excluded_paths):
    # Dictionary to store details (folder_name: columns_and_datatypes)
    details_dict = {}

    for full_path in full_paths:
        # Skip processing for specific paths
        if any(excluded_path in full_path for excluded_path in excluded_paths):
            print(f"Skipping path {full_path}...")
            continue

        # Extract folder name from the path
        folder_name = full_path.split("/")[-2]

        # Check if folder_name starts with "rmcm_", if not, add "rmcm_"
        if not folder_name.startswith("rmcm_"):
            folder_name = f"rmcm_{folder_name}"

        # Read Parquet file
        parquet_df = spark.read.parquet(full_path)

        # Get columns and datatypes
        columns_and_datatypes = {col.name: str(col.dataType) for col in parquet_df.schema}

        # Update details_dict
        details_dict[folder_name] = columns_and_datatypes

    return details_dict

def print_details(result_details):
    # Print or process the result as needed
    for folder_name, columns_and_datatypes in result_details.items():
        print(f"Folder Name: {folder_name}")
        print("Columns and Datatypes:")
        for column, datatype in columns_and_datatypes.items():
            print(f"  {column}: {datatype}")
        print("\n")



# COMMAND ----------

# DBTITLE 1,Extracting schema from delta tables
def read_delta_and_store_details(catalog_name, schema_name, exclude_tables=None, exclude_columns=None):
    # Dictionary to store details (table_name: columns_and_datatypes)
    table_details_dict = {}

    # Get the list of delta tables
    delta_tables_query = f"SHOW TABLES IN `{catalog_name}`.{schema_name}"
    delta_tables = spark.sql(delta_tables_query).select("tableName").collect()

    for table_info in delta_tables:
        table_name = table_info["tableName"]

        # Exclude tables specified in exclude_tables list
        if exclude_tables and table_name.lower() in exclude_tables:
            continue

        # Read Delta table
        delta_table_df = spark.read.format("delta").table(f"`{catalog_name}`.`{schema_name}`.`{table_name}`")

        # Exclude specified columns
        if exclude_columns:
            delta_table_df = delta_table_df.drop(*exclude_columns)

        # Get columns and datatypes
        columns_and_datatypes = {col.name: str(col.dataType) for col in delta_table_df.schema}

        # Update details_dict
        table_details_dict[table_name] = columns_and_datatypes

    return table_details_dict

def print_details(result_details):
    # Print or process the result as needed
    for table_name, columns_and_datatypes in result_details.items():
        print(f"Table Name: {table_name}")
        print("Columns and Datatypes:")
        for column, datatype in columns_and_datatypes.items():
            print(f"  {column}: {datatype}")
        print("\n")




# COMMAND ----------

# DBTITLE 1,Extracting timestamp for date_refresh
def extract_timestamps_from_folders(base_path, folders_to_skip=None):
    timestamps = []

    if folders_to_skip is None:
        folders_to_skip = []

    for folder_info in dbutils.fs.ls(base_path):
        if folder_info.isDir():
            folder_path = folder_info.path

            # Check if the folder should be skipped
            if any(skip_folder in folder_path for skip_folder in folders_to_skip):
                print(f"Skipping folder: {folder_path}")
                continue

            files_in_folder = dbutils.fs.ls(folder_path)

            # Extract timestamps
            for file_info in files_in_folder:
                split_path = os.path.basename(file_info.path)

                file_name_pattern = re.compile("(?P<date_time_stamp>\d{8}T\d{6})?\.parquet\.gzip")
                file_match = file_name_pattern.search(split_path)

                if file_match:
                    date_time_stamp_string = file_match.group('date_time_stamp')

                    if date_time_stamp_string:
                        load_timestamp_cr_str = str(date_time_stamp_string)
                        load_timestamp_cr_datetime = dt.strptime(load_timestamp_cr_str, '%Y%m%dT%H%M%S')
                        # print(load_timestamp_cr_datetime)
                        timestamps.append(load_timestamp_cr_datetime)
                    # else:
                    #     print("No timestamp found")
                else:
                    print("No match found")

    return timestamps




# COMMAND ----------

# DBTITLE 1,Rmcm table info from value for rollback purposes
def get_rmcm_tables_for_values(catalog_name,value_lists):
    
    rmcm_tables_result = []

    
    for item in value_lists:
        table_name = item['table_name']
        values = item['values']

        
        for value in values:
            # Extract schema from the value
            schema_name = value.split('.')[0]

            

            # Get tables with "rmcm" prefix in the schema
            table_query = f"SHOW TABLES IN {catalog_name}.`{schema_name}`"
            tables_in_schema = [row.tableName for row in spark.sql(table_query).collect()]

            # Filter tables that start with "rmcm_"
            rmcm_tables_in_schema = list(filter(lambda t: t.startswith("rmcm_"), tables_in_schema))

            # Check if there are any RMCM tables before appending to the result list
            if rmcm_tables_in_schema:
                rmcm_tables_result.append({"schema": value, "table_name": table_name,})
                

    return rmcm_tables_result

# COMMAND ----------

# DBTITLE 1,Rmcm table info from whole prod catalog for rollback purposes
def get_rmcm_tables(catalog_name, excluded_schemas):
    all_schemas_query = f"SHOW DATABASES IN {catalog_name}"
    all_schemas = [row.databaseName for row in spark.sql(all_schemas_query).collect()]

    # Exclude specified schemas
    filtered_schemas = [schema for schema in all_schemas if schema.lower() not in excluded_schemas]

    rmcm_tables_result = []

    # Get tables with "rmcm" prefix in each schema
    for schema_name in filtered_schemas:
        table_query = f"SHOW TABLES IN {catalog_name}.`{schema_name}`"
        tables_in_schema = [row.tableName for row in spark.sql(table_query).collect()]

        # Filter tables that start with "rmcm_"
        rmcm_tables_in_schema = list(filter(lambda table: table.startswith("rmcm_"), tables_in_schema))

        if rmcm_tables_in_schema:
            rmcm_tables_result.extend([{"schema": schema_name.upper(), "table_name": table_name} for table_name in rmcm_tables_in_schema])

    return rmcm_tables_result


# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      pass
