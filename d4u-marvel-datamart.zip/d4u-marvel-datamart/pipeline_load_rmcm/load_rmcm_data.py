# Databricks notebook source
pipeline_environment = dbutils.widgets.get("pipelineEnvironment")
jobId = dbutils.widgets.get("job_id")
runId = dbutils.widgets.get("run_id")
studyId = dbutils.widgets.get("studyId")
studyEnvironment = dbutils.widgets.get("environment")
batch_id =  dbutils.widgets.get("batchId")
accept_metadata_change = dbutils.widgets.get("accept_metadata_change")


study_id = studyId
source_data_model = dbutils.widgets.get("data_model")
lifecycle = studyEnvironment
job_id = jobId
run_id = runId
study_environment=studyEnvironment


# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rmcm

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ./rmcm_util

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/lineage_utils

# COMMAND ----------

import os
import re
import boto3
import json
from datetime import datetime as dt 
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
import time
from pyspark.sql import functions as F
dt.now()

from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql.functions import lit, md5, regexp_extract
import datetime
#from datetime import datetime
from pyspark.sql.types import StructType, StructField, IntegerType, StringType


# COMMAND ----------

job_name = "N/A"
today = dt.now()
load_timestamp = today.strftime("%Y-%m-%d %H:%M:%S")
domainStats ={} 


# COMMAND ----------

# DBTITLE 1,Extraction of paths and foldernames 
full_paths = [folder_info.path for folder_info in dbutils.fs.ls(f"{s3_mountpoint}/rmcm/") if folder_info.isDir()]

# List subfolders in the base folder
folder_list = [folder_info.name[:-1] for folder_info in dbutils.fs.ls(f"{s3_mountpoint}/rmcm/") if folder_info.isDir()]


# COMMAND ----------

catalog_name = "marvel-prod-gold"
schema_name = "rmcm"
base_folder = schema_name

# COMMAND ----------

# DBTITLE 1,Setting trg file to ipr
rename_if_file_exists(s3_access_key, s3_secret_key, aws_region, s3_bucket_name,base_folder, 'rmcm.trg','rmcm.ipr')

# COMMAND ----------

# DBTITLE 0,Schema comparison
excluded_tables = ["file_processed_audit"]

excluded_columns = ["D4U_RECID", "D4U_RECVERDATE", "D4U_RECVER"]

excluded_paths_list = [str(s3_mountpoint)+"/rmcm/temp/"]
mismatched_schemas = []

# Check if the schema exists before proceeding
query = f"SHOW SCHEMAS IN `{catalog_name}` LIKE '{schema_name}'"
result = spark.sql(query)
schema_exists = result.count() > 0

if schema_exists:
    # Read Parquet and Delta details
    result_details = read_parquet_and_store_details(full_paths, excluded_paths_list)
    result_details_delta = read_delta_and_store_details(catalog_name, schema_name, excluded_tables, excluded_columns)

    # Check if both Parquet and Delta table schemas exist
    if result_details and result_details_delta:
        # Compare schemas
        for table_name, details_schema in result_details.items():
            if table_name in result_details_delta:
                delta_schema = result_details_delta[table_name]

                if details_schema != delta_schema:
                    file_mismatched_columns = [col for col in details_schema if details_schema[col] != delta_schema.get(col)]
                    table_mismatched_columns = [col for col in delta_schema if delta_schema[col] != details_schema.get(col)]
                    mismatched_columns = list(set(file_mismatched_columns + table_mismatched_columns))
                    error_message = f"Schema mismatch for table {table_name}. Mismatched Columns: {mismatched_columns}"
                    mismatched_schemas.append(error_message)

        # Print or handle mismatched schemas
        if len(mismatched_schemas)>0:
            print(f"Schema mismatches found, {mismatched_schemas}")
            if accept_metadata_change == "True":
                print("User selected 'True' for accept_metadata_change flag to continue..")                
            else:
                error_msg = "Schema mismatches found"
                update_audit_log(batch_id, jobId, runId, studyId, studyEnvironment, "FAILED", error_msg)
                errant_tables = "N/A" 
                message = build_clinical_study_json(studyId,errant_tables,studyEnvironment,jobId,runId,load_timestamp,"",error_msg,{})
                send_notification(studyId,studyEnvironment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
                raise ValueError(f"Schema mismatches found for {mismatched_schemas}, please select 'True' for 'accept_metadata_change' flag and manually re-run the job..")             
        else:
            print("All schemas match.")    
else:
    print("skipping schema comparison as its an intial load")

# COMMAND ----------

# DBTITLE 1,Extracting timestamp for date_refresh
base_path = f"{s3_mountpoint}/rmcm/"


folders_to_skip = ["temp"]

timestamps = extract_timestamps_from_folders(base_path, folders_to_skip)

# Find max timestamp
if timestamps:
    max_timestamp = max(timestamps)
    formatted_timestamp_str = max_timestamp.strftime("%Y-%m-%dT%H:%M:%S")

    # print(f"max_timestamp: {max_timestamp}")
    print(f"formatted_timestamp_str: {formatted_timestamp_str}")
else:
    print("No timestamps found.")

# COMMAND ----------

import threading
from concurrent.futures import ThreadPoolExecutor

success_list = []
failure_list = []
empty_tables = []

# Create locks for accessing shared lists
success_lock = threading.Lock()
failure_lock = threading.Lock()


# Check if the schema exists
query = f"SHOW SCHEMAS IN `{catalog_name}` LIKE '{schema_name}'"
result = spark.sql(query)
schema_exists = result.count() > 0

if not schema_exists:
    # Create schema
    spark.sql(f"CREATE SCHEMA `{catalog_name}`.`{schema_name}`")
    print("Schema created")


paths_to_skip = [
    f"dbfs:"+str(s3_mountpoint)+"/rmcm/bv_ora_eccdb_v_ora_missing_pages_hist/",
    f"dbfs:"+str(s3_mountpoint)+"/rmcm/co_missing_pages_hist/",
    f"dbfs:"+str(s3_mountpoint)+"/rmcm/temp/"
    
]
# Filter the paths to exclude
filtered_paths = list(filter(lambda path: path not in paths_to_skip, full_paths))

folders_to_skip = [
    "bv_ora_eccdb_v_ora_missing_pages_hist",
    "co_missing_pages_hist",
    "temp"
    
]
# Filter the paths to exclude
folders_list = list(filter(lambda path: path not in folders_to_skip, folder_list))

# Check for empty source data files
for folder_path in full_paths:
    if any(folder_path==i for i in paths_to_skip):
        print(f"Skipping folder: {folder_path}")
        continue
    
    print(f"Processing folder: {folder_path}")
    df = spark.read.parquet(folder_path)
    if df.count() == 0:
        empty_tables.append(folder_path)
    else:
        continue

if empty_tables:
    print(f"Empty source data files found, {empty_tables}")
    error_msg = "Empty source data files found"
    update_audit_log(batch_id, jobId, runId, studyId, studyEnvironment, "FAILED", error_msg)
    errant_tables = "N/A" 
    message = build_clinical_study_json(studyId,errant_tables,studyEnvironment,jobId,runId,load_timestamp,"",error_msg,{})
    send_notification(studyId,studyEnvironment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise ValueError(f"Empty source data files found for: {empty_tables}, please fix source data files in landing zone and manually trigger a new load..")


def process_folder(folders_list, filtered_paths):
    try:
        create_delta_table(folders_list, filtered_paths)
        with success_lock:
            success_list.append(folders_list)
    except Exception as e:
        print(f"Error in process for folder {folders_list} and path {filtered_paths}: {str(e)}")
        with failure_lock:
            failure_list.append(folders_list)

# Determine the number of threads based on the length of the folder list
num_threads = len(folders_list) # Adjust the maximum number of threads as needed

# Use ThreadPoolExecutor to execute process_folder in multiple threads
with ThreadPoolExecutor(max_workers=num_threads) as executor:
    for folder, path in zip(folders_list, filtered_paths):
        executor.submit(process_folder, folder, path)

# Wait for all threads to complete
# Note: This block will only proceed after all tasks submitted to the executor are finished
print("Success list:", success_list)
print("Failure list:", failure_list)

# Check if failure_list has any entries
if failure_list:
    # If there are failures, perform the necessary actions
    file_ext= "err"
    msg= "Cummulative_load_failed"
    base_folder= 'rmcm.ipr'
    s3_folder = 'rmcm'
    error_msg = msg
    rename_file(s3_access_key, s3_secret_key, aws_region, s3_bucket_name,s3_folder,base_folder,error_msg,file_ext)
    
    update_audit_log(batch_id, jobId, runId, studyId, studyEnvironment, "FAILED", error_msg)
    errant_tables = "N/A" 
    domainstats={}
    message = build_clinical_study_json(studyId,errant_tables,studyEnvironment,jobId,runId,load_timestamp,"",error_msg,domainstats)
    send_notification(studyId,studyEnvironment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise Exception(f"Error processing folders.{failure_list}")


# COMMAND ----------

# DBTITLE 1,Incremental load
# proper Functions
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql.functions import lit, md5, regexp_extract
import datetime
from datetime import datetime
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

#original flow
#Check if file_processed audit table exist if not run full load

try:
    # Check if file_processed audit table exists; if not, run full load
    bv_hist_file=file_exists(base_path+"bv_ora_eccdb_v_ora_missing_pages_hist")
    co_hist_file=file_exists(base_path+"co_missing_pages_hist")
    catalog_name = "marvel-prod-gold"
    schema_name = "rmcm"
    file_processed_table = "file_processed_audit"
    co_hist_table = "co_missing_pages_hist"
    bv_hist_table = "bv_ora_eccdb_v_ora_missing_pages_hist"
    print(f"file exist:{bv_hist_file},{co_hist_file}")
    
    schema = StructType([
        StructField("path", StringType(), True),
        StructField("batch_id", StringType(), True),
        StructField("path_hash", StringType(), True),
        StructField("domain", StringType(), True),
        StructField("year", StringType(), True),
        StructField("month", StringType(), True),
        StructField("date", StringType(), True)
    ])
    createTableIfNotExist(catalog_name, schema_name, file_processed_table, schema=schema)

    if bv_hist_file == True:
        print(f"bv_hist_file:{bv_hist_file}")
        df = spark.sql(f"select * from `{catalog_name}`.`{schema_name}`.`{file_processed_table}` where domain='bv_hist' limit 10")
        count = df.count()

        if count == 0:
            print("Record count in file_processed_audit table is 0. Triggering initial load")
            initial_load()
        else:
            current_year = get_current_year()
            year_list=[current_year-1]
            bv_hist_df = compare_file_processed(year_list, bv_hist_table, batch_id, "bv_hist", file_processed_table, schema)
  
        # bv_hist data ingestion
            bv_hist_path_list = [row.path for row in bv_hist_df.select('path').collect()]
            for bc_hist_path in bv_hist_path_list:
            # implement ingestion
                print(f"loading {bv_hist_table} path {bc_hist_path}")
                ingest_delta_table(bv_hist_table, bc_hist_path)
            bv_hist_df.write.format("delta").mode("append").saveAsTable(f"`{catalog_name}`.`{schema_name}`.`{file_processed_table}`")

    if co_hist_file == True:    
        print(f"co_hist_file:{co_hist_file}")
        df = spark.sql(f"select * from `{catalog_name}`.`{schema_name}`.`{file_processed_table}` where domain='co_hist' limit 10")
        count = df.count()

        if count == 0:
            print("Record count in file_processed_audit table is 0. Triggering initial load")
            initial_load()
        else:
            current_year = get_current_year()
            year_list=[current_year-1]
            co_hist_df = compare_file_processed(year_list, co_hist_table, batch_id, "co_hist", file_processed_table, schema)
            co_hist_path_list = [row.path for row in co_hist_df.select('path').collect()]
            for co_hist_path in co_hist_path_list:
            # implement ingestion
                print(f"loading {co_hist_table} path {co_hist_path}")
                ingest_delta_table(co_hist_table, co_hist_path)
            co_hist_df.write.format("delta").mode("append").saveAsTable(f"`{catalog_name}`.`{schema_name}`.`{file_processed_table}`")
       
        
        #processed_file_df = bv_hist_df.union(co_hist_df)  

except Exception as e:
    print(f"An error occurred: {str(e)}")
    file_ext= "err"
    msg= "incremental_load_failed"
    base_folder= 'rmcm.ipr'
    s3_folder = 'rmcm'
    error_msg = msg
    rename_file(s3_access_key, s3_secret_key, aws_region, s3_bucket_name,s3_folder,base_folder,error_msg,file_ext)
    update_audit_log(batch_id, jobId, runId, studyId, studyEnvironment, "FAILED", error_msg)
    errant_tables = "N/A" 
    message = build_clinical_study_json(studyId,errant_tables,studyEnvironment,jobId,runId,load_timestamp,"",error_msg,{})
    send_notification(studyId,studyEnvironment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")

# COMMAND ----------

dbutils.jobs.taskValues().set(key="pipeline_environment", value=pipeline_environment)
dbutils.jobs.taskValues().set(key="batch_id", value=batch_id)
dbutils.jobs.taskValues().set(key="study_id", value=studyId)
dbutils.jobs.taskValues().set(key="environment", value=studyEnvironment)
dbutils.jobs.taskValues().set(key="job_id", value=jobId)
dbutils.jobs.taskValues().set(key="run_id", value=runId)
dbutils.jobs.taskValues().set(key="load_timestamp", value=load_timestamp)
dbutils.jobs.taskValues().set(key="formatted_timestamp_str", value=formatted_timestamp_str)

# COMMAND ----------

delta_lake = "gold"
catalog_marvel = "marvel"
schema_marvel = "default"
audit_log_table = "audit_log"

catalog_name = f"{catalog_marvel}-{lifecycle}-{delta_lake}"
relationship_full_table_name = f"`{catalog_name}`.`{study_id}`.`{relationship_table_name}`" 

# COMMAND ----------

# Create d4u_lineage table
try:
    create_table(catalog_name, study_id, relationship_table_name)
except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    raise e


# COMMAND ----------

# Execute Core LINEAGE processing
print("Core listing LINEAGE creation started..")
try:
    records = get_marvel_study_listing_config(study_id, lifecycle, 'Core', source_data_model)
    core_listing_table_names = [row["listing_name"] for row in records]
    print(core_listing_table_names)

    if len(core_listing_table_names) > 0:
        manage_self_lineage_relationships(core_listing_table_names, catalog_name, study_id, relationship_table_name, source_data_model)
       
except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    raise e
