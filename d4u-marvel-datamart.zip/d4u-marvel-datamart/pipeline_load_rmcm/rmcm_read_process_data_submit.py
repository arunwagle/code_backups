# Databricks notebook source
import re
import os
import json
import requests
import datetime
from datetime import datetime as dt
from pyspark.sql.functions import *
import traceback

pipeline_environment = dbutils.widgets.get("pipelineEnvironment").lower()
databricks_instance = dbutils.widgets.get("databricksInstance")
study_data_job_id = dbutils.widgets.get("processStudyJobId")
# # submit_job_id = dbutils.widgets.get("job_id")
# # submit_run_id = dbutils.widgets.get("run_id")
today = dt.now()
load_timestamp = today.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rmcm

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../utils/jobs_util

# COMMAND ----------

# MAGIC %run ../utils/date_util

# COMMAND ----------

# MAGIC %run ../utils/file_util

# COMMAND ----------

# DBTITLE 1,Build & Call Process Clinical Study Job API
# Intialize audit log table based on environment variable
initialize_audit_log_table(catalog_marvel, schema_marvel, audit_log_table)

logger.info(f"Checkpoint Table: {checkpoint_table}")
checkpoint_query = f"""
    SELECT study_id, path, file_arrival_timestamp, is_processed 
    FROM {checkpoint_table} 
    WHERE is_processed = 0
    ORDER BY file_arrival_timestamp ASC"""

df_checkpoint_data = spark.sql(checkpoint_query)

file_path_trim_part = f"s3a://{s3_bucket_name}"

global batch_id

file_count = df_checkpoint_data.count()

if file_count > 0:
    logger.info(f'Found {file_count} files to process')
    display(df_checkpoint_data.groupBy('study_id').count())

    studies = groups = [x[0] for x in df_checkpoint_data.select("study_id").distinct().collect()]

    for study_id in studies:
        logger.info('')
        logger.info('')

        study_df = df_checkpoint_data.filter(col('study_id') == study_id).orderBy(col('file_arrival_timestamp'))
        study_files = list(study_df.toPandas()['path'])

        if study_id is None:
            logger.error(f'Files with no study found: {study_files}')
            checkpoint_update_query = f"""
                UPDATE {checkpoint_table} SET 
                is_processed = 1, 
                job_id = '{study_data_job_id}' 
                WHERE study_id IS NULL
            """
            logger.info(f'Running update query: {checkpoint_update_query}')
            execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")
            continue

        logger.info(f'Found {len(study_files)} files for study {study_id}')

        if len(study_files) > 50:
            logger.info('Limiting batch of study files to 50')
            study_files = study_files[:50]

        logger.info(f'study_files: {study_files}')

        # Study File Name format Validation
        try:
            environment = 'prod'

            # Checking if study run already exists
            run_exist = study_run_exist(study_id=study_id, job_id=study_data_job_id)

            if run_exist is True:
                logger.info(f'Skipping files for study {study_id} as there is already another job running.')
                continue

            # Parse Study File Name
            checkpoint_update_query = f"""
                UPDATE {checkpoint_table} SET 
                    study_id = '{study_id}', 
                    environment = '{environment}', 
                    process_start_timestamp = '{load_timestamp}' 
                    WHERE path IN ({','.join([f"'{x}'" for x in study_files])})"""

            logger.info(f'Running update query: {checkpoint_update_query}')
            execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")

            batch_id = create_audit_log(study_data_job_id, job_name, study_id, environment, load_timestamp)

            study_files_mnt = list(map(lambda x: x.replace(file_path_trim_part, s3_mountpoint), study_files))

            data = {
                "job_id": study_data_job_id,
                "notebook_params": {
                    "studyFilePath": json.dumps(study_files_mnt),
                    "pipelineEnvironment": pipeline_environment,
                    "batchId": batch_id,
                    "studyId": study_id,
                    "data_model": "RMCM" ,
                    "environment": environment,
                    "loadTimestamp": load_timestamp
                }
            }

            jobs_response = create_job_run(data)

            if jobs_response.status_code == 200:
                logger.info("Job has been triggered successfully")

                retry = 3

                while retry > 0:
                    runs_response = list_job_runs(job_id=study_data_job_id, active_only=True)

                    if runs_response.status_code == 200:
                        runs_response_json = runs_response.json()
                        if "runs" in runs_response_json:
                            response_list = runs_response_json["runs"]

                            if len(response_list) > 0:
                                current_run_id = response_list[0]["run_id"]

                            if current_run_id is None:
                                logger.info(f'Failed to parse run id. Waiting 5sec and Retrying')
                                retry -= 1
                                time.sleep(5)
                                continue

                            logger.info(f"Job submitted for study files with run_id: {current_run_id} for {environment} environment")

                            # Update run id into the audit log table
                            update_audit_log_run_id(batch_id, current_run_id, "STARTED")

                            # Update study process flag in the checkpoint table
                            checkpoint_update_query = f"""
                                UPDATE {checkpoint_table} SET 
                                is_processed = 1, 
                                job_id = '{study_data_job_id}', 
                                run_id = {current_run_id}, 
                                process_start_timestamp = '{load_timestamp}' 
                                WHERE path IN ({','.join([f"'{x}'" for x in study_files])}) and environment='{environment}'"""

                            logger.info(f'Running update query: {checkpoint_update_query}')
                            execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")

                            logger.info(f"Checkpoint table updated for run_id: {current_run_id}")

                            break

                        else:
                            logger.info("No active runs exist")
                    else:
                        logger.info("Get active runs API call is not successful")

                    retry -= 1
            else:
                logger.info(f"Submit job run for study {study_id} is not successful: {jobs_response.json()}")
                update_audit_log_by_batch_id(batch_id, "FAILED", "API call to submit job has failed")

        except Exception as e:
            error_msg = str(e)
            error_msg = error_msg.replace("'", "").replace("\"", "")
            logger.error(error_msg)
            logger.error(repr(traceback.format_exc(e)))

            update_audit_log_by_batch_id(batch_id, "FAILED", error_msg)

            errant_tables = "N/A"

            study_environment = 'prod'

            domainstats = {}
            message = build_clinical_study_json(study_id, errant_tables, study_environment, study_data_job_id, "",
                                                 load_timestamp, data_source, error_msg, domainstats)

            send_notification(study_id, study_environment, "Failed", admin_user_recipients, message, vpc_name, "NA",
                               "", "", "", "")
            raise e
            dbutils.notebook.exit(error_msg)
else:
    logger.info("No study file exists to process")

