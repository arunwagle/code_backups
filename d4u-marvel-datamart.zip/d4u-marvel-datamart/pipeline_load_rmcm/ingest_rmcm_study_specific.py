# Databricks notebook source
import requests
import json
import base64
from pathlib import Path, PurePath
import os

# COMMAND ----------

dbutils.widgets.text("data_model", "RMCM")

# COMMAND ----------

pipeline_environment = dbutils.jobs.taskValues().get(taskKey="load_data", key="pipeline_environment", default="", debugValue="release")
batch_id = dbutils.jobs.taskValues().get(taskKey="load_data", key="batch_id", default="", debugValue="asdf")
study_id = dbutils.jobs.taskValues().get(taskKey="load_data", key="study_id", default="error", debugValue="RMCM")
studyEnvironment = dbutils.jobs.taskValues().get(taskKey="load_data", key="environment", default="error", debugValue="prod")
studyEnvironment="prod"
jobId = dbutils.jobs.taskValues().get(taskKey="load_data", key="job_id", default="", debugValue="12345")
runId = dbutils.jobs.taskValues().get(taskKey="load_data", key="run_id", default="error", debugValue="1")
load_timestamp = dbutils.jobs.taskValues().get(taskKey="load_data", key="load_timestamp", default="", debugValue="06/04/2025T03:28:00-04:00")
batch_id = dbutils.jobs.taskValues().get(taskKey="load_data", key="batch_id", default="", debugValue="xyz")
formatted_timestamp_str = dbutils.jobs.taskValues().get(taskKey="load_data", key="formatted_timestamp_str", default="", debugValue="06/04/2025T03:28:00-04:00")
# formatted_timestamp_str= "2028-01-10T10:28:28"


source_data_model = dbutils.widgets.get("data_model")
lifecycle = studyEnvironment
job_id = jobId
run_id = runId
study_environment=studyEnvironment
studyId=study_id

catalog_name = "marvel-prod-gold"

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rmcm

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ./rmcm_util

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

# MAGIC %run ../utils/lineage_utils

# COMMAND ----------

# MAGIC %run ../programmed_listing_notebooks/dre_utils

# COMMAND ----------

import os
import re
import boto3
import json
from datetime import datetime as dt 
from concurrent.futures import ThreadPoolExecutor
import time
from pyspark.sql import functions as F

# COMMAND ----------

from pyspark.sql.utils import AnalysisException

session_user = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()

def write_data_to_table(catalog_name, schema_name, table_name, study_var, study):
    try:
        # Build the filtered SELECT
        query = f"""
        SELECT * 
        FROM `{catalog_name}`.`{schema_name}`.`{table_name}`
        WHERE {study_var} = '{study}'
        """
        df = spark.sql(query)
        row_count = df.count()

        # If no rows, still write an empty table using the schema of the source table
        if row_count == 0:
            # print(f"[INFO] No matching records for {study}.{table_name}. Creating empty table.")

            # Get the schema from the source table
            df = spark.sql(f"SELECT * FROM `{catalog_name}`.`{schema_name}`.`{table_name}` LIMIT 0")
        # else:
            # print(f"[INFO] {row_count} matching records for {study}.{table_name}.")

        # Try to overwrite, if failed to merge the drop and overwrite
        target_table = f"`{catalog_name}`.`{study}`.`{table_name}`"
        try:
            df.write.mode("overwrite") \
                .format("delta") \
                .option("mergeSchema", "true") \
                .option("delta.columnMapping.mode", "name") \
                .option("delta.minReaderVersion", "2") \
                .option("delta.minWriterVersion", "5") \
                .saveAsTable(target_table)
        except AnalysisException as ae:
            print(f"[ERROR] AnalysisException: {str(ae)}")
            if "Failed to merge fields" in str(ae):
                print(f"[WARN] Schema mismatch in {target_table}, taking ownership and recreating")
                spark.sql(f"ALTER TABLE {target_table} OWNER TO `{session_user}`")
                spark.sql(f"DROP TABLE IF EXISTS {target_table}")
                df.write.mode("overwrite") \
                    .format("delta") \
                    .option("mergeSchema", "true") \
                    .option("delta.columnMapping.mode", "name") \
                    .option("delta.minReaderVersion", "2") \
                    .option("delta.minWriterVersion", "5") \
                    .saveAsTable(target_table)
            else:
                raise ae

        return ("success", {
            "study": study,
            "table": table_name,
            "rows_written": row_count
        })

    except Exception as e:
        return ("failure", {
            "study": study,
            "table": table_name,
            "error_type": type(e).__name__,
            "error_message": str(e)
        })


# COMMAND ----------

# DBTITLE 1,Find valid studyid values in all rmcm.rmcm_* tables and compare against existing UC schemas
try:
    schema_name = "rmcm"
    schema_name_upper = schema_name.upper()

    # Step 1: Get list of available schemas in catalog
    schema_query = f"SHOW DATABASES IN `{catalog_name}`"
    schema_names = set([row.databaseName.upper() for row in spark.sql(schema_query).collect()])
    print(f"Available schemas: {schema_names}\n")

    # Step 2: Get list of rmcm_ tables
    spark.sql(f"USE `{catalog_name}`.{schema_name_upper}")
    table_query = f"SHOW TABLES IN {schema_name_upper}"
    tables = spark.sql(table_query)
    rmcm_table_names = [row.tableName for row in tables.collect() if row.tableName.startswith("rmcm_")]
    print(f"rmcm tables: {rmcm_table_names}\n")

    # Step 3: Gather valid studyids across all rmcm tables, filtered by existing schemas
    valid_studyids = set()

    for table_name in rmcm_table_names:
        try:
            df = spark.table(f"`{catalog_name}`.`{schema_name_upper}`.{table_name}")
            if "studyid" in df.columns:
                distinct_studyids_df = df.selectExpr("upper(studyid) as studyid").distinct()
                studyids_filtered = [row["studyid"] for row in distinct_studyids_df.collect() if row["studyid"] in schema_names]
                valid_studyids.update(studyids_filtered)
            else:
                print(f"[WARN] {table_name} skipped — no 'studyid' column")
        except Exception as e:
            print(f"[ERROR] Failed reading from {table_name}: {e}\n")

    print(f"Valid studyids: {valid_studyids}\n")

except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, "RMCM", study_environment, "FAILED", error_msg)
    raise e

# COMMAND ----------

# DBTITLE 1,Write the RMCM data to the studies
try:
    with ThreadPoolExecutor(max_workers=len(rmcm_table_names)) as executor:
        futures = [
            executor.submit(write_data_to_table, catalog_name, schema_name, table_name, "studyid", study)
            for table_name in rmcm_table_names
            for study in valid_studyids
        ]

    # Gather and separate results
    results = [future.result() for future in futures]
    completed_list = [msg for status, msg in results if status == "success"]
    failure_list = [msg for status, msg in results if status == "failure"]

    print("Completed Messages:", completed_list)
    print("Failure Messages:", failure_list)
    print("Data writing completed.")

except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, "RMCM", study_environment, "FAILED", error_msg)
    raise e

# COMMAND ----------

# DBTITLE 1,Stats & send notification
# I'm not sure why this is here but I'm afraid to remove it.
spark.sql("set spark.sql.ansi.enabled = false")

# COMMAND ----------

# DBTITLE 1,Create the d4u_lineage table in each study
# Loop through each study value and each table
for x in valid_studyids:
    try:
        # Create d4u_lineage table
        create_table(catalog_name, x, relationship_table_name)

        # Execute Core LINEAGE processing
        records = get_marvel_study_listing_config(x, lifecycle, 'Core', source_data_model)
        core_listing_table_names = [row["listing_name"] for row in records]

        if len(core_listing_table_names) > 0:
            print(core_listing_table_names)
            manage_self_lineage_relationships(core_listing_table_names, catalog_name, x, relationship_table_name, source_data_model)

    except Exception as e:
        error_msg = str(e)
        error_msg = error_msg.replace("'","").replace("\"","")
        update_audit_log(batch_id, job_id, run_id, x, study_environment, "FAILED", error_msg)
        raise e

# COMMAND ----------

# DBTITLE 1,Trigger the basic listings in the global RMCM study
# TODO This, along with the EventBridge notification for the RMCM global study, should be moved to the first task in the workflow
try:
    records = get_basic_listing_config(studyId, study_environment, "RMCM")
    if len(records) > 0:
        source_job_name = "submit_process_basic_listings"
        listing_job_id = dbutils.widgets.get("basic_prog_listing_jobid")
        lifecycle = study_environment
        devMode = "True"
        dataModel = "RMCM"
        api_call = api_submit_job()  
    else:
        print(f"No basic listing found for study : {studyId}")
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, "RMCM", study_environment, "FAILED", error_msg)
    raise e

# COMMAND ----------

# DBTITLE 1,Trigger the basic listings in each study that received RMCM data
for studyId in valid_studyids:
    try:
        records=get_basic_listing_config(studyId, study_environment, "RMCM")
        if len(records) > 0:
            source_job_name = "submit_process_basic_listings"
            listing_job_id = dbutils.widgets.get("basic_prog_listing_jobid")
            lifecycle=study_environment
            devMode="True"
            dataModel="RMCM"
            api_call = api_submit_job()  
        else:
            print(f"No basic listing found for study : {studyId}")
    except Exception as e:
        error_msg = str(e)
        error_msg = error_msg.replace("'","").replace("\"","")
        update_audit_log(batch_id, job_id, run_id, studyId, study_environment, "FAILED", error_msg)
        raise e

# COMMAND ----------

# DBTITLE 1,Delete Trigger and Update Audit Log
base_folder= 'rmcm.ipr'
s3_folder = 'rmcm'
error_msg = s3_folder
delete_file(s3_access_key, s3_secret_key, aws_region, s3_bucket_name,s3_folder,base_folder)
job_status = "SUCCESS"
update_audit_log(batch_id, jobId, runId, study_id, studyEnvironment, job_status, "Job has been executed successfully")

# COMMAND ----------

# DBTITLE 1,Send one notification to AWS for the Global study
# TODO This, along with the programmed listing submission for the RMCM global study, should be moved to the first task in the workflow
try:
    rmcm_rows = []

    for table_name in rmcm_table_names:
        full_table_name = f"`{catalog_name}`.`RMCM`.`{table_name}`"
        try:
            count = spark.read.table(full_table_name).count()
        except Exception as e:
            print(f"[WARN] Could not count records in {full_table_name}: {e}")
            count = 0

        rmcm_rows.append((
            f"{table_name}",
            0,  # dropped
            count,
            0,  # updated
            "meta_change:n/a,added_columns:n/a"
        ))

    schema = ["table", "drop", "insert", "updated", "metadata_change"]
    rmcm_df = spark.createDataFrame(rmcm_rows, schema=schema)
    rmcm_domainStats = build_domain_statistics_dictionary(rmcm_df)

    rmcm_message = build_clinical_study_json(
        study_id="RMCM",
        errant_tables="",  # none expected
        study_environment=studyEnvironment,
        job_id=jobId,
        run_id=runId,
        time=formatted_timestamp_str,
        source=data_source,
        msg="Success",
        domainstats=rmcm_domainStats
    )

    print(rmcm_message)

    send_notification(
        "RMCM",
        studyEnvironment,
        "Success",
        admin_user_recipients,
        rmcm_message,
        vpc_name,
        "NA",
        "",
        "",
        "",
        ""
    )

except Exception as e:
    error_msg = str(e).replace("'", "").replace('"', "")
    print(f"[ERROR] Failed to build RMCM notification: {error_msg}")


# COMMAND ----------

# DBTITLE 1,Send one notification to AWS per study
try:
    row_count_lookup = {
        (entry["study"], entry["table"]): entry["rows_written"]
        for entry in completed_list
    }

    schema = ["table", "drop", "insert", "updated", "metadata_change"]

    for study_id in valid_studyids:
        df_rows = []

        # Filter and format error messages just for this study
        errant_messages = [
            f"{entry['table']}: {entry['error_type']}"
            for entry in failure_list
            if entry["study"] == study_id
        ]

        for table_name in rmcm_table_names:
            key = (study_id, table_name)
            if key in row_count_lookup:
                df_rows.append((
                    f"{table_name}",
                    0,  # dropped
                    row_count_lookup[key],
                    0,  # updated
                    "meta_change:n/a,added_columns:n/a"
                ))

        df = spark.createDataFrame(df_rows, schema=schema)
        domainStats = build_domain_statistics_dictionary(df)

        message = build_clinical_study_json(
            study_id=study_id,
            errant_tables='|'.join(errant_messages),
            study_environment=studyEnvironment,
            job_id=jobId,
            run_id=runId,
            time=formatted_timestamp_str,
            source=data_source,
            msg="Success",
            domainstats=domainStats
        )

        print(message)

        send_notification(
            study_id,
            studyEnvironment,
            "Success",
            admin_user_recipients,
            message,
            vpc_name,
            "NA",
            "",
            "",
            "",
            ""
        )

except Exception as e:
    error_msg = str(e).replace("'", "").replace('"', "")
    update_audit_log(batch_id, job_id, run_id, "RMCM", study_environment, "FAILED", error_msg)
    raise e

