# Databricks notebook source
from pyspark.sql.functions import regexp_replace, md5, concat_ws, array, col, lit, struct, to_json, when, greatest, to_timestamp
from pyspark.sql.types import MapType, StringType, ArrayType, TimestampType
from delta.tables import *
import functools
import re
import operator
from datetime import datetime as dt
from pyspark.sql.functions import to_date,expr
import traceback

# COMMAND ----------

# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rave_inquiries

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

def SavetoSilver(study_schema_name, config_dict, catalog_silver, catalog_gold, table_name, file):
  
    recId_keys= config_dict[f"{table_name}"]['RecIdKeys']
    recver_keys = config_dict[f"{table_name}"]['RecverKey']

    logger.info(f'recId_keys: {recId_keys}')
    logger.info(f'recver_keys: {recver_keys}')
    
    spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")
    spark.conf.set("spark.sql.parquet.enableVectorizedReader",False)

    df=spark.read.parquet(f"{file}/")

    df=df.drop("year", "month", "day", "marvel_integration_timestamp", "date_key")

    df_final=df\
        .withColumn("D4U_RECID",lit(md5(concat_ws("||",*recId_keys))))\
        .withColumn("D4U_RECVER",md5(concat_ws("||",*recver_keys)))\
        .withColumn("D4U_DATAPROV",array(to_json(create_map(lit("table"),lit(table_name),lit("D4U_RECID"),md5(concat_ws("||",*recId_keys)),lit("D4U_RECVER"),md5(concat_ws("||",*recver_keys))))).cast("string"))\
        .withColumn("D4U_RECVERDATE", greatest(to_timestamp(col("created_raw"), "yyyy-MM-dd HH:mm:ss.SSS"), to_timestamp(col("answered_raw"), "yyyy-MM-dd HH:mm:ss.SSS"), to_timestamp(col("resolved_raw"), "yyyy-MM-dd HH:mm:ss.SSS")))\
        .withColumn("D4U_ISACTIVE", lit(True))\
        .withColumn("D4U_ISDROP", lit(False))

    logger.info(f'Received {df_final.count()} records to process')

    df_duplicates = df_final.groupBy(['D4U_RECID', 'D4U_RECVER']).count().where('count > 1')
    duplicate_count = df_duplicates.count()
    if duplicate_count > 0:
        logger.info(f'!! Found {duplicate_count} duplicate records in data !!')
        display(df_duplicates)
        raise Exception('Duplicate records found')

    #Initial Load
    if not (tableExists(catalog_silver,study_schema_name,table_name)):
  
        logger.info('Initial Load')
          
        schema = df_final.schema

        #Creation of Rave inquiry table if not exists in Silver and gold layers
        silver_table = createTableIfNotExist(catalog_silver,study_schema_name,table_name,schema)
        gold_table = createTableIfNotExist(catalog_gold,study_schema_name,table_name,schema)
        
        silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{table_name}`")).alias('silver')
        
        logger.info(f'0 records in silver before merge')
        logger.info(f'Merging {df_final.count():,} records into silver')

        tic = time.perf_counter()
        silverTable.alias("silver").merge(source = df_final.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()
        toc = time.perf_counter()

        logger.info(f'{silverTable.toDF().count():,} records in silver after merge')
        logger.info(f'Merge completed {toc - tic:0.4f} seconds')
    
    #Incremental Load
    else:

        logger.info('Incremental Load')

        column_list = df_final.columns

        silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{table_name}`")).alias('silver')
        
        silver_records = silverTable.toDF().where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
        
        df_insert = df_final.alias("df").join(silver_records,on = 'D4U_RECID',how = 'leftanti').select(['df.*'])
        df_insert = df_insert.select(column_list)

        logger.info(f'{df_insert.count():,} records in to insert')
        
        df_update = silver_records.join(df_final.alias("df"),expr(f"df.D4U_RECID = silver.D4U_RECID and df.D4U_RECVER != silver.D4U_RECVER"),how = 'inner').select(['df.*'])
        df_update = df_update.select(column_list)

        logger.info(f'{df_update.count():,} records in to update')

        # df_drop = silver_records.join(df_final.alias("df"), on = 'D4U_RECID', how = 'leftanti').select(['silver.*'])
        # df_drop = df_drop\
        #     .select(column_list)\
        #     .withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp'))\
        #     .withColumn("D4U_ISACTIVE", lit(True))\
        #     .withColumn("D4U_ISDROP", lit(True))

        # logger.info(f'{df_drop.count():,} records in to drop')
        
        # df_insert_update_drop = df_insert.union(df_update).union(df_drop).cache()
        df_insert_update_drop = df_insert.union(df_update).cache()

        

        logger.info(f'{silverTable.toDF().count():,} records in silver before merge')
        logger.info(f'Merging { df_insert_update_drop.count()} records into silver')

        tic = time.perf_counter()

        #set previous records as false for updated records
        silverTable\
            .alias("silver")\
            .merge(source = df_insert_update_drop.alias("df"), condition = col('df.D4U_RECID') == col('silver.D4U_RECID'))\
            .whenMatchedUpdate(set = {"silver.D4U_ISACTIVE": lit(False)})\
            .execute()

        #insert all new, updated and dropped records
        silverTable\
            .alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID').isNull())\
            .whenNotMatchedInsertAll()\
            .execute()

        toc = time.perf_counter()
        
        logger.info(f'{silverTable.toDF().count():,} records in silver after merge')
        logger.info(f'Merge completed {toc - tic:0.4f} seconds')

# COMMAND ----------

try:  
    study_files = json.loads(dbutils.widgets.get("studyFilePath"))

    logger.info(f'Received {len(study_files)} files')
    
    for file in study_files:
        logger.info(f'Processing file: {file}')
        SavetoSilver(study_schema_name, config_dict, catalog_silver, catalog_gold, table_name, file)


except Exception as e:
    print(repr(traceback.format_exception(e)))
    error_process = "ingest_study_data_silver"       
    error_table = f"{catalog_silver}.{study_schema_name}.{table_name}"
    tables_list=[table_name]
    handle_error(e, error_process, error_table,tables_list)
