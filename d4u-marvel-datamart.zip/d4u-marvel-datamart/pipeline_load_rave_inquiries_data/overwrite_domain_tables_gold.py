# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rave_inquiries

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------


import traceback
from pyspark.sql.functions import cast,col,date_format,max,current_timestamp
from pyspark.sql.types import StringType,BooleanType,DateType
from datetime import datetime as dt 
import os
import time
from delta.tables import DeltaTable
from pyspark.sql.functions import col, max
from pyspark.sql.types import DateType
spark.conf.set('spark.sql.ansi.enabled', False)


def saveToGold(study_schema_name,catalog_gold,catalog_silver,tableName):


    try:
        
        silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
        goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')

        print('Merging silver updates to gold')

        if(goldTable.toDF().count()==0):

          goldTable \
              .merge(
                  source = silverTable, 
                  condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
              ) \
              .whenNotMatchedInsertAll() \
              .execute()

        else: 

          
          silverTable_drop = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == True)).alias('silver_drop')        

          # Delete records updated in silver
          goldTable.merge(
                  source = silverTable, 
                  condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
              ).whenMatchedDelete(
                  condition = col('silver.D4U_RECVER') != col('gold.D4U_RECVER')
              ).execute()

          # Delete Dropped records no in silver DF
          goldTable \
              .merge(
                  source = silverTable_drop, 
                  condition = (col('silver_drop.D4U_RECID') == col('gold.D4U_RECID'))
              ) \
              .whenMatchedDelete(
                  condition = col('silver_drop.D4U_RECVER') == col('gold.D4U_RECVER')
              ) \
              .execute()
          

          # Add all new and updated records
          goldTable \
              .merge(
                  source = silverTable, 
                  condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
              ) \
              .whenNotMatchedInsertAll() \
              .execute()

        
    except Exception as p:
        global error_process
        global error_table
        error_process = "Ingest_data_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
        raise p
  

# COMMAND ----------

try:

  saveToGold(study_schema_name,catalog_gold,catalog_silver,table_name)

  # goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{table_name}`")).alias('gold') 
  # gold_delta_df = goldTable.toDF().alias('gold')
  # load_timestamp_rave = gold_delta_df.select(max(col('factupdatedate').cast(DateType())))
  # load_timestamp_rq = load_timestamp_rave.collect()[0][0]
  
  goldTable = DeltaTable.forName(spark, f"`{catalog_gold}`.`{study_schema_name}`.`dv_rave_edc_queries`")
  max_date_result = spark.sql(f"SELECT MAX(factupdatedate) FROM `{catalog_gold}`.`{study_schema_name}`.`dv_rave_edc_queries`")
  load_timestamp_rq = max_date_result.collect()[0][0]
  print(load_timestamp_rq)

  
  
  load_timestamp_rq_str = str(load_timestamp_rq)
  
  if '.' in load_timestamp_rq_str:
    load_timestamp_rq_datetime = dt.strptime(load_timestamp_rq_str, '%Y-%m-%d %H:%M:%S.%f')
  else:
    load_timestamp_rq_datetime = dt.strptime(load_timestamp_rq_str, '%Y-%m-%d %H:%M:%S')

  formatted_timestamp_str = load_timestamp_rq_datetime.strftime("%Y-%m-%dT%H:%M:%S")

  print(formatted_timestamp_str)

except Exception as e:
  # DJM 4/5/24 cannot pass e in ==> print(repr(traceback.format_exc(e)))
  print(traceback.format_exc())

  error_process = "Ingest_data_gold"       
  error_table = f"{catalog_gold}.{study_schema_name}.{table_name}"
  tables_list=[table_name]
  handle_error(e, error_process, error_table,tables_list)


# COMMAND ----------

dbutils.jobs.taskValues.set(key="formatted_timestamp_str", value=formatted_timestamp_str)

# COMMAND ----------

# job_status = "SUCCESS"
# message = "Pipeline Job %s has been executed successfully" % (job_name)
# # Update audit log
# update_audit_log(batch_id, job_id, run_id, study_id, study_environment, job_status, "Job has been executed successfully")
# #logger.info("Updating process end timstamp in audit log table ")

# COMMAND ----------

# errant_tables = "N/A"
# msg = "Success: The Rave Inquiry data for Study Id - {0} has been processed successfully".format(study_id)
# domainstats={}
# message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,formatted_timestamp_str,data_source,msg,domainstats)
# send_notification(study_id,study_environment,"Success",business_user_recipients,message,vpc_name,"","","","","")
