# Databricks notebook source
# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rave_inquiries

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

# DBTITLE 1,Import libraries for the notebook
import psycopg2
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
from pyspark.sql.window import Window
from pyspark.sql import DataFrame

# COMMAND ----------

def get_marvel_study_lifecycle_edc_query_config(protocol_Number, lifecycle, conn):
    """
    Retrieves the EDC query processing flag for the specified study lifecycle from the database.

    Parameters:
    - protocol_Number (str): The study protocol number.
    - lifecycle (str): The lifecycle.
    - conn (psycopg2.connection): An active connection to the PostgreSQL database.

    Returns:
    - bool: True if the EDC query processing flag is enabled, False otherwise.
    """
    try:
        with conn.cursor() as cursor:
            # Fetch the study lifecycle ID
            query = f"""
                SELECT study_lifecycle_id
                FROM dre.get_latest_study_lifecycle_version('{protocol_Number}', '{lifecycle}')
            """
            print(f"Query DRE database for study lifecycle id: {query}")
            cursor.execute(query)

            row = cursor.fetchone()
            if row:
                study_lifecycle_id = row[0]

                # Fetch the rave query processing flag
                flag_query = f"""
                    SELECT config->'flags'->'rave_query_processing' AS flag
                    FROM dre.study_lifecycle 
                    WHERE id = '{study_lifecycle_id}'
                """
                print(f"Querying flags for study lifecycle id: {study_lifecycle_id}")
                cursor.execute(flag_query)

                flag_row = cursor.fetchone()
                if flag_row:
                    flag_value = flag_row[0]
                    if flag_value is True:
                        return True
                    elif flag_value is False:
                        return False
                    else:
                        print("Unexpected value for flag: ", flag_value)
                        return False
                else:
                    print("No flag found for study_lifecycle_id")
                    return False
            else:
                print("No study_lifecycle_id found in DRE. Returning defaults.")
                return False

    except Exception as e:
        print("An error occurred: ", e)
        return False

# COMMAND ----------

def get_study_listing_config(protocol_number, lifecycle, data_source, connection_string_psycopg2):
    """
    Fetches the study listing configuration for the given protocol and lifecycle.

    Args:
        protocol_number (str): The study protocol number.
        lifecycle (str): The lifecycle/environment (e.g., "dev", "uat", "prod").
        data_source (str): The data source for the study.
        connection_string_psycopg2 (str): The psycopg2 connection string.

    Returns:
        list: A list of records containing the study listing configuration.
    """
    try:
        # Establish a new connection using psycopg2 connection string
        with psycopg2.connect(connection_string_psycopg2) as conn:
            with conn.cursor() as cursor:
                # Fetch the study lifecycle ID
                query = f"""
                    SELECT
                        sl.asset_id AS listing_asset_id,
                        sl.config->>'tableName' AS table_name
                    FROM (
                        SELECT * 
                        FROM dre.get_study_listing_table('{protocol_number}', '{lifecycle}') 
                        WHERE LOWER(config->>'dataModel') = LOWER('{data_source}') 
                        AND (
                            '{lifecycle}' IN ('dev', 'uat') 
                            OR (sla_config->>'is_active')::BOOLEAN
                        )
                    ) sl
                    LEFT JOIN dre.listing_type lt 
                        ON sl.config->>'type' = lt.id::text,
                    JSONB_ARRAY_ELEMENTS(sl.config->'parameters') WITH ORDINALITY arr(item_object, position)
                    WHERE arr.item_object->>'name' = 'fileName' 
                    AND lt.label = 'Core Listing'
                """
                print(f"Querying DRE database for study lifecycle ID:\n{query}")
                cursor.execute(query)

                # Fetch all matching records
                records = cursor.fetchall()

                return records
    except Exception as e:
        print(f"Error while fetching study listing config: {e}")
        return []


# COMMAND ----------

def delete_rave_edc_inbound_and_errors(protocol_Number, lifecycle, conn):
    """
    Deletes records from the `idqm_source.rave_edc_inbound` and `idqm_source.rave_edc_inbound_errors` tables
    for the specified protocol_Number and lifecycle.

    Parameters:
    - protocol_Number (str): The protocol number to match in the WHERE clause.
    - lifecycle (str): The lifecycle to match in the WHERE clause.
    - conn (psycopg2.connection): An active connection to the PostgreSQL database.

    Returns:
    - None
    """
    try:
        with conn.cursor() as cursor:
            # Delete from `rave_edc_inbound` table
            sql_query = "DELETE FROM idqm_source.rave_edc_inbound WHERE LOWER(protocol_num) = LOWER(%s) AND LOWER(lifecycle) = LOWER(%s);"
            cursor.execute(sql_query, (protocol_Number, lifecycle))
            inbound_row_count = cursor.rowcount
            conn.commit()
            print(f"{inbound_row_count} row(s) deleted from rave_edc_inbound successfully.")

            # Delete from `rave_edc_inbound_errors` table
            errors_query = "DELETE FROM idqm_source.rave_edc_inbound_errors WHERE LOWER(protocol_num) = LOWER(%s) AND LOWER(lifecycle) = LOWER(%s);"
            cursor.execute(errors_query, (protocol_Number, lifecycle))
            errors_row_count = cursor.rowcount
            conn.commit()
            print(f"{errors_row_count} row(s) deleted from rave_edc_inbound_errors successfully.")

    except Exception as e:
        print(f"Error during deletion: {e}")

# COMMAND ----------

def fetch_rave_queries(protocol_Number: str, lifecycle: str) -> (DataFrame, DataFrame):
  sql_query = f"""
    SELECT  
        '{protocol_Number}' as protocol_num,  
        CAST(FORMAT_NUMBER(query_id, '###') AS NUMERIC) AS query_id, 
        CAST(querytext AS STRING) as querytext, 
        CAST(FORMAT_NUMBER(requeryforid, '###') AS NUMERIC) AS requeryforid,    
        CAST(studyname AS STRING) AS studyname,    
        CAST(countryregion AS STRING) AS countryregion,    
        CAST(sitenumber AS STRING) AS sitenumber,    
        CAST(subjectname AS STRING) AS subjectname,    
        CAST(folderoid AS STRING) AS folderoid,    
        CAST(FORMAT_NUMBER(recordid, '###') AS STRING) AS recordid,    
        CAST(FORMAT_NUMBER(datapointid, '###') AS STRING) AS datapointid,    
        CAST(field AS STRING) AS field,    
        CAST(fmtcreated AS STRING) AS fmtcreated,   
        CAST(created_raw AS STRING) AS created_raw,    
        CAST(createuser AS STRING) AS createuser,    
        CAST(answereduser AS STRING) AS answereduser,    
        CAST(answertext AS STRING) AS answertext,    
        CAST(answered_raw AS STRING) AS answered_raw,    
        CAST(fmtanswered AS STRING) AS fmtanswered,   
        CAST(resolveduser AS STRING) AS resolveduser,  
        CAST(resolved_raw AS STRING) AS resolved_raw,  
        CAST(fmtresolved AS STRING) AS fmtresolved,   
        CAST(markinggroup AS STRING) AS markinggroup,    
        CAST(status AS STRING) AS status,    
        CAST(recordposition AS STRING) AS recordposition,    
        CAST(formoid AS STRING) as formoid, 
        CAST(instancerepeatnumber AS STRING) as instancerepeatnumber,  
        CAST(crfversionid AS STRING) as crfversionid,
        '{lifecycle}' as lifecycle
    FROM `marvel-{lifecycle.upper()}-gold`.{protocol_Number}.dv_rave_edc_queries
    """
    
  #print(f"Executing Spark SQL Query:\n{sql_query}")
  queries_df = spark.sql(sql_query)
  return queries_df


# COMMAND ----------

def fetch_rave_queries_needing_synchronization(protocol_Number, lifecycle, connection_string, connection_properties) -> int:
    """
    Identifies Rave queries that need synchronization with the `rave_edc_inbound` table in PostgreSQL. 
    Compares source queries from Rave with existing queries in PostgreSQL and filters out unchanged records.

    Parameters:
    - protocol_Number (str): The study protocol number.
    - lifecycle (str): The lifecycle/environment (e.g., "uat", "prod").
    - connection_string (str): The JDBC connection string to Postgres.
    - connection_properties (dict): The JDBC connection properties used to connect to Postgres.

    Returns:
    - DataFrame: A DataFrame containing the queries needing synchronization, excluding unchanged records.
    """
    
    sql_query = f"""
      SELECT  
          '{protocol_Number}' as protocol_num,  
          CAST(FORMAT_NUMBER(query_id, '###') AS NUMERIC) AS query_id, 
          CAST(querytext AS STRING) as querytext, 
          CAST(FORMAT_NUMBER(requeryforid, '###') AS NUMERIC) AS requeryforid,    
          CAST(studyname AS STRING) AS studyname,    
          CAST(countryregion AS STRING) AS countryregion,    
          CAST(sitenumber AS STRING) AS sitenumber,    
          CAST(subjectname AS STRING) AS subjectname,    
          CAST(folderoid AS STRING) AS folderoid,    
          CAST(FORMAT_NUMBER(recordid, '###') AS STRING) AS recordid,    
          CAST(FORMAT_NUMBER(datapointid, '###') AS STRING) AS datapointid,    
          CAST(field AS STRING) AS field,    
          CAST(fmtcreated AS STRING) AS fmtcreated,   
          CAST(created_raw AS STRING) AS created_raw,    
          CAST(createuser AS STRING) AS createuser,    
          CAST(answereduser AS STRING) AS answereduser,    
          CAST(answertext AS STRING) AS answertext,    
          CAST(answered_raw AS STRING) AS answered_raw,    
          CAST(fmtanswered AS STRING) AS fmtanswered,   
          CAST(resolveduser AS STRING) AS resolveduser,  
          CAST(resolved_raw AS STRING) AS resolved_raw,  
          CAST(fmtresolved AS STRING) AS fmtresolved,   
          CAST(markinggroup AS STRING) AS markinggroup,    
          CAST(status AS STRING) AS status,    
          CAST(recordposition AS STRING) AS recordposition,    
          CAST(formoid AS STRING) as formoid, 
          CAST(instancerepeatnumber AS STRING) as instancerepeatnumber,  
          CAST(crfversionid AS STRING) as crfversionid,
          '{lifecycle}' as lifecycle
      FROM `marvel-{lifecycle.upper()}-gold`.{protocol_Number}.dv_rave_edc_queries
      """

    queries_df = spark.sql(sql_query)

    print("queries_df:", queries_df.count())
    #queries_df.select(["query_id", "createuser", "status"]).display()

    # Query to retrieve existing edc_query records
    query = f"""
    (SELECT eq.external_id, eq.config->'edc'->>'status' as edc_status 
    FROM idqm.edc_query eq 
    WHERE LOWER(eq.protocol_num) = LOWER('{protocol_Number}')
    ) AS edc_query
    """
    existing_edc_queries_df = spark.read.jdbc(url=connection_string, table=query, properties=connection_properties)

    print("existing_edc_queries_df:", existing_edc_queries_df.count())
    #df2.display()

    # Perform a left join to find matches and mismatches
    comparison_df = queries_df.alias('source').join(
        existing_edc_queries_df.alias('target'),
        F.col('source.query_id') == F.col('target.external_id'),
        how='left'
    )

    print("comparison_df:", comparison_df.count())
    #comparison_df.display()

    # Synchronize mismatched or new queries
    filtered_df = comparison_df.filter(
        (F.col('target.external_id').isNull()) |
        (F.col('source.status') != F.col('target.edc_status')) 
    )

    filtered_df_count = filtered_df.count()
    print(f"filtered_df: {filtered_df_count}")
    # filtered_df.select(["source.query_id", "source.querytext", "source.createuser", "source.status", "target.external_id", "target.edc_status"]).display()

    # Drop the unnecessary columns
    filtered_df = filtered_df.drop(
        "external_id", "edc_status"
    )

    return filtered_df

# COMMAND ----------

def batch_join_with_form_field(augmented_df, protocol_number, lifecycle):
    # Extract distinct combinations of form_oid and field
    distinct_combinations = augmented_df.select("form_oid", "field").distinct().collect()

    generic_df_list = []  # To hold transformed DataFrames for all combinations

    # Iterate over each distinct combination of form_oid and field
    for row in distinct_combinations:
        form_oid = row["form_oid"]
        field = row["field"]
        table_name = f"`marvel-{lifecycle.upper()}-gold`.{protocol_number}.{form_oid}"
        
        try:
            # Query the corresponding Delta table for the relevant field
            sql_query = f"""
                SELECT '{form_oid}' AS form_oid,
                       recordid AS record_id,
                       '{field}' AS variable_name,
                       {field} AS variable_value
                FROM {table_name}
                WHERE {field} IS NOT NULL
            """
            # Execute query and load data into a DataFrame
            field_df = spark.sql(sql_query)
            generic_df_list.append(field_df)
        except Exception as e:
            print(f"Error processing table {table_name} for field {field}: {e}")

    # Combine all DataFrames into a single generic DataFrame
    if generic_df_list:
        # Start with the first DataFrame
        generic_df = generic_df_list[0]

        # Iteratively union the remaining DataFrames
        for df in generic_df_list[1:]:
            generic_df = generic_df.unionByName(df)
    else:
        empty_schema = augmented_df.schema.add("variable_value", StringType(), True)
        return spark.createDataFrame([], empty_schema)
    
    # Perform the join with the augmented DataFrame
    final_df = augmented_df.join(
        generic_df,
        (augmented_df["form_oid"] == generic_df["form_oid"]) &
        (augmented_df["recordid"] == generic_df["record_id"]) &
        (augmented_df["field"] == generic_df["variable_name"]),
        how="left"
    ).select(
        *[augmented_df[col] for col in augmented_df.columns],  # Keep all original augmented_df columns
        F.col("variable_value")  # Add only the variable_value column from generic_df
    )

    return final_df

# COMMAND ----------

def augment_query_dataframe_with_rave_metadata(
    source_df: DataFrame,
    Protocol_Number: str,
    Lifecycle: str,
    connection_string: str,
    connection_properties: dict
) -> (DataFrame, DataFrame):
    """
    Augments the source DataFrame with Rave metadata and tracks unmatched queries.

    Parameters:
    - source_df (DataFrame): The source DataFrame containing the queries to process.
    - Protocol_Number (str): The protocol number for filtering metadata tables.
    - Lifecycle (str): The lifecycle/environment (e.g., "uat", "prod").
    - connection_string (str): The JDBC connection string to Postgres.
    - connection_properties (dict): The JDBC connection properties used to connect to Postgres.

    Returns:
    - DataFrame: The augmented DataFrame containing matched rows with metadata.
    - DataFrame: A DataFrame of unmatched rows with failure reasons.
    """
    # Load metadata tables
    metadata_queries = {
        "rse": f"""
            (SELECT *, protocol_num AS rse_protocol_num, metadata_version_oid AS rse_metadata_version_oid 
             FROM idqm_source.rave_study_events 
             WHERE protocol_num = '{Protocol_Number}' AND lifecycle = '{Lifecycle}') AS study_events
        """,
        "rf": f"""
            (SELECT *, protocol_num AS rf_protocol_num, metadata_version_oid AS rf_metadata_version_oid 
             FROM idqm_source.rave_forms 
             WHERE protocol_num = '{Protocol_Number}' AND lifecycle = '{Lifecycle}') AS forms
        """,
        "rig": f"""
            (SELECT *, protocol_num AS rig_protocol_num, metadata_version_oid AS rig_metadata_version_oid 
             FROM idqm_source.rave_item_groups 
             WHERE protocol_num = '{Protocol_Number}' AND lifecycle = '{Lifecycle}') AS item_groups
        """,
        "ri": f"""
            (SELECT *, protocol_num AS ri_protocol_num, metadata_version_oid AS ri_metadata_version_oid 
             FROM idqm_source.rave_items 
             WHERE protocol_num = '{Protocol_Number}' AND lifecycle = '{Lifecycle}') AS items
        """
    }

    metadata_dfs = {
        key: spark.read.jdbc(url=connection_string, table=query, properties=connection_properties)
        for key, query in metadata_queries.items()
    }

    # Perform a single multi-table join with deduplication and additional condition for `ri`
    joined_df = (
        source_df.alias("source")
        .join(
            metadata_dfs["rse"].alias("rse"),
            (F.col("source.protocol_num") == F.col("rse.rse_protocol_num")) &
            (F.col("source.crfversionid") == F.col("rse.rse_metadata_version_oid")) &
            (F.col("source.folderoid") == F.col("rse.study_event_oid")) &
            (F.col("source.formoid") == F.col("rse.form_oid")),
            how="left"
        )
        .join(
            metadata_dfs["rig"].alias("rig"),
            (
                (F.col("rse.rse_protocol_num") == F.col("rig.rig_protocol_num")) &
                (F.col("rse.rse_metadata_version_oid") == F.col("rig.rig_metadata_version_oid")) &
                (
                    (
                        (F.col("rig.repeating_flag") == "N") &
                        (F.col("source.formoid") == F.col("rig.item_group_oid"))
                    ) |
                    (
                        (F.col("rig.repeating_flag") == "Y") &
                        (F.concat(F.col("source.formoid"), F.lit("_LOG_LINE")) == F.col("rig.item_group_oid"))
                    )
                ) &
                (F.concat(F.col("source.formoid"), F.lit("."), F.col("source.field")) == F.col("rig.item_oid"))  # Corrected condition
            ),
            how="left"
        )
        .join(
            metadata_dfs["rf"].alias("rf"),
            (F.col("rse.rse_protocol_num") == F.col("rf.rf_protocol_num")) &
            (F.col("rse.rse_metadata_version_oid") == F.col("rf.rf_metadata_version_oid")) &
            (F.col("rse.form_oid") == F.col("rf.form_oid")) &
            (F.col("rig.item_group_oid") == F.col("rf.item_group_oid")), 
            how="left"
        )
        .join(
            metadata_dfs["ri"].alias("ri"),
            (F.col("rig.rig_protocol_num") == F.col("ri.ri_protocol_num")) &
            (F.col("rig.rig_metadata_version_oid") == F.col("ri.ri_metadata_version_oid")) &
            (F.col("rig.item_oid") == F.col("ri.item_oid")) &
            (F.col("source.field") == F.col("ri.item_name")),  # Additional condition
            how="left"
        )
    )

    # Identify unmatched rows and their failure reasons
    unmatched_rows = joined_df.filter(
        F.col("rse.rse_protocol_num").isNull() |
        F.col("rf.rf_protocol_num").isNull() |
        F.col("rig.rig_protocol_num").isNull() |
        F.col("ri.ri_protocol_num").isNull()
    ).select(
        *[F.col(f"source.{col}") for col in source_df.columns],
        F.when(F.col("rse.rse_protocol_num").isNull(), "No match in study events")
        .when(F.col("rf.rf_protocol_num").isNull(), "No match in forms")
        .when(F.col("rig.rig_protocol_num").isNull(), "No match in item groups")
        .when(F.col("ri.ri_protocol_num").isNull(), "No match in items")
        .otherwise("Unknown failure").alias("failure_reason")
    )


    # Select only source_df columns for unmatched rows
    unmatched_rows = unmatched_rows.select(*source_df.columns, "failure_reason")

    # Augmented DataFrame: keep only source columns + relevant metadata
    augmented_df = joined_df.filter(
        F.col("rse.rse_protocol_num").isNotNull() &
        F.col("rf.rf_protocol_num").isNotNull() &
        F.col("rig.rig_protocol_num").isNotNull() &
        F.col("ri.ri_protocol_num").isNotNull() 
    ).select(
        # Study Event Information
        F.col("rse.metadata_version_oid"),
        F.concat(F.col("rse.rse_protocol_num"), F.lit(" ("), F.col("rse.lifecycle"), F.lit(")")).alias("study_oid"),
        F.col("rse.study_event_oid"),
        F.col("rse.repeating_flag").cast("boolean").alias("study_event_repeating_flag"),
        
        # Form Information
        F.col("rf.form_oid"),
        F.col("rf.repeating_flag").cast("boolean").alias("form_repeating_flag"),
        
        # Item Group Information
        F.col("rig.item_group_oid"),
        F.col("rig.repeating_flag").cast("boolean").alias("item_group_repeating_flag"),
        
        # Item Information
        F.col("ri.item_oid"),
        F.col("ri.variable_oid"),
        F.col("ri.data_type"),
        F.col("ri.codelist_oid"),
        F.col("ri.trans_text_en"),
        
        # Original Query Feed Information
        *[F.col(f"source.{col}") for col in source_df.columns if col not in ["crfversionid", "mapped_status"]]  # Exclude duplicates
    )

    return augmented_df, unmatched_rows


# COMMAND ----------

def sync_rave_queries_to_inbound(final_df, protocol_number, lifecycle, connection_string, connection_properties) -> int:
    """
    Synchronizes Rave queries from the source data with the `rave_edc_inbound` table in PostgreSQL.

    Parameters:
    - protocol_number (str): The study protocol number.
    - lifecycle (str): The lifecycle/environment (e.g., "uat", "prod").
    - connection_string: The JDBC connection string to Postgres
    - connection_properties: The JDBC connection properties used to connect to Postgres

    Returns:
    - int: The number of records successfully synchronized.
    """
    final_df_count = final_df.count()

    # Write the result to the PostgreSQL destination table
    final_df.write \
        .mode("append") \
        .option("stringtype", "unspecified") \
        .jdbc(connection_string, "idqm_source.rave_edc_inbound", properties=connection_properties)

    print(f"{final_df_count} rows appended successfully.")
    return final_df_count


# COMMAND ----------

def call_upsert_procedure(Protocol_Number, Lifecycle, conn):
    """
    Calls the stored procedure idqm.upsert_rave_inquiry_by_study to process
    the newly inserted data in `idqm_source.rave_edc_inbound`, and then reports
    both the returned values and any errors from the error table.

    Parameters:
    - Protocol_Number (str): The protocol number to process.
    - Lifecycle (str): The lifecycle to process.
    - conn (psycopg2.connection): An active connection to the PostgreSQL database.

    Returns:
    - None
    """
    try:
        with conn.cursor() as cursor:
            # Call the stored procedure and fetch returned values
            cursor.execute("SELECT * FROM idqm.upsert_rave_inquiry_by_study(%s, %s);", (Protocol_Number, Lifecycle))
            result = cursor.fetchone()  # Fetch the returned values
            if result:
                num_inquiry_inserts, num_response_inserts, num_edc_query_inserts, num_edc_query_updates, num_edc_query_to_response_inserts, num_assignment_inserts = result
                print("Stored procedure executed successfully.")
                print("Returned Values:")
                print(f"Number of Inquiry Inserts: {num_inquiry_inserts}")
                print(f"Number of Response Inserts: {num_response_inserts}")
                print(f"Number of Assignment Inserts: {num_assignment_inserts}")
                print(f"Number of EDC Query Inserts: {num_edc_query_inserts}")
                print(f"Number of EDC Query to Response Inserts: {num_edc_query_to_response_inserts}")
                print(f"Number of EDC Query Updates: {num_edc_query_updates}")

    except Exception as e:
        print(f"Error executing stored procedure: {e}")
        raise

# COMMAND ----------

def fetch_errors(
    protocol_number: str, 
    lifecycle: str, 
    connection_string: str, 
    connection_properties: dict
) -> DataFrame:
    """
    Fetches errors from the error table based on the provided protocol number and lifecycle

    Args:
        protocol_number (str): The protocol number to filter the error table.
        lifecycle (str): The lifecycle to filter the error table.
        connection_string (str): The JDBC connection string for the database.
        connection_properties (dict): The connection properties including user, password, and driver.

    """
    # Construct the query to fetch the error records
    error_query = f"""
        (SELECT protocol_num, lifecycle, process_name, table_name, error_message, timestamp, query_id
         FROM idqm_source.rave_edc_inbound_errors
         WHERE LOWER(protocol_num) = LOWER('{protocol_number}')
           AND LOWER(lifecycle) = LOWER('{lifecycle}')
         ORDER BY timestamp DESC) AS error_data
    """

    # Load the data into a Spark DataFrame
    error_df = spark.read.jdbc(url=connection_string, table=error_query, properties=connection_properties)
    
    return error_df

#connection_string = f"jdbc:postgresql://{dbMarvelHost}:{dbMarvelPort}/{dbMarvelName}"
#connection_properties = {
#    "user": dbMarvelUser,
#    "password": dbMarvelPwd,
#    "driver": "org.postgresql.Driver"
#}
#fetch_and_display_errors('77242113PSO3001_D4U', 'PROD', connection_string, connection_properties)

# COMMAND ----------

def join_records_to_tablenames(matched_records_df: DataFrame, protocol_number: str, lifecycle: str) -> DataFrame:
    """
    Joins each record in matched_records_df to one of the tablenames in the array in increasing index order.

    Args:
        matched_records_df (DataFrame): The DataFrame containing matched records.
        protocol_number (str): The protocol number.
        lifecycle (str): The lifecycle.

    Returns:
        DataFrame: A DataFrame with the joined records.
    """
    all_results = []

    matched_records_df = matched_records_df.withColumn("concatenated_tablenames", F.concat_ws(",", "tablenames"))

    print(f"matched_records_df count: {matched_records_df.count()}")
    # Select distinct tablenames
    distinct_tablenames_df = matched_records_df.select("tablenames").distinct()
    distinct_tablenames_df.display()

    for row in distinct_tablenames_df.collect():
        tablenames = row['tablenames']
        concatenated_tablenames_str = ",".join(tablenames)

        print(f"Processing tablenames: {tablenames}")

        # Filter matched_records_df to include only records that contain all tablenames
        filtered_records_df = matched_records_df.filter(
            F.col("concatenated_tablenames").contains(concatenated_tablenames_str)
        )
        
        print(f"filtered_records_df count (tablename): {filtered_records_df.count()}")
        #filtered_records_df.display()

        for tablename in tablenames:
            if(filtered_records_df.count() == 0):
                print(f"Matched all records for tablenames: {tablenames}")
                break

            print(f"Processing tablename: {tablename}")

            fully_qualified_table_name = f"`marvel-{lifecycle.upper()}-gold`.`{protocol_number}`.`{tablename}`"
            
            # First query for rrid
            query_rrid = f"""
                SELECT D4U_RECID, D4U_RECVER,
                       posexplode(split(rrid, '-')) AS (pos_rrid, rrid_value)
                FROM {fully_qualified_table_name}
            """
            rrid_df = spark.sql(query_rrid)

            # Second query for rdataset
            query_rdataset = f"""
                SELECT D4U_RECID, D4U_RECVER,
                       posexplode(split(rdataset, '-')) AS (pos_rdataset, rdataset_value)
                FROM {fully_qualified_table_name}
            """
            rdataset_df = spark.sql(query_rdataset)

            # Join the two DataFrames on common columns
            joined_df = rrid_df.join(
                rdataset_df,
                on=["D4U_RECID", "D4U_RECVER"],
                how="inner"
            )

            # Filter to ensure positions align and values match
            filtered_df = filtered_records_df.join(
                joined_df,
                (filtered_records_df["recordid"] == joined_df["rrid_value"]) &
                (filtered_records_df["formoid"] == joined_df["rdataset_value"]) &
                (F.col("pos_rrid") == F.col("pos_rdataset")),
                "inner"
            ).select(
                *filtered_records_df.columns,
                "D4U_RECID",
                "D4U_RECVER",
                F.lit(tablename).alias("tablename")
            )
            
            print(f"Filtered records count (rrid+rdataset): {filtered_df.count()}")
            if filtered_df.count() > 0:
                all_results.append(filtered_df)
                # Remove matched records from matched_records_df
                matched_records_df = matched_records_df.join(
                    filtered_df,
                    on=["query_id"],
                    how="left_anti"
                )
                print(f"Matched records count: {matched_records_df.count()}")

                # Remove matched records from filtered_records_df
                filtered_records_df = filtered_records_df.join(
                    filtered_df,
                    on=["query_id"],
                    how="left_anti"
                )
                print(f"Filtered records count (remaining): {filtered_records_df.count()}")

    # Combine all results into a single DataFrame
    if all_results:
        final_df = all_results[0]
        for df in all_results[1:]:
            final_df = final_df.union(df)
    else:
        schema = StructType([
            StructField("D4U_RECID", StringType(), True),
            StructField("D4U_RECVER", StringType(), True),
            StructField("tablename", StringType(), True)
        ])
        final_df = spark.createDataFrame([], schema)

    return final_df
# joined_records_df = join_records_to_tablenames(matched_records_df, '77242113PSO3001_D4U', 'PROD')
# display(joined_records_df)

# COMMAND ----------

def map_rave_forms_to_core_listings(protocol_number: str, lifecycle: str, table_info: list) -> DataFrame:
    """
    Builds a table mapping each RAVE form to a D4U core listing for the provided protocol and lifecycle.
    Dynamically checks for the presence of the `rdataset` column and includes empty tables in the result.
    Handles (table_name, listing_asset_id) tuples as input.

    Args:
        protocol_number (str): The protocol number.
        lifecycle (str): The lifecycle/environment (e.g., "dev", "uat", "prod").
        table_info (list): List of tuples containing table_name and listing_asset_id.

    Returns:
        DataFrame: A DataFrame containing dataset values and the corresponding unique tablenames, ordered based on custom logic.
    """
    all_results = []

    for listing_asset_id, table_name in table_info:
        fully_qualified_table_name = f"`marvel-{lifecycle.upper()}-gold`.`{protocol_number}`.`{table_name}`"

        # Check if `rdataset` column exists in the table schema
        try:
            schema_df = spark.sql(f"DESCRIBE TABLE {fully_qualified_table_name}")
            columns = [row["col_name"].lower() for row in schema_df.collect()]
            rdataset_exists = "rdataset" in columns
        except Exception as e:
            print(f"Error describing table {fully_qualified_table_name}: {e}")
            rdataset_exists = False

        if not rdataset_exists:
            # Create a DataFrame indicating `rdataset` is missing for this table
            schema = StructType([
                StructField("protocol_number", StringType(), True),
                StructField("lifecycle", StringType(), True),
                StructField("tablename", StringType(), True),
                StructField("listing_asset_id", StringType(), True),
                StructField("rdataset", StringType(), True),
                StructField("dataset", StringType(), True),
                StructField("all_datasets", ArrayType(StringType()), True)
            ])
            missing_df = spark.createDataFrame(
                [(protocol_number, lifecycle, table_name, listing_asset_id, None, None, ["rdataset_missing"])],
                schema
            )
            all_results.append(missing_df)
            print(f"Table {table_name} does not contain 'rdataset'.")
            continue

        # Query for tables with `rdataset`
        query = f"""
            WITH exploded_datasets AS (
                SELECT
                    '{protocol_number}' AS protocol_number,
                    '{lifecycle}' AS lifecycle,
                    '{table_name}' AS tablename,
                    '{listing_asset_id}' AS listing_asset_id,
                    rdataset,
                    EXPLODE(SPLIT(rdataset, '-')) AS dataset
                FROM {fully_qualified_table_name}
            ),
            distinct_datasets AS (
                SELECT
                    protocol_number,
                    lifecycle,
                    tablename,
                    listing_asset_id,
                    COLLECT_SET(dataset) AS all_datasets
                FROM exploded_datasets
                GROUP BY protocol_number, lifecycle, tablename, listing_asset_id
            )
            SELECT DISTINCT
                e.protocol_number,
                e.lifecycle,
                e.tablename,
                e.listing_asset_id,
                e.rdataset,
                e.dataset,
                d.all_datasets
            FROM exploded_datasets e
            JOIN distinct_datasets d
            ON e.protocol_number = d.protocol_number
            AND e.lifecycle = d.lifecycle
            AND e.tablename = d.tablename
            AND e.listing_asset_id = d.listing_asset_id
            ORDER BY protocol_number, lifecycle, tablename, rdataset
        """
        try:
            core_listing_df = spark.sql(query)
            if core_listing_df.count() > 0:
                all_results.append(core_listing_df)
            else:
                # Include an entry for empty tables
                empty_schema = StructType([
                    StructField("protocol_number", StringType(), True),
                    StructField("lifecycle", StringType(), True),
                    StructField("tablename", StringType(), True),
                    StructField("listing_asset_id", StringType(), True),
                    StructField("rdataset", StringType(), True),
                    StructField("dataset", StringType(), True),
                    StructField("all_datasets", ArrayType(StringType()), True)
                ])
                empty_df = spark.createDataFrame(
                    [(protocol_number, lifecycle, table_name, listing_asset_id, None, None, ["empty_table"])],
                    empty_schema
                )
                all_results.append(empty_df)
                print(f"Table {table_name} is empty.")
        except Exception as e:
            print(f"Error processing table {table_name}: {e}")
            continue

    # Combine all results into a single DataFrame
    if all_results:
        combined_df = all_results[0]
        for df in all_results[1:]:
            combined_df = combined_df.union(df)
    else:
        schema = StructType([
            StructField("protocol_number", StringType(), True),
            StructField("lifecycle", StringType(), True),
            StructField("tablename", StringType(), True),
            StructField("listing_asset_id", StringType(), True),
            StructField("rdataset", StringType(), True),
            StructField("dataset", StringType(), True),
            StructField("all_datasets", ArrayType(StringType()), True)
        ])
        combined_df = spark.createDataFrame([], schema)

    # Step 2: Find common datasets
    combined_df = combined_df.withColumn(
        "tablename_suffix", F.lower(F.expr("substring(tablename, 5, length(tablename) - 4)"))
    )
    combined_df = combined_df.withColumn(
        "dataset_prefix", F.lower(F.expr("substring(dataset, 1, instr(dataset, '_') - 1)"))
    )
    combined_df = combined_df.withColumn(
        "is_match", F.when(F.col("tablename_suffix") == F.col("dataset_prefix"), 1).otherwise(0)
    )

    dataset_tablenames = combined_df.groupBy("dataset").agg(
        F.collect_set(F.struct("is_match", "tablename", "listing_asset_id")).alias("tablenames_struct")
    )

    # Extract tablename and listing_asset_id separately
    dataset_tablenames = dataset_tablenames.withColumn(
        "tablename_and_asset_id",
        F.expr(
            """
            transform(
                array_sort(tablenames_struct, 
                    (left, right) -> 
                    case 
                        when left.is_match = right.is_match 
                        then case 
                            when left.tablename < right.tablename 
                            then -1 
                            else 1 
                        end 
                        else right.is_match - left.is_match 
                    end
                ), 
                x -> struct(x.tablename as tablename, x.listing_asset_id as listing_asset_id)
            )
            """
        )
    )

    # Add individual columns for tablename and listing_asset_id
    dataset_tablenames = dataset_tablenames.withColumn("tablename", F.element_at(F.col("tablename_and_asset_id.tablename"), 1))
    dataset_tablenames = dataset_tablenames.withColumn("listing_asset_id", F.element_at(F.col("tablename_and_asset_id.listing_asset_id"), 1))

    # Drop unnecessary intermediate column
    dataset_tablenames = dataset_tablenames.drop("tablename_and_asset_id")

    return dataset_tablenames


# COMMAND ----------

def create_combined_dataframe(protocol_number: str, lifecycle: str, study_listing_config: list, required_tablenames: list) -> DataFrame:
    """
    Creates a combined DataFrame by processing tables associated with the specified protocol number and lifecycle.
    For each table:
      - Filters the tables to process based on distinct tablename values extracted from a prior operation.
      - Dynamically checks for the existence of specific columns (e.g., rrid, rdataset, rkey_rrid, rkey_split).
      - Explodes the rrid and rdataset columns into their positions and values if they exist.
      - Joins the exploded rrid and rdataset DataFrames on common columns (D4U_RECID, D4U_RECVER, and pos).

    The resulting DataFrame includes:
      - Table name
      - Exploded rrid and rdataset values
      - Other relevant columns (e.g., rkey_rrid, rkey_split).

    Args:
        protocol_number (str): The protocol number.
        lifecycle (str): The lifecycle.
        required_tablenames (list): A list of distinct tablenames to process, ensuring only relevant tables are included.

    Returns:
        DataFrame: A combined DataFrame containing data from the filtered tables.
    """
    
    # Extract the tableName attribute
    all_tablenames = [config[1] for config in study_listing_config]

    # Filter out tables that are not in the required_tablenames
    filtered_tablenames = [table for table in all_tablenames if table in required_tablenames]
    print(f"Filtered tablenames: {filtered_tablenames}")

    all_results = []

    for table_name in filtered_tablenames:
        fully_qualified_table_name = f"`marvel-{lifecycle.upper()}-gold`.`{protocol_number}`.`{table_name}`"

        # Check if the columns rkey_rrid and rkey_split exist
        try:
            schema_df = spark.sql(f"DESCRIBE TABLE {fully_qualified_table_name}")
            columns = [row['col_name'].lower() for row in schema_df.collect()]
            # print(f"Columns: {columns}")
        except Exception as e:
            print(f"Table {fully_qualified_table_name} does not exist. Skipping.")
            continue

        rrid_exists = 'rrid' in columns
        rdataset_exists = 'rdataset' in columns
        rkey_rrid_exists = 'rkey_rrid' in columns
        rkey_split_exists = 'rkey_split' in columns

        # First query for rrid
        query_rrid = f"""
            SELECT '{table_name}' AS table_name,
                   D4U_RECID,
                   D4U_RECVER,
                   {"rrid" if rrid_exists else "null as rrid"},
                   {"rdataset" if rdataset_exists else "null as rdataset"},
                   {"rkey_rrid" if rkey_rrid_exists else "null as rkey_rrid"},
                   {"rkey_split" if rkey_split_exists else "null as rkey_split"},
                   {"posexplode(split(rrid, '-')) AS (pos, rrid_value)" if rrid_exists else "0 as pos, null as rrid_value"}
            FROM {fully_qualified_table_name}
        """
        rrid_df = spark.sql(query_rrid)

        # Second query for rdataset
        query_rdataset = f"""
            SELECT D4U_RECID,
                   D4U_RECVER,
                   {"posexplode(split(rdataset, '-')) AS (pos, rdataset_value)" if rdataset_exists else "0 as pos, null as rdataset_value"}
            FROM {fully_qualified_table_name}
        """
        rdataset_df = spark.sql(query_rdataset)

        # Join the two DataFrames on common columns
        joined_df = rrid_df.join(
            rdataset_df,
            on=["D4U_RECID", "D4U_RECVER", "pos"],
            how="inner"
        ).select(
            rrid_df["table_name"],
            rrid_df["D4U_RECID"],
            rrid_df["D4U_RECVER"],
            rrid_df["rrid"],
            rrid_df["rdataset"],
            rrid_df["pos"],
            rrid_df["rrid_value"],
            rdataset_df["rdataset_value"],
            rrid_df["rkey_rrid"],
            rrid_df["rkey_split"]
        )

        all_results.append(joined_df)

    # Combine all results into a single DataFrame
    if all_results:
        combined_df = all_results[0]
        for df in all_results[1:]:
            combined_df = combined_df.union(df)
    else:
        schema = StructType([
            StructField("table_name", StringType(), True),
            StructField("D4U_RECID", StringType(), True),
            StructField("D4U_RECVER", StringType(), True),
            StructField("rrid", StringType(), True),
            StructField("rdataset", StringType(), True),
            StructField("pos", StringType(), True),
            StructField("rrid_value", StringType(), True),
            StructField("rdataset_value", StringType(), True),
            StructField("rkey_rrid", StringType(), True),
            StructField("rkey_split", StringType(), True)
        ])
        combined_df = spark.createDataFrame([], schema)

    # If I drop rrid and rdataset, and keep rrid_value and rdataset_value, that should resolve some of the duplicates we are experiencing
    # when the same rrid appears on  multiple records with different rdataset values
    combined_df = combined_df.drop("rrid", "rdataset")
    return combined_df

# Example usage
# combined_df = create_combined_dataframe('77242113PSO3001_D4U', 'prod')
# combined_df = create_combined_dataframe('MikeGDemoAndTesting', 'dev')
# print(f"combined_df: {combined_df.count()}")
# combined_df.display()

# COMMAND ----------

# import time
# import pyspark.sql.functions as F

# print(dbMarvelHost)
# connection_string = f"jdbc:postgresql://{dbMarvelHost}:{dbMarvelPort}/{dbMarvelName}"
# connection_properties = {
#     "user": dbMarvelUser,
#     "password": dbMarvelPwd,
#     "driver": "org.postgresql.Driver"
# }

# # For psycopg2 connection
# connection_string_psycopg2 = (
#     f"host={dbMarvelHost} dbname={dbMarvelName} user={dbMarvelUser} "
#     f"password={dbMarvelPwd} port={dbMarvelPort}"
# )

# protocol_number = '86974680NSC1001_D4U'
# lifecycle = 'PROD'

# COMMAND ----------

# # queries_df = fetch_rave_queries(protocol_number, lifecycle)
# queries_df = fetch_rave_queries_needing_synchronization(protocol_number, lifecycle, connection_string, connection_properties)
# print(f"queries_df: {queries_df.count()}")
# queries_df.display()

# # TODO This goes in the main processing loop
# queries_df_count = queries_df.count()
# if(queries_df_count == 0):
#     print("No queries to synchronize")
#     # return queries_df_count

# COMMAND ----------

# study_listing_config = get_study_listing_config(protocol_number, lifecycle, "drm", connection_string_psycopg2)
# print(study_listing_config)

# COMMAND ----------

# rave_forms_to_core_listings_df = map_rave_forms_to_core_listings(protocol_number, lifecycle, study_listing_config)
# print(f"rave_forms_to_core_listings_df: {rave_forms_to_core_listings_df.count()}")
# rave_forms_to_core_listings_df.display()

# COMMAND ----------

# matched_records_df = queries_df.join(rave_forms_to_core_listings_df, queries_df["formoid"] == rave_forms_to_core_listings_df["dataset"], how="inner")
# print(f"matched_records_df: {matched_records_df.count()}")
# matched_records_df.display()

# distinct_tablenames = matched_records_df.select("tablename").distinct().collect()
# distinct_tablenames = [row["tablename"] for row in distinct_tablenames]
# print(f"distinct_tablenames: {distinct_tablenames}")

# COMMAND ----------

# # NOTE: These will end up as un-linked inquiries
# unmatched_query_ids_df = queries_df.join(matched_records_df, on="query_id", how="left_anti")
# print(f"unmatched_query_ids_df: {unmatched_query_ids_df.count()}")
# unmatched_query_ids_df.display()

# COMMAND ----------

# distinct_tablenames = matched_records_df.select("tablename").distinct().collect()
# distinct_tablenames = [row["tablename"] for row in distinct_tablenames]
# print(f"distinct_tablenames: {distinct_tablenames}")

# combined_df = create_combined_dataframe(protocol_number, lifecycle, study_listing_config, distinct_tablenames)
# # If I drop rrid and rdataset, and keep rrid_value and rdataset_value, that should resolve some of the duplicates we are experiencing
# combined_df = combined_df.drop("rrid", "rdataset")
# print(f"combined_df: {combined_df.count()}")
# combined_df.display()

# COMMAND ----------

# # Step 9a: Count matches based on table_name, rdataset_value, and rrid_value
# match_counts_df = combined_df.groupBy("table_name", "rdataset_value", "rrid_value").count()
# print(f"match_counts_df: {match_counts_df.count()}")
# match_counts_df.display()

# COMMAND ----------

# # Step 9b: Flag records where multiple matches exist
# multi_match_df = match_counts_df.filter(F.col("count") > 1).select("table_name", "rdataset_value", "rrid_value")
# print(f"multi_match_df: {multi_match_df.count()}")
# multi_match_df.display()

# COMMAND ----------

# # Step 9c: Join queries to core listing records
# # Create lists of column expressions
# m_columns = [F.col(f"m.{col}") for col in matched_records_df.columns]  # Select all from m
# c_columns = [F.col(f"c.{col}") for col in combined_df.columns if col not in ["table_name", "D4U_RECID", "D4U_RECVER", "rkey_split"]]  # Exclude specific columns from c

# # Add the resolved columns in place of excluded ones
# resolved_columns = [
#     F.col("resolved_table_name").alias("table_name"),
#     F.col("resolved_D4U_RECID").alias("D4U_RECID"),
#     F.col("resolved_D4U_RECVER").alias("D4U_RECVER"),
#     F.col("resolved_rkey_split").alias("rkey_split")
# ]

# # Final column list for selection
# all_columns = m_columns + c_columns + resolved_columns

# joined_df = matched_records_df.alias("m").join(
#     combined_df.alias("c"),
#     (F.col("m.tablename") == F.col("c.table_name")) &
#     (F.col("m.formoid") == F.col("c.rdataset_value")) &
#     (F.col("m.recordid") == F.col("c.rrid_value")),
#     "left_outer"
# ).join(
#     multi_match_df.alias("mm"),
#     (F.col("m.tablename") == F.col("mm.table_name")) &
#     (F.col("m.formoid") == F.col("mm.rdataset_value")) &
#     (F.col("m.recordid") == F.col("mm.rrid_value")),
#     "left_outer"
# ).withColumn(
#     "match_status",
#     F.when(F.col("mm.table_name").isNotNull() & (F.col("m.field") == F.col("c.rkey_split")), "Matched")
#     .when(F.col("mm.table_name").isNotNull() & (F.col("m.field") != F.col("c.rkey_split")), "Unmatched-Multi")
#     .otherwise("Unmatched-Single")
# ).withColumn(
#     "resolved_table_name",
#     F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.table_name"))
# ).withColumn(
#     "resolved_D4U_RECID",
#     F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.D4U_RECID"))
# ).withColumn(
#     "resolved_D4U_RECVER",
#     F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.D4U_RECVER"))
# ).withColumn(
#     "resolved_rkey_split",
#     F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.rkey_split"))
# )
# print(f"joined_df: {joined_df.count()}")
# joined_df.display()

# COMMAND ----------

# # Step 1: Prioritize matches using window function
# match_priority = F.when(F.col("match_status") == "Matched", 1)\
#                   .when(F.col("match_status") == "Unmatched-Single", 2)\
#                   .otherwise(3)

# window = Window.partitionBy("query_id").orderBy(match_priority)

# joined_df = joined_df.withColumn("row_rank", F.row_number().over(window))\
#                       .filter(F.col("row_rank") == 1)\
#                       .drop("row_rank")

# # Step 2: Remove any accidental full-row duplicates
# joined_df = joined_df.dropDuplicates()
# print(f"joined_df: {joined_df.count()}")
# joined_df.display()

# COMMAND ----------

# # Filter for unmatched records where combined_df columns are null
# unmatched_records_df = joined_df.filter(
#     (combined_df["table_name"].isNull()) &
#     (combined_df["rdataset_value"].isNull()) &
#     (combined_df["rrid_value"].isNull())
# )

# print(f"unmatched_records_df: {unmatched_records_df.count()}")
# unmatched_records_df.display()

# print("distinct tuples:")
# distinct_unmatched_records = unmatched_records_df.select("tablename", "formoid", "recordid", "field").distinct()
# distinct_unmatched_records.display()

# COMMAND ----------

# # Initialize an empty list to store DataFrames
# result_dataframes = []

# # Iterate through the rows and construct SQL queries
# for row in distinct_unmatched_records.collect():
#     tablename = row["tablename"]
#     recordid = row["recordid"]

#     # Construct the SQL query
#     query = f"""
#         SELECT urecid 
#         FROM `marvel-prod-gold`.`77242113PSO3001_D4U`.`{tablename}` 
#         WHERE urecid = '{recordid}'
#     """
#     print(query)
#     # Execute the query and append to the result list
#     try:
#         result_df = spark.sql(query)
#         result_dataframes.append(result_df)
#     except Exception as e:
#         print(f"Error querying table {tablename} with recordid {recordid}: {e}")

# # Combine all the DataFrames into a single DataFrame
# if result_dataframes:
#     combined_results_df = result_dataframes[0]
#     for df in result_dataframes[1:]:
#         combined_results_df = combined_results_df.union(df)

#     # Display the combined results
#     print(f"Total combined results: {combined_results_df.count()}")
#     combined_results_df.display()
# else:
#     print("No results found.")

# COMMAND ----------

#joined_df.filter(col("formoid") == lit("VS_GL_900")).display()

# COMMAND ----------

# # Join each query to its parent record
# joined_records_df = join_records_to_tablenames(matched_records_df, '77242113PSO3001_D4U', 'PROD')
# display(joined_records_df)

# COMMAND ----------

try:
    batch_id = dbutils.jobs.taskValues.get(taskKey="read_configuration_from_dre", key="batch_id", default="", debugValue="1670398893")
    study_id = dbutils.jobs.taskValues.get(taskKey="read_configuration_from_dre", key="study_id", default="", debugValue="86974680NSC1001_D4U")
    study_environment = dbutils.jobs.taskValues.get(taskKey="read_configuration_from_dre", key="environment", default="", debugValue="PROD")
    job_id = dbutils.jobs.taskValues.get(taskKey="read_configuration_from_dre", key="job_id", default="", debugValue="211349027580568")
    run_id = dbutils.jobs.taskValues.get(taskKey="read_configuration_from_dre", key="run_id", default="", debugValue="1234567")
    load_timestamp = dbutils.jobs.taskValues.get(taskKey="read_configuration_from_dre", key="load_timestamp", default="", debugValue="2022-12-09T07:00:11")
    formatted_timestamp_str = dbutils.jobs.taskValues.get(taskKey="ingest_inquiries_gold_and_update_audit", key="formatted_timestamp_str", default="", debugValue="")
    
    dbutils.widgets.dropdown("debug", "false", ["true", "false"], "Enable Debug?")
    debug = dbutils.widgets.get("debug").lower() == "true"
    protocol_number = study_id
    lifecycle = study_environment.upper()

    # PostgreSQL connection settings
    # For psycopg2 connection
    connection_string_psycopg2 = f"host={dbMarvelHost} dbname={dbMarvelName} user={dbMarvelUser} password={dbMarvelPwd} port={dbMarvelPort}"
    # For spark connection
    connection_string = f"jdbc:postgresql://{dbMarvelHost}:{dbMarvelPort}/{dbMarvelName}"
    connection_properties = {
        "user": dbMarvelUser,
        "password": dbMarvelPwd,
        "driver": "org.postgresql.Driver"
    }

    print(f"Protocol_Number: {protocol_number}")
    print(f"Lifecycle: {lifecycle}")

    # Establish a single connection to the PostgreSQL database
    with psycopg2.connect(connection_string_psycopg2) as conn:
        # Step 1: Check if Rave query processing is enabled
        is_rave_processing_enabled = get_marvel_study_lifecycle_edc_query_config(protocol_number, lifecycle, conn)
        
        if is_rave_processing_enabled:
            # Step 2: Delete old records from inbound tables
            delete_rave_edc_inbound_and_errors(protocol_number, lifecycle, conn)
            conn.commit()

            # Step 3: Fetch new Rave queries needing synchronization
            queries_df = fetch_rave_queries_needing_synchronization(protocol_number, lifecycle, connection_string, connection_properties)
            print(f"queries_df: {queries_df.count()}")
            queries_df.display()

            queries_df_count = queries_df.count()
            if(queries_df_count > 0):
                # Step 4: Retrieve study listing configuration
                study_listing_config = get_study_listing_config(protocol_number, lifecycle, "drm", connection_string_psycopg2)
                print(study_listing_config)

                # Step 5: Map RAVE forms to core listing tables
                rave_forms_to_core_listings_df = map_rave_forms_to_core_listings(protocol_number, lifecycle, study_listing_config)
                if debug:
                    print(f"rave_forms_to_core_listings_df: {rave_forms_to_core_listings_df.count()}")
                    rave_forms_to_core_listings_df.display()

                # Step 6: Match queries to their respective core listings, do not include queries which are tied to forms that we don't have listings for
                matched_records_df = queries_df.join(rave_forms_to_core_listings_df, queries_df["formoid"] == rave_forms_to_core_listings_df["dataset"], how="inner")
                if debug:
                    print(f"matched_records_df: {matched_records_df.count()}")
                    matched_records_df.display()

                # Step 7: Retrieve distinct core listing table names
                distinct_tablenames = matched_records_df.select("tablename").distinct().collect()
                distinct_tablenames = [row["tablename"] for row in distinct_tablenames]
                print(f"distinct_tablenames: {distinct_tablenames}")

                # Step 8: Create combined DataFrame for all listing tables
                combined_df = create_combined_dataframe(protocol_number, lifecycle, study_listing_config, distinct_tablenames)
                if debug:
                    print(f"combined_df: {combined_df.count()}")
                    combined_df.display()
                
                # Step 9a: Count matches based on table_name, rdataset_value, and rrid_value
                match_counts_df = combined_df.groupBy("table_name", "rdataset_value", "rrid_value").count()
                if debug:
                    print(f"match_counts_df: {match_counts_df.count()}")
                    match_counts_df.display()

                # Step 9b: Flag records where multiple matches exist
                multi_match_df = match_counts_df.filter(F.col("count") > 1).select("table_name", "rdataset_value", "rrid_value")
                if debug:
                    print(f"multi_match_df: {multi_match_df.count()}")
                    multi_match_df.display()

                # Step 9c: Join queries to core listing records
                # Create lists of column expressions
                m_columns = [F.col(f"m.{col}") for col in matched_records_df.columns]  # Select all from m
                c_columns = [F.col(f"c.{col}") for col in combined_df.columns if col not in ["table_name", "D4U_RECID", "D4U_RECVER", "rkey_split"]]  # Exclude specific columns from c

                # Add the resolved columns in place of excluded ones
                resolved_columns = [
                    F.col("resolved_table_name").alias("table_name"),
                    F.col("resolved_D4U_RECID").alias("D4U_RECID"),
                    F.col("resolved_D4U_RECVER").alias("D4U_RECVER"),
                    F.col("resolved_rkey_split").alias("rkey_split")
                ]

                # Final column list for selection
                all_columns = m_columns + c_columns + resolved_columns

                joined_df = matched_records_df.alias("m").join(
                    combined_df.alias("c"),
                    (F.col("m.tablename") == F.col("c.table_name")) &
                    (F.col("m.formoid") == F.col("c.rdataset_value")) &
                    (F.col("m.recordid") == F.col("c.rrid_value")),
                    "left_outer"
                ).join(
                    multi_match_df.alias("mm"),
                    (F.col("m.tablename") == F.col("mm.table_name")) &
                    (F.col("m.formoid") == F.col("mm.rdataset_value")) &
                    (F.col("m.recordid") == F.col("mm.rrid_value")),
                    "left_outer"
                ).withColumn(
                    "match_status",
                    F.when(F.col("mm.table_name").isNotNull() & (F.col("m.field") == F.col("c.rkey_split")), "Matched")
                    .when(F.col("mm.table_name").isNotNull() & (F.col("m.field") != F.col("c.rkey_split")), "Unmatched-Multi")
                    .otherwise("Unmatched-Single")
                ).withColumn(
                    "resolved_table_name",
                    F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.table_name"))
                ).withColumn(
                    "resolved_D4U_RECID",
                    F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.D4U_RECID"))
                ).withColumn(
                    "resolved_D4U_RECVER",
                    F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.D4U_RECVER"))
                ).withColumn(
                    "resolved_rkey_split",
                    F.when(F.col("match_status") == "Unmatched-Multi", F.lit(None)).otherwise(F.col("c.rkey_split"))
                )

                # De-duplicate the records
                # Step 9d: Prioritize matches using window function
                match_priority = F.when(F.col("match_status") == "Matched", 1)\
                                .when(F.col("match_status") == "Unmatched-Single", 2)\
                                .otherwise(3)

                window = Window.partitionBy("query_id").orderBy(match_priority)

                joined_df = joined_df.withColumn("row_rank", F.row_number().over(window))\
                                    .filter(F.col("row_rank") == 1)\
                                    .drop("row_rank")

                # Step 9e: Apply final selection and remove any accidental full-row duplicates
                joined_df = joined_df.select(*all_columns).dropDuplicates()

                if debug:
                    print(f"joined_df: {joined_df.count()}")
                    joined_df.display()

                # Step 10: Identify queries that failed to match; report these as errors
                unmatched_queries_df = (
                    matched_records_df.alias("m")
                    .join(
                        joined_df.alias("j"),
                        ["query_id"],  # Assuming query_id is unique per match
                        "left_anti"  # This keeps only records that do NOT appear in joined_df
                    )
                )

                # Step 11: Augment with Rave metadata
                # The unmatched_rave_metadata_df  shows the records which we could not link with additional metadata or core listings.
                augmented_df, unmatched_rave_metadata_df  = augment_query_dataframe_with_rave_metadata(
                    joined_df, 
                    protocol_number, lifecycle, connection_string, connection_properties
                )
                if debug:
                    print(f"augmented_df: {augmented_df.count()}")
                    augmented_df.display()

                # Step 12: Final batch join with form fields
                final_df = batch_join_with_form_field(augmented_df, protocol_number, lifecycle)
                final_df_count = final_df.count()
                if debug:
                    print(f"final_df: {final_df_count}")
                    final_df.display()

                if final_df_count > 0:
                    # Step 13: Cleanup and write to PostgreSQL
                    clean_df = final_df.drop("dataset", "tablenames_struct", "tablename", "table_name", "pos", "rrid_value", "rdataset_value", "rkey_rrid", "rkey_split")
                    clean_df = clean_df.withColumnRenamed("d4u_recid", "d4urecid")
                    clean_df = clean_df.withColumnRenamed("d4u_recver", "d4urecversion")
                    print(f"clean_df: {clean_df.count()}")
                    clean_df.display()

                    sync_rave_queries_to_inbound(clean_df, protocol_number, lifecycle, connection_string, connection_properties)

                    call_upsert_procedure(protocol_number, lifecycle, conn)
                    conn.commit()

                # Step 14: Fetch errors from Postgres
                errors_df = fetch_errors(protocol_number, lifecycle, connection_string, connection_properties)
                
                # Step 15: Error checks **AFTER** syncing data
                has_postgres_errors = errors_df.count() > 0
                has_unmatched_queries = unmatched_queries_df.count() > 0
                has_unmatched_rave_metadata = unmatched_rave_metadata_df.count() > 0

                if has_postgres_errors or has_unmatched_queries or has_unmatched_rave_metadata:
                    print("Errors detected during processing:")

                    if has_postgres_errors:
                        print(f"Postgres Error Table contains {errors_df.count()} errors.")
                        errors_df.display()

                    if has_unmatched_queries:
                        print(f"Unmatched queries detected: {unmatched_queries_df.count()} records.")
                        unmatched_queries_df.display()

                    if has_unmatched_rave_metadata:
                        print(f"Unmatched Rave metadata records: {unmatched_rave_metadata_df.count()} records.")
                        unmatched_rave_metadata_df.display()

                print("Processing completed successfully.")

            else:
                print("No queries to synchronize")
                
        else:
            print("Rave query processing is not enabled. Skipping marvel_landing_inbound.")

    # Send notification for job success
    job_status = "SUCCESS"
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, job_status, "Job has been executed successfully")
    errant_tables = "N/A"
    msg = "Success: The Rave Inquiry data for Study Id - {0} has been processed successfully".format(study_id)
    domainstats = {}
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,formatted_timestamp_str,data_source,msg,domainstats)
    send_notification(study_id,study_environment,"Success",business_user_recipients,message,vpc_name,"","","","",load_timestamp)

except Exception as e:
    print(f"Caught a generic exception: {e}")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", "rave inquires loaded but failed at rave query landing")
    errant_tables = "N/A"
    msg = "rave inquires loaded but failed at rave query landing notebook"
    domainstats = {}
    message = build_clinical_study_json(study_id, errant_tables, study_environment, job_id, run_id, load_timestamp, "", msg, domainstats)
    send_notification(study_id, study_environment, "Failed", business_user_recipients, message, vpc_name, "", "", "", "", "")
    raise
