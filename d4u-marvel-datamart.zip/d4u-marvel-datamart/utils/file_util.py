# Databricks notebook source
#
# Get file name from mount file path
#
def get_file_name_from_mount_path(mount_file_path):
    path_list = mount_file_path.split("/")
    return path_list[len(path_list)-1]

# COMMAND ----------

#
# Get file name from absolute path
# 
def get_file_name(file_path):
    path_list = file_path.split("/")
    return path_list[len(path_list)-1]

# COMMAND ----------

#
# Get file folder path
#
def get_folder_path(full_file_path):
    path_list = full_file_path.split("/")
    file_name = path_list[len(path_list)-1]
    file_name_trim = "/%s" % (file_name)
    folder_path = full_file_path.replace(file_name_trim, "")
    return folder_path

# COMMAND ----------

def glob(path, pattern, recursive = False):
    return [
        fname
        for flist in [
            ([fi.path] if fi.isFile() else glob(fi.path, pattern, recursive))
            for fi in dbutils.fs.ls(path)
        ]
        for fname in flist if re.search(pattern, fname) is not None
    ]
