# Databricks notebook source
#from datetime import date
import datetime
import time
from numpy import random
import uuid

# Create audit log table if not exists in the given environment
def initialize_audit_log_table(catalog_marvel, schema_marvel, audit_log_table):
#     print(f"Audit Log Table: {catalog_marvel}.{schema_marvel}.{audit_log_table}")
    audit_log_query = f"CREATE TABLE IF NOT EXISTS `{catalog_marvel}`.{schema_marvel}.{audit_log_table}(batch_id STRING, job_id STRING, run_id BIGINT, job_name STRING, study_id STRING, environment STRING, job_start_datetime TIMESTAMP, job_end_datetime TIMESTAMP, job_status STRING, error_msg STRING) PARTITIONED BY (study_id, environment)"
    spark.sql(audit_log_query)


import uuid

def create_bulk_audit_log_with_run_id(job_id, job_batches, study_id, environment, load_timestamp, run_id, status):
    """
    Inserts multiple audit log entries with provided batch_ids for each job_name.
    `job_batches` should be a dict: { job_name: batch_id }
    """

    if not all([job_id, job_batches, load_timestamp, run_id, status]):
        errorMsg = "Required field(s) are missing: "
        if job_id is None:
            errorMsg += "job_id, "
        if not job_batches:
            errorMsg += "job_batches, "
        if load_timestamp is None:
            errorMsg += "load_timestamp, "
        if run_id is None:
            errorMsg += "run_id, "
        if status is None:
            errorMsg += "status, "
        raise Exception(errorMsg.rstrip(", "))

    values = []
    for job_name, batch_id in job_batches.items():
        values.append(
            f"('{batch_id}', '{job_id}', '{run_id}', '{job_name}', "
            f"'{study_id}', '{environment}', '{load_timestamp}', NULL, '{status}', NULL)"
        )

    values_str = ", ".join(values)
    audit_log_insert_query = f"""
        INSERT INTO `{catalog_marvel}`.`{schema_marvel}`.`{audit_log_table}`
            (batch_id, job_id, run_id, job_name, study_id, environment, job_start_datetime, job_end_datetime, job_status, error_msg)
        VALUES 
            {values_str}
    """
    print(f'audit_log_insert_query = {audit_log_insert_query}')
    execute_sql_with_retry(audit_log_insert_query)

def create_audit_log_with_run_id(job_id, job_name, study_id, environment, load_timestamp, run_id, status):
    """
    Inserts an audit log entry with all necessary fields, including run_id and status.
    """

    # Validate required parameters
    if not all([job_id, job_name, load_timestamp, run_id, status]):
        errorMsg = "Required field(s) are missing: "
        if job_id is None:
            errorMsg += "job_id, "
        if job_name is None:
            errorMsg += "job_name, "
        if load_timestamp is None:
            errorMsg += "load_timestamp, "
        if run_id is None:
            errorMsg += "run_id, "
        if status is None:
            errorMsg += "status, "
        raise Exception(errorMsg.rstrip(", "))

    batch_id = str(uuid.uuid4())  # Generate unique batch ID

    audit_log_insert_query = f"""
        INSERT INTO `{catalog_marvel}`.`{schema_marvel}`.`{audit_log_table}`
            (batch_id, job_id, run_id, job_name, study_id, environment, job_start_datetime, job_end_datetime, job_status, error_msg)
        VALUES 
            ('{batch_id}', '{job_id}', '{run_id}', '{job_name}', '{study_id}', '{environment}', '{load_timestamp}', NULL, '{status}', NULL)
    """

    execute_sql_with_retry(audit_log_insert_query)

    return batch_id

def create_audit_log(job_id, job_name, study_id, environment, load_timestamp):
    # Validate that all required parameters have a value.
    if job_id is None or job_name is None or load_timestamp is None:
        errorMsg = "Required field(s) are missing: "
        if job_id is None:
            errorMsg += " job_id,"
        if job_name is None:
            errorMsg += " job_name,"
        if load_timestamp is None:
            errorMsg += " load_timestamp,"

        errorMsg = errorMsg.rstrip(",")
        raise Exception(errorMsg)

    # DJM 1/18/24 - JADR-19322 - SINC0288248 - Recurring Pipeline Failure
    # Changed from time.time() to str(uuid.uuid4() to provide better uniqueness.
    batch_id = str(uuid.uuid4())

#     job_start_timestamp = datetime.datetime.fromtimestamp(batch_id).strftime('%Y-%m-%d %H:%M:%S')
#     job_status = "STARTED"
    audit_log_insert_query = f"""INSERT INTO `{catalog_marvel}`.{schema_marvel}.{audit_log_table} (batch_id, job_id, run_id, job_name, study_id, environment, job_start_datetime, job_end_datetime, job_status, error_msg) VALUES ('{batch_id}', '{job_id}', NULL, '{job_name}', '{study_id}', '{environment}',  '{load_timestamp}', NULL, NULL, NULL)"""

    # Allow NULL values when study_id and/or environment are None.
    if study_id is None or environment is None:
        audit_log_insert_query = audit_log_insert_query.replace("'None'", "NULL")

    #print(f"audit_log_insert_query: {audit_log_insert_query}")
    execute_sql_with_retry(audit_log_insert_query)
    #logger.info(f"Insertion of  Job status for {study_id} into Audit Log Table ")
    return batch_id


def update_audit_log_run_id(batchId, runId, status):

    study_id,environment = get_audit_log_partition(batchId)
    audit_update_query = f"""UPDATE `{catalog_marvel}`.{schema_marvel}.{audit_log_table} SET run_id = {runId}, job_status = '{status}' WHERE batch_id = '{batchId}' AND study_id = '{study_id}' AND environment = '{environment}'"""
    execute_sql_with_retry(audit_update_query)
    # DJM 3/15/24 Performance Tweak - print(f"run_id {runId} is updated in audit_log for batch_id {batchId}")
    #logger.info(f"run_id {runId} is updated in audit_log for batch_id {batchId}")
    

def update_audit_log(batch_id, job_id, run_id, study_id, environment, job_status, error_msg):    
    job_end_time = int(time.time())
    job_end_timestamp = datetime.datetime.fromtimestamp(job_end_time).strftime('%Y-%m-%d %H:%M:%S')    
    audit_log_update_query = f"""UPDATE `{catalog_marvel}`.{schema_marvel}.{audit_log_table} SET job_end_datetime = '{job_end_timestamp}', job_status = '{job_status}', error_msg = '{error_msg}' WHERE batch_id = '{batch_id}' AND lower(study_id) = lower('{study_id}') AND environment = '{environment}'"""        
    execute_sql_with_retry(audit_log_update_query)
    
def update_audit_log_with_partitioning(study_id, environment, job_name, batch_id, job_status, error_msg):    
    job_end_time = int(time.time())
    job_end_timestamp = datetime.datetime.fromtimestamp(job_end_time).strftime('%Y-%m-%d %H:%M:%S')

    if not job_name:
        print(f"WARNING: job_name not provided. Proceeding with partial partition filtering (no job_name).")
        audit_log_update_query = f"""
            UPDATE `{catalog_marvel}`.{schema_marvel}.{audit_log_table} 
            SET job_end_datetime = '{job_end_timestamp}', 
                job_status = '{job_status}', 
                error_msg = '{error_msg}' 
            WHERE lower(study_id) = lower('{study_id}') 
              AND environment = '{environment}'
              AND batch_id = '{batch_id}' 
        """
    else:
        audit_log_update_query = f"""
            UPDATE `{catalog_marvel}`.{schema_marvel}.{audit_log_table} 
            SET job_end_datetime = '{job_end_timestamp}', 
                job_status = '{job_status}', 
                error_msg = '{error_msg}' 
            WHERE lower(study_id) = lower('{study_id}') 
              AND environment = '{environment}' 
              AND job_name = '{job_name}'
              AND batch_id = '{batch_id}' 
        """

    execute_sql_with_retry(audit_log_update_query)

def update_audit_log_by_batch_id(batch_id, job_status, error_msg):   
    job_end_time = int(time.time())
    job_end_timestamp = datetime.datetime.fromtimestamp(job_end_time).strftime('%Y-%m-%d %H:%M:%S')
    audit_log_select_query = f"SELECT error_msg,study_id,environment FROM `{catalog_marvel}`.{schema_marvel}.{audit_log_table} WHERE batch_id = '{batch_id}'"
    df_err_msg = spark.sql(audit_log_select_query)
    batch_error_msg = df_err_msg.collect()[0]["error_msg"]
    
    study_id = df_err_msg.collect()[0]["study_id"]
    environment = df_err_msg.collect()[0]["environment"]
    if(batch_error_msg is not None):
        batch_error_msg = batch_error_msg + error_msg
    else:
        batch_error_msg = error_msg
    
    audit_log_update_query = f"""UPDATE `{catalog_marvel}`.{schema_marvel}.{audit_log_table} SET job_end_datetime = '{job_end_timestamp}', job_status = '{job_status}', error_msg = '{batch_error_msg}' WHERE batch_id = '{batch_id}' and job_name = '{job_name}' AND study_id = '{study_id}' AND environment = '{environment}'"""
    execute_sql_with_retry(audit_log_update_query)
    #logger.info(f"updating job status into audit log table for {study_id}")


def execute_sql_with_retry(sql, log_try = None, total_retry = 20):
    import time
    retry_count = 0
    while True:
        try:
            if (log_try is not None):
                print(f"Log Retry: {log_try} of {total_retry}")
            spark.sql(sql)
            break
        except Exception as e:
            retry_count += 1
            print(f"SQL execution failed (Possible concurency issue). Retrying (count={retry_count})")
            if retry_count > total_retry:
                print(f"Failed to execute SQL: {sql} after {total_retry} attempts.")
                raise e
            sleeptime = random.uniform(1, 5)
            print("Sleeping for: ", (sleeptime * 1000) , " ms")
            time.sleep(sleeptime)

def get_audit_log_partition(batch_id):
    try:
        study_id=environment = ""
        audit_log_get_partition = f"""select study_id, environment from `marvel`.default.audit_log WHERE batch_id = '{batch_id}'"""
        df = spark.sql(audit_log_get_partition)
            # Ensure df is not None before calling collect()
        if df is not None:
            # Perform the necessary operations on df
            study_id  = df.collect()[0][0]
            environment = df.collect()[0][1]
        else:
            print("DataFrame is None in get_audit_log_partition. Please check the audit_log table with " + str(batch_id))
            raise Exception()
        #print(study_id)
        #print(environment)
        return study_id,environment
    except Exception as e:
         print("Error in get_audit_log_partition. Please check the audit_log table with " + str(batch_id))
         raise e

