# Databricks notebook source
# DBTITLE 1,Build & Call Process Clinical Study Job API
import requests
import json


databricks_job_list_uri = "/api/2.1/jobs/list"
databricks_job_uri = "/api/2.1/jobs/run-now"
databricks_runs_uri = "/api/2.1/jobs/runs/list"

databricks_api_token = dbutils.secrets.get(scope = 'marvel', key = 'marvel_databricks_api_token')

databricks_job_url = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['databricks_job_url']

databricks_instance = databricks_job_url.split("/")
databricks_instance ="https://"+databricks_instance[0]

databricks_job_list_api = f"{databricks_instance}{databricks_job_list_uri}"
databricks_run_job_api = f"{databricks_instance}{databricks_job_uri}"
databricks_runs_list_api = f"{databricks_instance}{databricks_runs_uri}"

#Databricks API Request to create Job Run
auth_header = f"Bearer {databricks_api_token}"
headers = {
        'Authorization': auth_header,
        'Content-Type': 'application/json'
        }

# COMMAND ----------

def create_job_run(data):

    logger.info(f'Creating job run via Databricks API: {data}')

    jobs_response = requests.post(databricks_run_job_api, headers=headers, json=data)

    logger.info(f'Job API response: {str(jobs_response.json())}')

    return jobs_response

def list_job_runs(job_id = None, active_only = False):

    if job_id is None:
        logger.info(f'Listing all job runs via Databricks API')

        runs_response = requests.get(databricks_runs_list_api, headers = headers)
    else:
        logger.info(f'Listing job runs for job_id {job_id} via Databricks API')

        runs_response = requests.get(databricks_runs_list_api, headers = headers, params={"job_id": job_id, "active_only": str(active_only).lower()})

    return runs_response


# COMMAND ----------

def study_run_exist(study_id, job_id):

    runs_response = list_job_runs(job_id = job_id, active_only = True)

    if(runs_response.status_code == 200):

        runs_response_json = runs_response.json()

        if "runs" in runs_response_json:
            
            response_list = runs_response_json["runs"]

            logger.info(f'Found {len(response_list)} active runs')

            for run in response_list:
                
                current_run_id = run["run_id"]

                params = run["overriding_parameters"]

                if 'notebook_params' in params:
                    params = params["notebook_params"]

                if "studyId" in params:

                    if str(study_id).upper() == str(params["studyId"]).upper():
                        logger.info(f'Found active run for study {study_id}: {run}')
                        return True

    return False




# COMMAND ----------

def study_lifecycle_run_exist(study_id, job_id, environment, dataModel=None, run_id=None):
    runs_response = list_job_runs(job_id=job_id, active_only=True)
    if runs_response.status_code == 200:
        runs_response_json = runs_response.json()

        if "runs" in runs_response_json:
            response_list = runs_response_json["runs"]

            logger.info(f'Found {len(response_list)} active runs')

            for run in response_list:
                current_run_id = run["run_id"]
                print(f"current_run_id :{current_run_id} & run_id:{run_id}")
                params = run["overriding_parameters"]

                if 'notebook_params' in params:
                    params = params["notebook_params"]

                # Handle both study_id and studyId
                # The submit_clinical_study_process and submit_clinical_study_checks workflows are launched with parameter "studyId"
                # The submit_process_basic_listings, submit_process_filtered_listings, and submit_process_complex_listings workflows are launched with parameter "study_id"
                # Ideally, we should use the same parameter name across all workflows to avoid confusion, but for now we handle both cases
                study_id_param = params.get("study_id") or params.get("studyId")
                environment_param = params.get("environment")
                data_model_param = params.get("data_model")

                if study_id_param and environment_param and data_model_param:
                    if (
                        str(study_id).upper() == str(study_id_param).upper()
                        and str(environment).upper() == str(environment_param).upper()
                        and (dataModel is None or str(dataModel).upper() == str(data_model_param).upper())
                        and (run_id is None or int(current_run_id) != int(run_id))
                    ):
                        print("found active run")
                        logger.info(
                            f'Found active run for study {study_id} & {environment} & {dataModel}: {run}'
                        )
                        return True

    return False
