# Databricks notebook source
# MAGIC %md
# MAGIC ### Marvel Utility

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

import psycopg2
import boto3
import json
from pyspark.sql.functions import col

secretClient = boto3.client('secretsmanager', region_name = aws_region, aws_access_key_id = aws_access_key, aws_secret_access_key = aws_secret_key)
dbMarvelPwd = json.loads(secretClient.get_secret_value(SecretId='POSTGRES_AUTH')['SecretString'])['password']
dbMarvelUser =json.loads(secretClient.get_secret_value(SecretId='POSTGRES_AUTH')['SecretString'])['username'] 
dbMarvelHost = json.loads(secretClient.get_secret_value(SecretId='POSTGRES_AUTH')['SecretString'])['host']
dbMarvelPort = "5432"
dbMarvelName = "marvel"

# COMMAND ----------

# DBTITLE 1,Get Study Listing Configuration from DRE
def get_marvel_study_listing_config(dataSource, studyId="", env=""):
    connection = None
    try:
        # DJM 3/15/24 Remove debug code - print('Connection to DRE DB')
        connection = psycopg2.connect(user=dbMarvelUser,
                                      password=dbMarvelPwd,
                                      host=dbMarvelHost,
                                      port=dbMarvelPort,
                                      database=dbMarvelName)
        cursor = connection.cursor()
        listingConfigQuery = ""

        if studyId != "":
            print("Study Id is present. Query listing configuration from study_listing table.")
            # Query to fetch listing configuration records associated with a study
            listingConfigQuery = f"""SELECT
            sl.label AS listing_name,
            sl.config->>'tableName' AS table_name,
            arr.item_object->>'value' AS file_name,
            sl.config AS listing_config,
            sl.is_active AS is_active
            FROM
            dre.get_study_listing_table('{studyId}', '{env}','{dataSource}','Core Listing') sl
            ,jsonb_array_elements(sl.config->'parameters') WITH ORDINALITY arr(item_object, position)
            WHERE arr.item_object->>'name' = 'fileName'
            """

        else:
            print("Study id is not present. Query listing configuration from catalog")
            # Query to fetch listing configuration records of a data model from the template catalog
            listingConfigQuery = f"""SELECT
                tvl.listingname AS listing_name,
                tvl.tablename AS table_name,
                arr.item_object->>'value' AS file_name,
                tvl.config AS listing_config,
                tvl.is_active AS is_active
            FROM (
                SELECT 
                    tv.name AS listingname, 
                    tv.config->>'tableName' AS tablename,
                    tv.config AS config,
                    ast.is_active
                FROM dre.template_version tv
                INNER JOIN dre.asset_version av ON tv.asset_version_id = av.id AND av.is_latest = true
                INNER JOIN dre.asset ast ON av.asset_id = ast.id 
                INNER JOIN dre.asset_type aty ON aty.id = ast.asset_type_id
                INNER JOIN dre.listing_type lt ON lt.id = (tv.config->>'type')::uuid AND lt.label = 'Core Listing'
                WHERE aty.type = 'Listing' AND LOWER(tv.config->>'dataModel') = LOWER('{dataSource}')
            ) tvl, jsonb_array_elements(tvl.config->'parameters') WITH ORDINALITY arr(item_object, position)
            WHERE arr.item_object->>'name' = 'fileName' """

        cursor.execute(listingConfigQuery)
        # DJM 3/15/24 Remove debug code - print("Fetching listing configuration")
        records = cursor.fetchall()

        cursor.close()

        filtered_records = []
        for record in records:
            if record[4] == True:
                filtered_records.append(record)
            else:
                print(f'Skipping listing configuration for {record[0]} as it is not active')

        print('Total Listing Configuration Records: ', len(filtered_records))

    except (Exception, psycopg2.Error) as error:
        print("Error while fetching data from PostgreSQL", error)
    finally:
        # closing database connection.
        if connection:
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")
    return filtered_records


# COMMAND ----------

# DBTITLE 1,Get study lifecycle and data environment config
def get_marvel_study_lifecycle_data_env_config(studyId):

    data_env_lifecycle_mapping = {
    #   'Data_Environment' : [Array of lifecycles] 
        'UAT' : ['DEV', 'UAT'],
        'PROD': ['PROD']
    }

    query = f"""
        SELECT 
            svv.Protocol_Number, 
            svv.Lifecycle, 
            de.label as Data_Environment
        FROM marvel_dre.dre.study_version_view svv
        JOIN marvel_dre.dre.data_env de ON de.id = svv.Data_Environment_Id
        WHERE svv.Is_Latest = true
        AND LOWER(svv.Protocol_Number) = LOWER('{studyId}')
    """
    print(f'Query DRE database for study lifecycle config: {query}')
    df = spark.sql(query)
    # DJM 3/15/24 Performance Tweak - print(df.show())
    if df.count() > 0:
        rows = df.toPandas().to_json(orient='records')
        rows = json.loads(rows)
        for row in rows:
            if row['Data_Environment'] != 'PROD':
                data_env_lifecycle_mapping['UAT'].append(row['Lifecycle'])
                data_env_lifecycle_mapping['UAT'] = list(set(data_env_lifecycle_mapping['UAT']))
            else:
                data_env_lifecycle_mapping['PROD'].append(row['Lifecycle'])
                data_env_lifecycle_mapping['PROD'] = list(set(data_env_lifecycle_mapping['PROD']))
    else:
        print('No mapping found in DRE. Returning defaults.')

    #print(data_env_lifecycle_mapping)
    return data_env_lifecycle_mapping
