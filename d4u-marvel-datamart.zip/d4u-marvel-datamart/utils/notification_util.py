# Databricks notebook source
# DBTITLE 1,Include init configuration
# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# DBTITLE 1,Send notification function
import json
import boto3
from datetime import datetime as dt
from pyspark.sql.functions import current_timestamp

event_client = boto3.client('events',region_name=aws_region, aws_access_key_id=s3_access_key, aws_secret_access_key=s3_secret_key)


#Funtion to build domain dictionary

#catalog_name,schema_name,domain_table -- input parameters
def build_domain_statistics_dictionary(df):
    domainstatistics_dict={}    
    for row_iterator in df.collect():
        statistics_list=[]
        no_of_updates = row_iterator['updated']
        no_of_inserts = row_iterator['insert']
        no_of_drops = row_iterator['drop']
        Metadata_change =  row_iterator['metadata_change']
        Metadata_change = Metadata_change.replace("'","*")
        table_name =  row_iterator['table']
        domain = table_name
        statistics_list.append(no_of_updates)
        statistics_list.append(no_of_inserts)
        statistics_list.append(no_of_drops)
        statistics_list.append(Metadata_change)
        statistics_list.append(table_name)
        domainstatistics_dict[domain] = statistics_list
        
    return domainstatistics_dict


# Function to build a json object from input parameters
def build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,time,source,msg,domainstats):
    job_url = "https://" + databricks_job_url + job_id + "/runs/" + run_id
    study_environment = study_environment.lower()
    study_id = study_id.lower()
    domain_statistics = []
    for key,value in domainstats.items():
        domain_statistics.append({"domain":key,"no_of_updates":value[0],"no_of_inserts":value[1],"no_of_drops":value[2],"Metadata Change":value[3], "table_name":value[4]})
    message_dict = {
        "Study_id":study_id,
        "errant_tables":errant_tables,
        "study_environment":study_environment,
        "Job Id": job_id,
        "Load Timestamp":time,
        "data_source":source,
        "Job_url": job_url,
        "Execution message":msg,
        "Domains":domain_statistics
    } 
    message = json.dumps(message_dict)
    return message


    
def send_notification(study_id,study_environment,event,recipients,message,vpc_name,s3_file_location,bucket_name,metrics_file_name,updated_tables,load_timestamp):
    today=dt.today()
    subject = f"{study_id} ({study_environment.upper()}) - {event} - Pipeline Execution status"
    current_time=today.strftime("%Y-%m-%d %H:%M:%S")
    catalog = f"marvel-{study_environment}-silver".lower()
    email_event = {
        "source": "Databricks",
        "vpc": vpc_name,
        "event": event, 
        "subject": subject,
        "recipients": recipients,
        "message": message,
        "s3_file_location" : s3_file_location,
        "bucket_name":bucket_name,
        "metrics_file_name":metrics_file_name,
        "catalog":catalog,
        "updated_tables":updated_tables,
        "load_timestamp":load_timestamp,
        "Study_id":study_id
              
    }

        
    
    event_sent = event_client.put_events(
        Entries=[
            {
                'Time': current_time,
                'Source': 'Databricks',
                'DetailType': 'email-admins',
                'Detail': json.dumps(email_event),
                'EventBusName': event_bus_name
                               
            }
        ]
    )
