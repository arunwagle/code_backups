# Databricks notebook source
class GitOptions(object):
    def __init__(self, my_dict):
        for key in my_dict:
            setattr(self, key, my_dict[key])

# COMMAND ----------

def createDirIfNotExist(dir, label = None):
    if not dir.exists():
        print(f"Creating {label or 'directory'} {dir.absolute()}")
        dir.mkdir(parents=True)
    else:
        print(f"Found existing {label or 'directory'} {dir.absolute()}")

# COMMAND ----------

def gitRepoApi(options, apiPath, start=0, asJson=True, max_retries=3):
    if apiPath.startswith("/"):
        apiPath = apiPath[1:]

    url = f"{options.baseurl}/rest/api/latest/projects/{options.projectKey}/repos/{options.repo}/{apiPath}"
    headers = {"Accept": "application/json", "Authorization": f"Bearer {options.token}"}
    params = {"start": start}

    for attempt in range(max_retries):
        response = requests.request("GET", url, headers=headers, params=params)
        if response.status_code == 200:
            if asJson:
                return json.loads(response.text)
            else:
                return response.text
        elif response.status_code == 429:
            print(f"Rate limit hit (HTTP 429) on attempt {attempt+1}/{max_retries}. Retrying with backoff...")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
                continue
        # Add more transient error codes here if needed (e.g., 503)
        # elif response.status_code == 503:
        #     print(f"Service unavailable (HTTP 503) on attempt {attempt+1}/{max_retries}. Retrying with backoff...")
        #     if attempt < max_retries - 1:
        #         time.sleep(2 ** attempt)
        #         continue
        else:
            # For all other errors, do not retry
            break

        # If here, either max retries reached or non-retryable error
    raise Exception(
        f"Error calling Git API {apiPath} (HTTP {response.status_code}). Response: {gitErrors(response)}"
    )

# COMMAND ----------

def gitErrors(response):
    try:
        return "\n".join([e["message"] for e in json.loads(response.text)["errors"]])
    except Exception as e:
        print("Failed to parse errors from response")
        print(e)
        return response.text

# COMMAND ----------

def gitFetchCommit(options, commit):
    apiPath = f"/commits/{commit}"
    print()
    print(f"Verifying commit {commit}")
    commit = gitRepoApi(options, apiPath)
    print(commit)

# COMMAND ----------

def gitFetchFiles(options, path, commit):
    # Check if the cache path exists
    cache_path = Path(f"{options.work_dir}/{path}")
    # print(f"cache_path: {cache_path}")
    if cache_path.exists():
        print(f"Path {cache_path} exists. Skipping fetch.")
        return

    print(f"Fetching git repo files in path {path} at commit {commit}")

    apiPath = f"/files/{path}?at={commit}"

    list_of_files = []
    start = 0
    is_last_page = False

    while (is_last_page ==False):
        files = gitRepoApi(options, apiPath, start=start)
        print(files)
        list_of_files.extend(files["values"])
        start = files.get("nextPageStart", None)
        is_last_page = files.get("isLastPage", True)

    
    print(f'Found {len(list_of_files)} file(s)')
    print(f"Downloading files to working directory {options.work_dir}")

    for sourcefile in list_of_files:
        print(f"\n... {sourcefile} ...")

        localfile = Path(options.work_dir, path, sourcefile)
        if localfile.exists():
            print(localfile)
            print(f'File {localfile} found in cache')
            continue

        rawFile = gitFetchFileContent(options, Path(path, sourcefile), commit)

        print(f"Ok ({len(rawFile)} bytes fetched)")

        createDirIfNotExist(localfile.parent)

        fileHeader = rawFile.splitlines()[0]

        if fileHeader.startswith('# Databricks notebook source'):
            notebook = Path('/', localfile.relative_to('/Workspace'))
            print(notebook)
            success = saveNotebook(notebook, rawFile)
            if not success:
                raise Exception(f"Notebook {notebook} failed to save.")

        else:
            with open(localfile, "w") as f:
                f.write(rawFile)
                print(f"File saved {localfile}")

# COMMAND ----------

def gitFetchFileContent(options, sourcefile, commit):
    apiPath = f"/raw/{sourcefile}?at={commit}"
    return gitRepoApi(options, apiPath, asJson=False)

# COMMAND ----------

import base64

def saveNotebook(targetPath, content, max_retries=3):

    # Check if running in a workflow context
    try:    
        ctx = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
        host_name = ctx['extraContext']['api_url']
        host_token = ctx['extraContext']['api_token']
    except:
        # Manually set the variables if not running in a workflow
        # Global variables are set in ../init_scripts/init_load_clinical_study.py
        host_name = databricks_instance
        host_token = databricks_api_token

    data = {
        "content": base64.b64encode(content.encode("utf-8")).decode('ascii'),
        "path": str(targetPath.absolute().with_suffix('')),
        "language": "PYTHON",
        "overwrite": True,
        "format": "SOURCE"
    }

    for attempt in range(max_retries):
        response = requests.post(
            f'{host_name}/api/2.0/workspace/import',
            headers={'Authorization': f'Bearer {host_token}'},
            json=data
        ).json()
        print(f'Response: {response}')
        
        if 'error_code' in response:
            print(f"Failed to save notebook {targetPath}: {response}")
            if response['error_code'] == 'RESOURCE_EXHAUSTED' and attempt < max_retries - 1:
                print("Rate limited, retrying...")
                time.sleep(2 ** attempt)  # Exponential backoff
                continue
            else:
                return False
        else:
            print(f"Notebook saved {targetPath}")
            return True

    print(f"Giving up on saving notebook {targetPath} after {max_retries} attempts.")
    return False

# COMMAND ----------

def gitFetchProgListing(options, progListingPath, commit):

    global labelFilePath
    global commit_folder

    # Check commit ID
    # NOTE: Removing the check to reduce the amount of traffic to Bitbucket
    # gitFetchCommit(options, commit)

    gitPath = Path(progListingPath.strip("/"))
    print(f'Git Path: {gitPath}')
    
    work_dir = Path(options.cacheDir, commit)
    print(f'work_dir: {work_dir}')

    #Look for programmed listing framework commit id
    prog_listing_framework_commit_id = get_prog_listing_framework_commit_id(studyId, dataEnv, dataModel)

    if prog_listing_framework_commit_id is None:
        prog_listing_framework_commit_id = commit
        print('Using default commit ID from current prog listing: ', prog_listing_framework_commit_id)
    else:
        print('Using commit ID from prog listing framework: ', prog_listing_framework_commit_id)
        labelFilePath = Path(labelFilePath).relative_to(work_dir)
        work_dir = Path(str(work_dir) + f"_{prog_listing_framework_commit_id}")
        labelFilePath = str(Path(work_dir, labelFilePath))

    print(f'labelFilePath: {labelFilePath}')
    print(f'work_dir: {work_dir}')

    # create work Directory for storing source code
    createDirIfNotExist(work_dir, 'Working directory')
    options.work_dir = work_dir

    commit_folder = os.path.basename(options.work_dir)

    # Fetch list of files in /common and store them in cache
    commonFiles = gitFetchFiles(options, "common", prog_listing_framework_commit_id)

    # Fetch list of files in /<ProgListingFolder> and store them in cache
    progListingFiles = gitFetchFiles(options, gitPath, commit)
    

# COMMAND ----------

def gitFetchPLFCommon(study_id, lifecycle, options, commit_ids):
    """
    For each distinct listing commit id, fetch list of files in /common and store them in cache
    using the framework commit id (if present). If no framework commit id is found, do nothing.
    commit_ids: iterable of distinct commit ids for all listings in the study lifecycle.
    """
    prog_listing_framework_commit_id = get_prog_listing_framework_commit_id(study_id, lifecycle, None)

    if prog_listing_framework_commit_id is None:
        print("No prog_listing_framework_commit_id found, skipping fetch.")
        return

    for listing_commit in commit_ids:
        print(f"\n.. {listing_commit} ..")
        work_dir = Path(options.cacheDir, listing_commit + f"_{prog_listing_framework_commit_id}")
        options.work_dir = work_dir

        createDirIfNotExist(work_dir, 'Working directory')
        gitFetchFiles(options, "common", prog_listing_framework_commit_id)
