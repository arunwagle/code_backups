# Databricks notebook source
# DBTITLE 1,Include init configuration
# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# DBTITLE 1,Method to send email
import boto3

from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

def send_email(run_id, batch_id, job_id, job_name, job_status, message):
    to_addrs = [to_address]
    subject = "Job: %s - %s" % (job_name, job_status)
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_address
    msg['To'] = ", ".join(to_addrs)
    msg['job_name'] = job_name
    msg['job_status'] = job_status
   
    HTML_EMAIL_CONTENT = f"""
        <html>
            <head></head>
            <body>
            <h4>Pipeline Execution Status</h4>
            <table>
            <tr><td>Job Id</td><td>{job_id}</td></tr>
            <tr><td>Job Name</td><td>{job_name}</td></tr>
            <tr><td>Batch Id</td><td>{batch_id}</td></tr>
            <tr><td>Job Status</td><td>{job_status}</td></tr>
            <tr><td>Message</td><td>{message}</td></tr>
            </table>
            </body>
        </html>
    """
    body = MIMEText(HTML_EMAIL_CONTENT, 'html')
    msg.attach(body)
    ses = boto3.client('ses', region_name=ses_region, aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key)
    
    ses.send_raw_email(
      Source=msg['FROM'],
      Destinations=to_addrs,
      RawMessage={'Data': msg.as_string()}) 
    print("Sending Email.")
  

# COMMAND ----------


