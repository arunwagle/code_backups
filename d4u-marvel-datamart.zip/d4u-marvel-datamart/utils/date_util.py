# Databricks notebook source
import dateutil

# COMMAND ----------

# Checks a date string for validity.
# EXAMPLES
#   Valid Test Returns True:    isValidDate("20231121T122701")
#   Invalid Test Returns False: isValidDate("20231121T12270")
def isValidDate(date_str_in):
    try:
        date_obj_out = dateutil.parser.parse(date_str_in)
        #print(f'date_obj_out: {date_obj_out}')
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False
