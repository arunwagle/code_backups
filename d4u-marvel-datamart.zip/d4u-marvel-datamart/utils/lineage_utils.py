# Databricks notebook source
from datetime import datetime as dt
from pyspark.sql import functions as F
import pandas as pd
import psycopg2
from pyspark.sql.types import *
from pyspark.sql.functions import lit, upper


relationship_table_name = "d4u_lineage"

# COMMAND ----------

def manage_self_lineage_relationships(listing_table_names, catalog_name, study_id, relationship_table_name, source_data_model):
    try:
        relationship_full_table_name = f"`{catalog_name}`.`{study_id}`.`{relationship_table_name}`"

        for listing_table_name in listing_table_names:
            try:
                # Read distinct D4U_RECID values from the listing table
                listing_df = spark.read.table(f"`{catalog_name}`.`{study_id}`.`{listing_table_name}`").select("D4U_RECID").distinct()

                # Transform data to match the schema without collecting
                relationship_df = listing_df.withColumn("source_table", lit(listing_table_name)) \
                                            .withColumn("target_table", lit(listing_table_name)) \
                                            .withColumn("source_record_id", listing_df["D4U_RECID"]) \
                                            .withColumn("target_record_id", listing_df["D4U_RECID"]) \
                                            .withColumn("relationship_type", lit("LINEAGE")) \
                                            .withColumn("is_primary", lit(True)) \
                                            .withColumn("source_data_model", upper(lit(source_data_model)))\
                                            .drop("D4U_RECID")

                print(f"Overwriting records in {relationship_full_table_name} for target_table '{listing_table_name}' and source_data_model '{source_data_model.upper()}'...")

                # Write to Delta table with `replaceWhere`
                relationship_df.write.format("delta") \
                    .mode("overwrite") \
                    .option("replaceWhere", f"source_data_model = '{source_data_model.upper()}' AND target_table = '{listing_table_name}' AND relationship_type = 'LINEAGE'") \
                    .partitionBy("target_table", "source_data_model") \
                    .saveAsTable(relationship_full_table_name)

                print(f"Self-lineage relationships updated for {listing_table_name}.")

            except Exception as e:
                print(f"Skipping {listing_table_name} due to error: {e}")
                continue

    except Exception as e:
        print(f"Error managing self-lineage relationships: {e}")
        raise e

# COMMAND ----------

from pyspark.sql import functions as F

def create_lineage_relationships_set_based(catalog_name, study_id, listing_table_names, relationship_table_name, source_data_model):
    """Optimized lineage processing with correct is_primary assignment and replaceWhere for efficient updates."""

    relationship_full_table_name = f"`{catalog_name}`.`{study_id}`.`{relationship_table_name}`"

    for listing_table_name in listing_table_names:
        try:
            print(f"\n[INFO] Processing lineage for {listing_table_name}")

            # Read provenance data from listing table
            data_prov = spark.read.table(f"`{catalog_name}`.`{study_id}`.`{listing_table_name}`")\
                .select("D4U_DATAPROV", "D4U_RECID")\
                .distinct()

            # Correctly explode D4U_DATAPROV and extract required fields
            exploded_data = data_prov.selectExpr("D4U_RECID", "posexplode_outer(D4U_DATAPROV) as (pos, provenance)")

            # Fix type mismatch by extracting 'table' as string
            exploded_data = exploded_data.withColumn("prov_table", F.col("provenance.table"))\
                                         .withColumn("prov_record_id", F.col("provenance.D4U_RECID"))\
                                         .drop("provenance")

            # Assign is_primary based on index (0th item in provenance array gets True)
            exploded_data = exploded_data.withColumn("is_primary", F.when(F.col("pos") == 0, True).otherwise(False))

            # Read relationship table, alias columns to avoid ambiguity
            relationship_df = spark.read.table(f"`{catalog_name}`.`{study_id}`.`{relationship_table_name}`")\
                .where((F.col("relationship_type") == F.lit("LINEAGE")) & F.col("is_primary"))\
                .select(
                    F.col("source_table").alias("rel_source_table"),
                    F.col("source_record_id").alias("rel_source_record_id"),
                    F.col("target_table").alias("rel_target_table"),
                    F.col("target_record_id").alias("rel_target_record_id"),
                )\
                .distinct()

            # Join exploded data with relationship table on target_table and target_record_id
            lineage_df = exploded_data.alias("ed").join(
                relationship_df.alias("rl"),
                (F.col("ed.prov_table") == F.col("rl.rel_target_table")) &
                (F.col("ed.prov_record_id") == F.col("rl.rel_target_record_id")),
                "inner"
            )

            # Add required columns
            final_df = lineage_df\
                .withColumn("target_table", F.lit(listing_table_name))\
                .withColumn("target_record_id", F.col("D4U_RECID"))\
                .withColumn("relationship_type", F.lit("LINEAGE"))\
                .withColumn("source_data_model", F.lit(source_data_model.upper()))\
                .select(
                    F.col("rel_source_table").alias("source_table"),
                    F.col("rel_source_record_id").alias("source_record_id"),
                    F.col("target_table"),
                    F.col("target_record_id"),
                    F.col("relationship_type"),
                    F.col("is_primary"),
                    F.col("source_data_model")
                )

            # Batch write to Delta Table with replaceWhere for efficiency
            num_records = final_df.count()
            print(f"[INFO] Writing {num_records} lineage records for {listing_table_name}...")

            final_df.write.format("delta")\
                .option("mergeSchema", "true")\
                .mode("overwrite")\
                .option("replaceWhere", f"source_data_model = '{source_data_model.upper()}' AND target_table = '{listing_table_name}' AND relationship_type = 'LINEAGE'")\
                .partitionBy("target_table", "source_data_model")\
                .saveAsTable(relationship_full_table_name)

        except Exception as e:
            print(f"[ERROR] Skipping {listing_table_name} due to error: {e}")


# COMMAND ----------

from pyspark.sql import functions as F
from collections import defaultdict

# TODO We might need a separate function to handle the RELTYPE = ONE|MANY realtionships
def process_relrec_relationships(catalog_name, study_id, relrec_table_name, relationship_table_name, source_data_model):
    try:
        source_data_model = source_data_model.lower()
        relrec_full_table_name = f"`{catalog_name}`.`{study_id}`.`{relrec_table_name}`"
        relationship_full_table_name = f"`{catalog_name}`.`{study_id}`.`{relationship_table_name}`"

        try:
            result = spark.sql(f"select count(1) from {relrec_full_table_name}").collect()[0][0]
            if result == 0:
                print("[INFO] {relrec_full_table_name} seems to be empty, please check the source table")
                return
        except Exception as e:
            print(f"[INFO] {relrec_full_table_name} table might be missing, please check the source data: {e}")
            return

        # Generate source-target mappings from RELREC table
        sql_stmt = f"""
            WITH drm_source_table AS (
                SELECT
                    CASE 
                        WHEN SPLIT_PART(lower(RDOMAIN), '_', 1) = '{source_data_model}' 
                        THEN LOWER(RDOMAIN) 
                        ELSE '{source_data_model}_' || LOWER(RDOMAIN) 
                    END AS source_table,
                    RELID AS rel_id,
                    IDVARVAL AS source_idvarval,
                    IDVAR AS source_idvar,
                    USUBJID,
                    RELTYPE AS source_reltype
                FROM {relrec_full_table_name}
            ),
            drm_target_table AS (
                SELECT
                    CASE 
                        WHEN SPLIT_PART(lower(RDOMAIN), '_', 1) = '{source_data_model}' 
                        THEN LOWER(RDOMAIN) 
                        ELSE '{source_data_model}_' || LOWER(RDOMAIN) 
                    END AS target_table,
                    RELID AS rel_id,
                    IDVARVAL AS target_idvarval,
                    IDVAR AS target_idvar,
                    USUBJID,
                    RELTYPE AS target_reltype
                FROM {relrec_full_table_name}
            )
            SELECT DISTINCT
                s.source_table,
                t.target_table,
                s.source_idvarval,
                s.source_idvar,
                t.target_idvarval,
                t.target_idvar,
                s.USUBJID,
                s.rel_id,
                s.source_reltype,
                t.target_reltype,
                'RELREC' AS relationship_type
            FROM drm_source_table s
            INNER JOIN drm_target_table t
                ON s.rel_id = t.rel_id
                AND s.source_table != t.target_table
                AND (
                      s.source_reltype is NOT NULL 
                      OR t.target_reltype is NOT NULL
                      OR s.USUBJID = t.USUBJID
                )
        """

        relrec_df = spark.sql(sql_stmt)
 
        if relrec_df.isEmpty():
            print("[INFO] No RELREC relationships found.")
            return
        
        # Extract unique source-target table pairs
        unique_table_pairs = relrec_df.select("source_table", "target_table", "source_idvar", "target_idvar", "source_reltype", "target_reltype") \
                                      .distinct().collect()

        table_cache = {}

        #print(unique_table_pairs)

        # Create a dictionary to track all `source_idvar` and `target_idvar` values per table
        source_idvars_per_table = defaultdict(set)
        target_idvars_per_table = defaultdict(set)

        for row in unique_table_pairs:
            source_idvars_per_table[row["source_table"]].add(row["source_idvar"])
            target_idvars_per_table[row["target_table"]].add(row["target_idvar"])

        # Cache all source and target tables with ALL relevant columns
      
        for source_table, source_idvars in source_idvars_per_table.items():
            if source_table not in table_cache:
                try:
                    table_cache[source_table] = (
                        spark.read.table(f"`{catalog_name}`.`{study_id}`.`{source_table}`")
                        .select(["D4U_RECID", "USUBJID", "DOMAIN"] + list(source_idvars))  # Select all needed `source_idvar` columns
                        .distinct()
                        .cache()
                    )
                except Exception as e:
                    print(f"[ERROR] Failed to process RELREC relationships: {e}")
                    continue   

        for target_table, target_idvars in target_idvars_per_table.items():
            if target_table not in table_cache:
                try:
                    table_cache[target_table] = (
                        spark.read.table(f"`{catalog_name}`.`{study_id}`.`{target_table}`")
                        .select(["D4U_RECID", "USUBJID", "DOMAIN"] + list(target_idvars))  # Select all needed `target_idvar` columns
                        .distinct()
                        .cache()
                    )
                except Exception as e:
                    print(f"[ERROR] Failed to process RELREC relationships: {e}")
                    continue    

        # Iterate through all (source_table, target_table) pairs and perform joins
        lineage_dfs = []
        for row in unique_table_pairs:
            try:
                source_table = row["source_table"]
                target_table = row["target_table"]
                source_idvar = row["source_idvar"]
                target_idvar = row["target_idvar"]
                source_domain = source_table.split("_")[1].upper()
                target_domain = target_table.split("_")[1].upper()
                     
                print(f"[INFO] Processing source={source_table}, target={target_table}")

                # Join relrec_df only for the relevant source-target pair
                filtered_relrec_df = relrec_df.filter(
                    (F.col("source_table") == source_table) & (F.col("target_table") == target_table)
                )

                if row["source_reltype"] is None and row["target_reltype"] is None:
                    print(f"reltype is: source = {row['source_reltype']}, target = {row['target_reltype']}")
                    joined_df = (
                        filtered_relrec_df.alias("rel")
                        .join(
                            table_cache[source_table].alias("s"),
                            (F.expr(f"s.`{row['source_idvar']}`") == F.col("rel.source_idvarval")) & 
                            (F.col("rel.USUBJID") == F.col("s.USUBJID")),
                            "inner"
                        )
                        .join(
                            table_cache[target_table].alias("t"),
                            (F.expr(f"t.`{row['target_idvar']}`") == F.col("rel.target_idvarval")) & 
                            (F.col("rel.USUBJID") == F.col("t.USUBJID")),
                            "inner"
                        )
                        .selectExpr(
                            "rel.source_table",                            
                            "s.D4U_RECID AS source_record_id",
                            "rel.target_table",
                            "t.D4U_RECID AS target_record_id",
                            "rel.relationship_type",
                            f"'{source_data_model.upper()}' AS source_data_model"
                        )
                    )
                    lineage_dfs.append(joined_df)      
                else:
                    print(f"reltype is: source = {row['source_reltype']}, target = {row['target_reltype']}")                         
                    joined_df = (
                        table_cache[source_table].alias("s")
                        .join(
                            table_cache[target_table].alias("t"),
                            (F.expr(f"s.{source_idvar}") == F.expr(f"t.{target_idvar}")) & 
                            (F.col("s.USUBJID") == F.col("t.USUBJID")) &
                            (F.col("s.D4U_RECID") != F.col("t.D4U_RECID")),
                            "inner" 
                        )
                        .join(
                            filtered_relrec_df.alias("rel"),
                            (F.expr("s.DOMAIN") == source_domain) &
                            (F.expr("t.DOMAIN") == target_domain) ,
                            "inner"
                        )
                        .selectExpr(
                            "rel.source_table",
                            "s.D4U_RECID AS source_record_id",
                            "rel.target_table",
                            "t.D4U_RECID AS target_record_id",
                            "rel.relationship_type",
                            f"'{source_data_model.upper()}' AS source_data_model"
                        )
                    )
                    lineage_dfs.append(joined_df) 

            except Exception as e:
                    print(f"[ERROR] Failed to process RELREC relationships: {e}")
                    continue
            #lineage_dfs.append(joined_df)

        # Union all joined results together
        if lineage_dfs:
            final_lineage_df = lineage_dfs[0]
            for df in lineage_dfs[1:]:
                final_lineage_df = final_lineage_df.union(df)

            # final_lineage_df.display()

            # Write the results to the lineage table
            final_lineage_df.write.format("delta") \
                .option("mergeSchema", "true") \
                .mode("overwrite") \
                .option("replaceWhere", f"source_data_model = '{source_data_model.upper()}' AND relationship_type = 'RELREC'") \
                .partitionBy("target_table", "source_data_model") \
                .saveAsTable(relationship_full_table_name)

            print(f"[INFO] Successfully updated D4U_LINEAGE in {relationship_full_table_name}")
        else:
            print("[INFO] No valid relationships found after joining.")

    except Exception as e:
        print(f"[ERROR] Failed to process RELREC relationships: {e}")
        raise e


# COMMAND ----------

def table_exists(catalog_name, study_id, table_name):
    #"""Check if a table exists using the information schema."""
    
    try:
        query = f"""
        SELECT COUNT(1) as row_count 
        FROM system.information_schema.tables 
        WHERE table_catalog = '{catalog_name}' 
        AND table_schema = '{study_id}' 
        AND table_name = '{table_name}'
        """
        result = spark.sql(query).collect()[0][0]
        return result > 0
    except Exception as e:
        print(f"Table might be missing,  error: {e}")
        create_table(catalog_name, study_id, table_name)
  
        

def create_table(catalog_name, study_id, table_name):  
    
    try:
        create_table_query = f"""
            CREATE TABLE IF NOT EXISTS `{catalog_name}`.`{study_id}`.`{table_name}` (
            source_table          STRING,
            source_record_id      STRING,
            target_table          STRING,
            target_record_id      STRING,
            relationship_type     STRING,
            is_primary            BOOLEAN,
            source_data_model     STRING
            ) PARTITIONED BY(target_table, source_data_model)
        """
        result = spark.sql(create_table_query).collect()
        return True
    except Exception as e:
        print(f"Table creation failed,  error: {e}")
        raise e


def get_marvel_study_listing_config(studyId, env, label, dataSource, listingAssetIds=""):
    connection = None
    try:
        print('Connection to DB')
        connection = psycopg2.connect(user=dbMarvelUser,
                                      password=dbMarvelPwd,
                                      host=dbMarvelHost,
                                      port=dbMarvelPort,
                                      database=dbMarvelName)
        cursor = connection.cursor()
        # Query to fetch study listing records for a data source of a study
        if len(listingAssetIds) > 0:
            studyListingQuery = f"""
            WITH listingColumns AS (
                SELECT 
                    sl.asset_id,
                    LOWER('{label}') as listing_type, 
                    LOWER(REPLACE(LOWER(sl.config->>'tableName'),'d4u_{label.lower()}_','')) as listing_name, 
                    sl.label as listing_title,
                    sl.config->>'bitbucket_commit' as bitbucket_commit,
                    sl.config->>'bitbucket_path' as bitbucket_path,
                    COALESCE(sl.config->>'parameters','[]')::jsonb AS parameters,
                    rd.elem->>'name' AS column_name,
                    (rd.elem->>'isRecIdKey')::boolean AS isRecIdKey,
                    (rd.elem->>'isRecVersionKey')::boolean AS isRecVersionKey	
                FROM dre.get_study_listing_table('{studyId}', '{env}','{dataSource}','{label} Listing')sl
                CROSS JOIN LATERAL jsonb_array_elements(COALESCE(sl.config->>'columns','[]')::jsonb) rd(elem)
                WHERE (sl.is_active = true) AND sl.asset_id in ({listingAssetIds})
            

            )
            SELECT 
                asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters,
                array_remove(array_agg(CASE WHEN isRecIdKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recIdKeys,
                array_remove(array_agg(CASE WHEN isRecVersionKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recVersionKeys 
            FROM listingColumns
            GROUP BY asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters
            ORDER BY asset_id;
            """
            cursor.execute(studyListingQuery)
            print("Fetching study")
            records = cursor.fetchall()
            cursor.close()
            print('Total Records: ', len(records))
            print(records)

            schema = StructType([
                StructField('asset_id', StringType()),
                StructField('listing_type', StringType()),
                StructField('listing_name', StringType()),
                StructField('listing_title', StringType()),
                StructField('bitbucket_commit', StringType()),
                StructField('bitbucket_path', StringType()),
                StructField('parameters', 
                    ArrayType(
                        StructType([
                            StructField('name', StringType()),
                            StructField('value', StringType())
                        ])
                    )
                ),
                StructField('recIdKeys', ArrayType(StringType())),
                StructField('recVersionKeys', ArrayType(StringType())),
            ])
        else:
            studyListingQuery = f"""
            WITH listingColumns AS (
                SELECT 
                    sl.asset_id,
                    LOWER('{label}') as listing_type, 
                    LOWER(REPLACE(LOWER(sl.config->>'tableName'),'d4u_{label.lower()}_','')) as listing_name, 
                    sl.label as listing_title,
                    sl.config->>'bitbucket_commit' as bitbucket_commit,
                    sl.config->>'bitbucket_path' as bitbucket_path,
                    COALESCE(sl.config->>'parameters','[]')::jsonb AS parameters,
                    rd.elem->>'name' AS column_name,
                    (rd.elem->>'isRecIdKey')::boolean AS isRecIdKey,
                    (rd.elem->>'isRecVersionKey')::boolean AS isRecVersionKey	
                FROM dre.get_study_listing_table('{studyId}', '{env}','{dataSource}','{label} Listing')sl
                CROSS JOIN LATERAL jsonb_array_elements(COALESCE(sl.config->>'columns','[]')::jsonb) rd(elem)
                WHERE (sl.is_active = true)
            

            )
            SELECT 
                asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters,
                array_remove(array_agg(CASE WHEN isRecIdKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recIdKeys,
                array_remove(array_agg(CASE WHEN isRecVersionKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recVersionKeys 
            FROM listingColumns
            GROUP BY asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters
            ORDER BY asset_id;
            """
            cursor.execute(studyListingQuery)
            print("Fetching study")
            records = cursor.fetchall()
            cursor.close()
            print('Total Records: ', len(records))
            print(records)

            schema = StructType([
                StructField('asset_id', StringType()),
                StructField('listing_type', StringType()),
                StructField('listing_name', StringType()),
                StructField('listing_title', StringType()),
                StructField('bitbucket_commit', StringType()),
                StructField('bitbucket_path', StringType()),
                StructField('parameters', 
                    ArrayType(
                        StructType([
                            StructField('name', StringType()),
                            StructField('value', StringType())
                        ])
                    )
                ),
                StructField('recIdKeys', ArrayType(StringType())),
                StructField('recVersionKeys', ArrayType(StringType())),
            ])

        df = spark.createDataFrame(records, schema)
        return df.collect()

    except (Exception, psycopg2.Error) as error:
        print("Error while fetching data from PostgreSQL", error)
        return []
    finally:
        # closing database connection.
        if connection:
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")

# COMMAND ----------

