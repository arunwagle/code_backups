# Databricks notebook source
# DBTITLE 1,Logging
import logging
from datetime import datetime

file_date = datetime.now().strftime('%Y%m%d_%H%M%S')
dir_date = datetime.now().strftime('%Y%m%d')

if 'study_id' not in locals():
    study_id = 'NA'
else:
    if study_id is None:
        study_id = 'NA'

notebook_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
notebook_name = notebook_name.split("/")[-1]
p_filename = f'log_{study_id}_{notebook_name}_{file_date}.log'

p_dir = '/tmp'
filepath = f'{p_dir}/{p_filename}'

print(f'Log file available at: {p_filename}')

logger = logging.getLogger('Custom_log')

if (logger.hasHandlers()):
    logger.handlers.clear()

if 'fileLogging' not in locals():
    fileLogging = True

logger.setLevel(logging.INFO)

if fileLogging == True:    
    fh = logging.FileHandler(filepath,mode='a')
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s',datefmt='%m/%d/%Y %I:%M:%S')
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    print('Console file handler configured')

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
streamformat = logging.Formatter("%(asctime)s.%(msecs)03d: %(message)s", datefmt='%I:%M:%S')
ch.setFormatter(streamformat)
logger.addHandler(ch)

print('Console log handler configured')

def read_log_file(filename):
    log_file_data=None
    with open('/tmp/{0}'.format(filename), 'r') as f:
            log_file_data = f.read()
    return log_file_data

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      raise

def write_log_file(nb1_logs,nb2_logs,nb3_logs,nb4_logs,nb5_logs,nb6_logs,nb7_logs,nb8_logs,nb9_logs,log_filename):
    from datetime import datetime
    file_date_folder = datetime.now().strftime('%Y%m%d')
    if(file_exists(f"{s3_mountpoint}/logs/{file_date_folder}/{log_filename}")):
        print("old log file exists so rename with version id")
        currentDateTime=datetime.now().strftime('%Y%m%H%M%S')
        parse_file_name = re.sub(r'\.log$', '', log_filename)
        updated_log_filename=(f"{parse_file_name}_v_{currentDateTime}.log")
        dbutils.fs.mv(f"{s3_mountpoint}/logs/{file_date_folder}/{log_filename}",f"{s3_mountpoint}/logs/{file_date_folder}/{updated_log_filename}")
    final_logs = nb1_logs+nb2_logs+nb3_logs+nb4_logs+nb5_logs+nb6_logs+nb7_logs+nb8_logs+nb9_logs
    dbutils.fs.mkdirs(f"{s3_mountpoint}/logs/{file_date_folder}")
    dbutils.fs.put(f"{s3_mountpoint}/logs/{file_date_folder}/{log_filename}",final_logs)
    
    

