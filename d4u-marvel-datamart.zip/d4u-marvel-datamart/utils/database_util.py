# Databricks notebook source
def is_schema_exist(catalog_name, schema_name):
    df_schemas = spark.sql("SHOW SCHEMAS IN `%s`" % (catalog_name))
    select_expr = "any(databaseName == '%s')" % (schema_name)
    return (df_schemas.selectExpr(select_expr).collect()[0][0])

# COMMAND ----------

def is_table_exist(catalog_name, schema_name, domain_table_name):
    df_tables = spark.sql("SHOW TABLES IN `%s`.`%s`" % (catalog_name, schema_name))
    select_expr = "any(tableName == '%s')" % (domain_table_name)
    return (df_tables.selectExpr(select_expr).collect()[0][0])
