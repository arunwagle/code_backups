# Databricks notebook source
# DBTITLE 1,Include init configuration
# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# DBTITLE 1,Extract Zip File
import boto3 
from boto3.s3.transfer import TransferConfig, S3Transfer
import zipfile 
from io import BytesIO 
import json 
import re 

def extract_zip_file(trimmed_study_file_path, unzipped_folder, s3_bucket_name,s3_marvel_assets_bucket):
    session = boto3.Session() 
    dev_client = session.client('s3',aws_access_key_id=aws_access_key,
         aws_secret_access_key= aws_secret_key) 
    dev_resource=boto3.resource('s3',aws_access_key_id=aws_access_key,
         aws_secret_access_key= aws_secret_key)           

    bucket_dev = dev_resource.Bucket(s3_bucket_name) 
    zip_obj = dev_resource.Object(bucket_name=s3_bucket_name, key=f"{trimmed_study_file_path}") 
    
    buffer = BytesIO(zip_obj.get()["Body"].read()) 
    z = zipfile.ZipFile(buffer) 
    
    # Set the desired multipart threshold value (5GB)
    GB = 1024 ** 3
    config = TransferConfig(multipart_threshold=5*GB)
       
    
    # Iterate each file within the zip 
    for filename in z.namelist():
        print(f"Filename within the zip {filename}") 
        file_info = z.getinfo(filename)
        data=z.open(filename)
        dev_client.upload_fileobj(data, s3_marvel_assets_bucket, Key=f'{unzipped_folder}{filename}',Config=config)


# COMMAND ----------

#This is zip_util.
