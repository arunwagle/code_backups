# Databricks notebook source
# MAGIC %sql
# MAGIC -- Create `marvel`.default.study_data_review_dtmart table, if not exists
# MAGIC CREATE TABLE IF NOT EXISTS `marvel`.default.study_data_review_dtmart (id BIGINT, source_id STRING, protocol_num STRING, tablename STRING, d4urecid STRING, created_datetime TIMESTAMP,  reviewer_data STRING, reviewer_group_data STRING,modified_date TIMESTAMP)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Preprocess the source table to eliminate multiple matches
# MAGIC WITH deduplicated_source AS (
# MAGIC   SELECT
# MAGIC     protocol_num,
# MAGIC     d4urecid,
# MAGIC     tablename,
# MAGIC     MAX(reviewer_group_data) AS reviewer_group_data,
# MAGIC     MAX(reviewer_data) AS reviewer_data,
# MAGIC     MAX(created_datetime) AS created_datetime,
# MAGIC     MAX(modified_date) AS modified_date
# MAGIC   FROM marvel_dre.dre.study_data_review_view
# MAGIC   WHERE d4urecid IS NOT NULL
# MAGIC   GROUP BY protocol_num, d4urecid, tablename
# MAGIC )
# MAGIC
# MAGIC -- Perform the merge operation with the deduplicated source table
# MAGIC MERGE INTO marvel.default.study_data_review_dtmart AS target
# MAGIC USING deduplicated_source AS source
# MAGIC ON (
# MAGIC   source.protocol_num = target.protocol_num 
# MAGIC   AND source.d4urecid = target.d4urecid
# MAGIC   AND source.tablename = target.tablename
# MAGIC )
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     target.reviewer_group_data = CASE
# MAGIC       WHEN source.reviewer_group_data <> target.reviewer_group_data THEN source.reviewer_group_data
# MAGIC       ELSE target.reviewer_group_data
# MAGIC     END,
# MAGIC     target.reviewer_data = CASE
# MAGIC       WHEN source.reviewer_data <> target.reviewer_data THEN source.reviewer_data
# MAGIC       ELSE target.reviewer_data
# MAGIC     END
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (
# MAGIC     
# MAGIC     target.protocol_num,
# MAGIC     target.tablename,
# MAGIC     target.d4urecid,
# MAGIC     target.created_datetime,
# MAGIC     target.reviewer_data,
# MAGIC     target.reviewer_group_data,
# MAGIC     target.modified_date
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     
# MAGIC     source.protocol_num,
# MAGIC     source.tablename,
# MAGIC     source.d4urecid,
# MAGIC     source.created_datetime,
# MAGIC     source.reviewer_data,
# MAGIC     source.reviewer_group_data,
# MAGIC     source.modified_date
# MAGIC   );
# MAGIC
