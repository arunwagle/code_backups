# Databricks notebook source
# DBTITLE 1,Get pipeline task variables
log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "log_file", default = "", debugValue = "")
temp_study_id= dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "temp_study_id", default = "", debugValue = "68284528MMY3031")
pipeline_environment = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "pipeline_environment", default = "release", debugValue = "release")
target_study_extraction_path = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "target_study_extraction_path", default = "", debugValue = "autoloader/ExtractionPoint-Dev/68284528MMY3031_drm_data_12_08_2022_1630_uat")
study_data_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "study_data_file", default = "", debugValue = "68284528MMY3031_drm_data_12_08_2022_1630_uat.zip")
study_data_path = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "study_data_path", default = "", debugValue = "/mnt/marvellanding/lsaf")
batch_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "batch_id", default = "", debugValue = "1670398893")
study_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "study_id", default = "", debugValue = "68284528MMY3031")
study_domain_model = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "domain_model", default = "", debugValue = "rave")
study_environment = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "environment", default = "", debugValue = "uat")
job_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "job_id", default = "", debugValue = "211349027580568")
run_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "run_id", default = "", debugValue = "1234567")
load_timestamp = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "load_timestamp", default = "", debugValue = "2022-12-09T07:00:11")
thread_count = dbutils.jobs.taskValues.get(taskKey = "initiate_process_rave_raw", key = "thread_count", default = "8", debugValue = "")
thread_count=int(thread_count)
study_schema_name = study_id.lower()
# Define Silver & Gold Catalog Names
catalog_silver = f"marvel-{study_environment}-silver_qa" if (pipeline_environment == "qa") else f"marvel-{study_environment}-silver"
catalog_gold = f"marvel-{study_environment}-gold_qa" if (pipeline_environment == "qa") else f"marvel-{study_environment}-gold"
