# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rave_raw

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

import requests
import json
import base64
from pathlib import Path, PurePath
import os

# COMMAND ----------

studyId=study_id

# COMMAND ----------

# MAGIC %run ../programmed_listing_notebooks/dre_utils

# COMMAND ----------

from datetime import datetime as dt 


# COMMAND ----------

domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_files",default = "error", debugValue = "")
zipfile_date = dbutils.jobs.taskValues.get(taskKey  = "initiate_process_rave_raw",key = "date_time_stamp_string",default = "error", debugValue = "")
# initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
# study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
# create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
# metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")
# ingest_silver_log_file = dbutils.jobs.taskValues.get(taskKey = "ingest_study_data_silver", key = "ingest_silver_log_file", default = "", debugValue = "")
# overwrite_gold_log_file = dbutils.jobs.taskValues.get(taskKey = "overwrite_domain_tables_gold", key = "overwrite_gold_log_file", default = "", debugValue = "")

# COMMAND ----------

job_status = "SUCCESS"
message = "Pipeline Job %s has been executed successfully" % (job_name)
# Update audit log
update_audit_log(batch_id, job_id, run_id, study_id, study_environment, job_status, "Job has been executed successfully")
#logger.info("Updating process end timstamp in audit log table ")

# COMMAND ----------

spark.sql("set spark.sql.ansi.enabled = false")
initial_df = spark.sql("select '' as table,'' as drop,'' as insert,'' as updated ,''as metadata_change")
for x in domains:
  new_inserted_records =  spark.sql(f"select * from `{catalog_gold}`.`{study_schema_name}`.{x}").count()
  updated_records = 0
  dropped_records = 0
                  
  meta_changes= "n/a"
  added_columns = "n/a"

  df2 = spark.sql(f"select '{x}' as table,{dropped_records} as drop,{new_inserted_records} as insert,{updated_records} as updated ,'meta_change:{meta_changes},added_columns:{added_columns}'as metadata_change")
    

  initial_df = initial_df.union(df2)
          
          



# COMMAND ----------

final_stats_df = initial_df

# COMMAND ----------

load_timestamp_cr_datetime = dt.strptime(zipfile_date, '%Y%m%dT%H%M%S')
formatted_timestamp_str = dt.strftime(load_timestamp_cr_datetime, "%Y-%m-%dT%H:%M:%S")

# COMMAND ----------

try:
    records=get_basic_listing_config(study_id, study_environment, data_model)
    if len(records) > 0:
        source_job_name = "submit_process_basic_listings"
        listing_job_id = dbutils.widgets.get("basic_prog_listing_jobid")
        lifecycle=study_environment
        devMode="True"
        dataModel=data_model
        api_call = api_submit_job()  
    else:
        print(f"No basic listing found for study : {study_id}")
except Exception as e:
    raise e

# COMMAND ----------

errant_tables = "N/A"
s3_file_location = ""
bucket_name = f"{s3_bucket_name}"
metrics_file_name = ""
msg = "Success: The load file for Study Id - {0} has been processed successfully".format(study_id)
domainstats = build_domain_statistics_dictionary(final_stats_df)
#message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,msg)
message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,formatted_timestamp_str,data_source,msg,domainstats)
send_notification(study_id,study_environment,"Success",business_user_recipients,message,vpc_name,s3_file_location,bucket_name,metrics_file_name,'',load_timestamp)
# logger.info(f"Domains that were successfully processed are :  {domains}")
# logger.info(msg)

# COMMAND ----------

checkpoint_update_query = f"UPDATE `{checkpoint_table}` SET process_end_timestamp = CURRENT_TIMESTAMP() WHERE run_id = {run_id} AND LOWER(study_id) = LOWER('{study_id}') AND LOWER(environment)=LOWER('{study_environment}')"
# print(checkpoint_update_query)
execute_sql_with_retry(checkpoint_update_query)
#logger.info("Updating checkpoint  table")

# COMMAND ----------

# try:
#     log_file_data=read_log_file(p_filename)
#     write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,metadata_log_file,
#                         ingest_silver_log_file,nonclinicdom_log_file,overwrite_gold_log_file,
#                    cleanupres_log_file,log_file_data,log_file)
# except Exception as e:
#     raise e
