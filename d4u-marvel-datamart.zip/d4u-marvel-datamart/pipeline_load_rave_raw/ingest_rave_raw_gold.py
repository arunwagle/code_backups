# Databricks notebook source
from pyspark.sql.functions import regexp_replace, md5, concat_ws, array, col, lit, struct, to_json, when
from pyspark.sql.types import MapType, StringType, ArrayType, TimestampType
from delta.tables import *
import functools
import re
import operator
from datetime import datetime as dt
from pyspark.sql.functions import to_date,expr


# COMMAND ----------

# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rave_raw

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_files",default = "error", debugValue = "")
# tables_list = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes",key = "tables_list",default = "error", debugValue = "")
# config_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_dict",default = "error", debugValue = "")
# initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
# study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
# create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
# metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")


# COMMAND ----------

print(study_environment)

# COMMAND ----------

catalog_name = f"`marvel-{study_environment}-gold`"

# catalog_name= "`marvel-prod-gold`"



# Check if the schema exists
query = f"SHOW SCHEMAS IN {catalog_name} LIKE '{study_schema_name}'"
result = spark.sql(query)
schema_exists = result.count() > 0

if schema_exists:
    print("Schema exists")
else:
    # Create schema
    spark.sql(f"CREATE SCHEMA {catalog_name}.{study_schema_name}")
    print("Schema created")

# COMMAND ----------

def populate_gold_tables(domain, study_schema_name, study_extraction_path, catalog_name):
    try:
        file_name = domain.replace("raw_", "")
        data_file = file_name + ".csv"
        domain_table_name = domain
        meta_file = file_name + "-meta.csv"
        meta_table_name = domain +"-meta"

        

        # Reading Full File
        df_inputdata = spark.read.option('header', 'true').option('delimiter', ',').option("ignoreLeadingWhiteSpace", "true").option('quote', None).option('escape', '"').option('multiline', True).csv(study_extraction_path + '/' + data_file + '')

        df_pandas = build_pandas_df(study_extraction_path,meta_file,domain)

        df_pandas = df_pandas[~(df_pandas['name'].isin(['D4U_RECID','D4U_RECVER','D4U_DATAPROV']))]

        querycolsstr = ",".join(df_pandas["finalqueryformat"])
        # querycolsstr = querycolsstr.replace("to_timestamp(D4U_RECVERDATE,'ddMMMyyyy:HH:mm:ss')","timestamp(D4U_RECVERDATE)")
        colnamesstr = ",".join(df_pandas["name"])
        spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")

        temp_view_name = f'{temp_study_id}_{domain}_full_data_tempview'
        # logger.info(f'[{domain}] Saving temp view {temp_view_name}')
        df_inputdata.createOrReplaceTempView(temp_view_name)
        df = spark.sql(f"select {querycolsstr} from {temp_view_name}").alias("df")
        # display(df)

        inputdata_meta = spark.read.option('header', 'true').option('delimiter', ',').option("ignoreLeadingWhiteSpace", "true").option('quote', None).option('escape', '"').option('multiline', True).csv(study_extraction_path + '/' + meta_file + '')
        # print("file read successfully")

        # Write data to table with mergeSchema option
        df_inputdata.write.option("overwriteSchema", "True").mode("overwrite").saveAsTable(f"{catalog_name}.{study_schema_name}.{domain_table_name}")

        inputdata_meta.write.option("overwriteSchema", "True").mode("overwrite").saveAsTable(f"{catalog_name}.`{study_schema_name}`.`{meta_table_name}`")


        print("data and meta files written successfully")
        

    except Exception as p:
        global error_process
        global error_table
        error_process = "ingest_study_data_gold"
        error_table = f"{catalog_name}.{study_schema_name}.{domain}"
        raise p



# COMMAND ----------

print(domains)

# COMMAND ----------

try:
    
    study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
    parallel_runs = ThreadPool(thread_count)
    parallel_runs.starmap(populate_gold_tables,zip(domains,repeat(study_schema_name), repeat(study_extraction_path), repeat(catalog_name)))
   
except Exception as e:
        
    # handle_error(e, error_process, error_table,tables_list)
    raise e

# COMMAND ----------


