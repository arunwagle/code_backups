# Databricks notebook source
study_full_path = dbutils.widgets.get("studyFilePath")
pipeline_environment = dbutils.widgets.get("pipelineEnvironment")
batch_id = dbutils.widgets.get("batchId")
study_id = dbutils.widgets.get("studyId")
dataModel= dbutils.widgets.get("data_model")
environment = dbutils.widgets.get("environment")
load_timestamp = dbutils.widgets.get("loadTimestamp")
job_id = dbutils.widgets.get("job_id")
run_id = dbutils.widgets.get("run_id")
thread_count=dbutils.widgets.get("thread_count")
study_id = study_id.lower()
temp_study_id=study_id.replace("-","_")
dataModel=dataModel.upper()
date_time_stamp_string = dbutils.widgets.get("date_time_stamp_string")

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

date_timestamp = load_timestamp.replace('-', '').replace(':','').split(".")[0]
log_filename=study_id+'_'+run_id+'_logs_'+date_timestamp+'.log'
dbutils.jobs.taskValues.set(key   = "log_file", value = log_filename)

# COMMAND ----------

#logger.info(f"Processing of SSR data for {study_id}  started")
#logger.info(f"Data Source for {study_id} :LSAF")

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_study_checks

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

import re
import datetime
from datetime import datetime as dt

# COMMAND ----------

# try:
#     # catalog_silver = f"marvel-{environment}-silver_qa" if (pipeline_environment == "qa") else f"marvel-{environment}-silver"
#     catalog_gold = f"marvel-{environment}-gold_qa" if (pipeline_environment == "qa") else f"marvel-{environment}-gold"      
#     # Checking  Silver schema exists or not
#     # if not (is_schema_exist(catalog_silver, study_id)):
#     #     raise Exception(f"ERROR: Study schema {study_id} does not exists in {catalog_silver}. Job could not proceed")
#     # else:
#     #     print("%s exists in %s" % (study_id, catalog_silver))
#     #     #logger.info(f"{study_id} exists in {catalog_silver}")
#     # # Checking  gold schema exists or not
#     if not (is_schema_exist(catalog_gold, study_id)):
#         raise Exception(f"ERROR: Study schema {study_id} does not exist in {catalog_gold}. Job could not proceed")
#     else:
#         print("%s exists in %s" % (study_id, catalog_gold))
#         #logger.info(f"{study_id} exists in {catalog_gold}")
# except Exception as e:
#     # logger.error("ERROR: Study schema  does not exist. Job could not proceed")
#     # logger.error(e)
#     #log_file_data=read_log_file(p_filename)
#     #write_log_file(log_file_data,"","","","","","","","",log_filename)
#     error_msg = str(e)
#     error_msg = error_msg.replace("'","").replace("\"","")
#     update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
#     errant_tables = "N/A"
#     domainstats ={} 
#     message = build_clinical_study_json(study_id,errant_tables,environment,job_id,run_id,load_timestamp,error_msg,domainstats)
#     send_notification(study_id,environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
#     raise e
#     #dbutils.notebook.exit(error_msg)
     


# COMMAND ----------

# DBTITLE 1,Parse Study File Name & Set Task Values
try:
    value = 10
    file_path_trim_part = f"s3a://{s3_bucket_name}"
    file_mount_path = study_full_path.replace(file_path_trim_part, s3_mountpoint)        

    # Get only file name from the path
    file_name = get_file_name(file_mount_path)

    # Get only the folder path from the path
    folder_path = get_folder_path(file_mount_path)

    print(file_name)
    print(folder_path)

    # Parse Study File Name
    trim_study_file_name = file_name[0:file_name.rfind(".")]
    target_study_extraction_path = f"{s3_unzipped_folder}{study_id}/{dataModel}/{environment}/{trim_study_file_name}/"
    
    print(pipeline_environment)
    print(study_id)
    print(target_study_extraction_path)
    #logger.info(f"Data Load started  for {study_id} at {load_timestamp}")
    # Set Job Task Values
    dbutils.jobs.taskValues.set(key   = "pipeline_environment", value = pipeline_environment)
    dbutils.jobs.taskValues.set(key   = "target_study_extraction_path", value = target_study_extraction_path)    
    dbutils.jobs.taskValues.set(key   = "study_data_file", value = file_name)
    dbutils.jobs.taskValues.set(key   = "study_data_path", value = folder_path)
    dbutils.jobs.taskValues.set(key   = "batch_id", value = batch_id)
    dbutils.jobs.taskValues.set(key   = "study_id", value = study_id)
    dbutils.jobs.taskValues.set(key   = "environment", value = environment)
    dbutils.jobs.taskValues.set(key   = "job_id", value = job_id)
    dbutils.jobs.taskValues.set(key   = "run_id", value = run_id)
    dbutils.jobs.taskValues.set(key   = "load_timestamp", value = load_timestamp)
    dbutils.jobs.taskValues.set(key   = "thread_count", value = thread_count)
    dbutils.jobs.taskValues.set(key   = "temp_study_id", value = temp_study_id)
    dbutils.jobs.taskValues.set(key = "date_time_stamp_string", value = date_time_stamp_string)
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    errant_tables = "Error while parsing file name and setting job task values"
    #logger.error(errant_tables)
    #logger.error(e)
    #log_file_data=read_log_file(p_filename)
    #write_log_file(log_file_data,"","","","","","","","",log_filename)
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    domainstats ={}
    study_environment = file_name[-8:-4]
    study_environment = study_environment.lower()
    if (study_environment[0] == '_'):
        study_environment = study_environment[1:]
    if study_environment not in ('prod','uat'):
        study_environment = "Invalid Study Environment"
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
    dbutils.notebook.exit(error_msg)

# COMMAND ----------

# try:
#     log_file_data=read_log_file(p_filename)
#     dbutils.jobs.taskValues.set(key   = "initiate_process_log_file", value = log_file_data)
# except Exception as e:
#     raise e

