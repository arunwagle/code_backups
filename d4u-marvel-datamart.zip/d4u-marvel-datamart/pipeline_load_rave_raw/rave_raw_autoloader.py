# Databricks notebook source
pipeline_environment = dbutils.widgets.get("pipeline_environment").lower()

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_rave_raw

# COMMAND ----------

# DBTITLE 1,S3 - Configuration
# access_key = dbutils.secrets.get(scope = "marvel", key = "marvel_landing_zone_access_key")
# secret_key = dbutils.secrets.get(scope = "marvel", key = "marvel_landing_zone_secret_key")

sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", s3_access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", s3_secret_key)

# If you are using Auto Loader file notification mode to load files, provide the AWS Region ID.
# aws_region = dbutils.secrets.get(scope = 'marvel', key = 'aws_region')
sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

# aws_bucket_name = "itx-cer-marvel-landing-zone"

# COMMAND ----------

# DBTITLE 1,Define autoloader to monitor S3 bucket for study checks
from pyspark.sql.functions import lit
from pyspark.sql.types import StringType, TimestampType, IntegerType,LongType

print(s3_study_folder_name)
print(lsaf_checkpoint_path)
print(checkpoint_table)

df = spark.readStream.format('cloudFiles') \
    .option('cloudFiles.format', 'binaryFile') \
    .option('cloudFiles.includeExistingFiles', 'true') \
    .option('cloudFiles.useNotifications', 'true') \
    .option('cloudFiles.region', aws_region) \
    .option('cloudFiles.awsAccessKey', s3_access_key) \
    .option('cloudFiles.awsSecretKey', s3_secret_key) \
    .option('pathGlobFilter', '*_{raw,RAW}_*.zip') \
    .load("s3a://%s/%s" % (s3_bucket_name, s3_study_folder_name))

df_custom = df.drop("content") \
    .withColumn("study_id", lit(None).cast(StringType())) \
    .withColumn("domain_model", lit(None).cast(StringType())) \
    .withColumn("environment", lit(None).cast(StringType())) \
    .withColumn("is_processed", lit("0")) \
    .withColumn("job_id", lit(None).cast(StringType())) \
    .withColumn("run_id", lit(None).cast(LongType())) \
    .withColumn("process_start_timestamp", lit(None).cast(TimestampType())) \
    .withColumn("process_end_timestamp", lit(None).cast(TimestampType())) \
    .withColumnRenamed("modificationTime", "file_arrival_timestamp")

df_custom.writeStream \
    .option('checkpointLocation', lsaf_checkpoint_path) \
    .table(checkpoint_table)
