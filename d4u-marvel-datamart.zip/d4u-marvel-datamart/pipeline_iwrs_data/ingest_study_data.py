# Databricks notebook source
from pyspark.sql.functions import regexp_replace, md5, concat_ws, array, col, lit, struct, to_json, when
from pyspark.sql.types import MapType, StringType, ArrayType, TimestampType
from delta.tables import *
import functools
import re
import time
import operator
from datetime import datetime as dt
from pyspark.sql.functions import to_date,expr
import traceback
import os


# COMMAND ----------

# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_iwrs

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

def SavetoSilver(study_schema_name,config_dict,catalog_silver,catalog_gold, table_name, file):
    
    StudyID=study_schema_name

    recId_keys= config_dict[f"{table_name}"]['RecIdKeys']
    recver_keys = config_dict[f"{table_name}"]['RecverKey']

    logger.info(f'recId_keys: {recId_keys}')
    logger.info(f'recver_keys: {recver_keys}')

    spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")
    spark.conf.set("spark.sql.parquet.enableVectorizedReader",False)

    df=spark.read.parquet(f"{file}/")

    df=df.drop("year", "month", "day", "marvel_integration_timestamp", "date_key")

    df_final=df\
        .withColumn("D4U_RECID",lit(md5(concat_ws("||",*recId_keys))))\
        .withColumn("D4U_RECVER",md5(concat_ws("||",*recver_keys)))\
        .withColumn("D4U_DATAPROV",array(to_json(create_map(lit("table"),lit(table_name),lit("D4U_RECID"),md5(concat_ws("||",*recId_keys)),lit("D4U_RECVER"),md5(concat_ws("||",*recver_keys))))).cast("string"))\
        .withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp'))\
        .withColumn("D4U_ISACTIVE", lit(True))\
        .withColumn("D4U_ISDROP", lit(False))

    logger.info(f'Received {df_final.count()} records to process')

    df_duplicates = df_final.groupBy(['D4U_RECID', 'D4U_RECVER']).count().where('count > 1')
    duplicate_count = df_duplicates.count()
    if duplicate_count > 0:
        logger.info(f'!! Found {duplicate_count} duplicate records in data !!')
        display(df_duplicates)
        raise Exception('Duplicate records found')

    #Initial Load
    if not (tableExists(catalog_silver,study_schema_name,table_name)):

        logger.info('Initial Load')
          
        schema = df_final.schema

        #Creation of iwrs table if not exists in Silver and gold layers
        silver_table = createTableIfNotExist(catalog_silver,study_schema_name,table_name,schema)
        gold_table = createTableIfNotExist(catalog_gold,study_schema_name,table_name,schema)

        silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{table_name}`")).alias('silver')

        logger.info(f'0 records in silver before merge')
        logger.info(f'Merging {df_final.count():,} records into silver')

        tic = time.perf_counter()
        silverTable.alias("silver").merge(source = df_final.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()
        toc = time.perf_counter()


        logger.info(f'{silverTable.toDF().count():,} records in silver after merge')
        logger.info(f'Merge completed {toc - tic:0.4f} seconds')

    #Incremental Load
    else:

        logger.info('Incremental Load')

        column_list=df_final.columns

        silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{table_name}`")).alias('silver')

        silver_records = silverTable.toDF().where(col('D4U_ISACTIVE') == True).alias('silver')

        df_insert = df_final.alias("df").join(silver_records,on = 'D4U_RECID', how = 'leftanti')
        df_insert=df_insert.select(column_list)
        logger.info(f'{df_insert.count():,} records in to insert')
        
        df_update = silver_records.join(df_final.alias("df"),expr(f"df.D4U_RECID = silver.D4U_RECID and df.D4U_RECVER != silver.D4U_RECVER"),how = 'inner').select(['df.*'])
        df_update = df_update.select(column_list)
        logger.info(f'{df_update.count():,} records in to update')
        
        df_insert_update = df_insert.union(df_update)
                
        logger.info(f'{silverTable.toDF().count():,} records in silver before merge')
        logger.info(f'Merging { df_insert_update.count()} records into silver')
        
        tic = time.perf_counter()

        #set previous records as false for updated records
        silverTable\
            .alias("silver")\
            .merge(source = df_insert_update.alias("df"), condition = col('df.D4U_RECID') == col('silver.D4U_RECID'))\
            .whenMatchedUpdate(set = {"silver.D4U_ISACTIVE": lit(False)})\
            .execute()

        #insert all new and updated records
        silverTable\
            .alias("silver").merge(source = df_insert_update.alias("df"),condition = col('df.D4U_RECID').isNull())\
            .whenNotMatchedInsertAll()\
            .execute()

        toc = time.perf_counter()
        
        logger.info(f'{silverTable.toDF().count():,} records in silver after merge')
        logger.info(f'Merge completed {toc - tic:0.4f} seconds')

# COMMAND ----------

def SavetoSilverCumulative(study_schema_name,config_dict,catalog_silver,catalog_gold, table_name, file):
    temp_iwrs_table = f'`{catalog_marvel}`.`default`.`temp_{study_schema_name}_iwrs`'

    try:
  
        recId_keys= config_dict[f"{table_name}"]['RecIdKeys']
        recver_keys = config_dict[f"{table_name}"]['RecverKey']

    
        

        logger.info(f'recId_keys: {recId_keys}')
        logger.info(f'recver_keys: {recver_keys}')
        
        spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")
        spark.conf.set("spark.sql.parquet.enableVectorizedReader",False)

        df=spark.read.parquet(f"{file}/")

        df=df.drop("year", "month", "day", "marvel_integration_timestamp", "date_key")

        if(recver_keys == []):
            recver_keys = df.columns
            recver_keys = list(set(recver_keys)-set(recId_keys))

        df_final=df\
            .withColumn("D4U_RECID",lit(md5(concat_ws("||",*recId_keys))))\
            .withColumn("D4U_RECVER",md5(concat_ws("||",*recver_keys)))\
            .withColumn("D4U_DATAPROV",array(to_json(create_map(lit("table"),lit(table_name),lit("D4U_RECID"),md5(concat_ws("||",*recId_keys)),lit("D4U_RECVER"),md5(concat_ws("||",*recver_keys))))).cast("string"))\
            .withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp'))\
            .withColumn("D4U_ISACTIVE", lit(True))\
            .withColumn("D4U_ISDROP", lit(False))

        logger.info(f'Received {df_final.count()} records to process')

        df_duplicates = df_final.groupBy(['D4U_RECID', 'D4U_RECVER']).count().where('count > 1')
        duplicate_count = df_duplicates.count()
        if duplicate_count > 0:
            logger.info(f'!! Found {duplicate_count} duplicate records in data !!')
            display(df_duplicates)
            raise Exception('Duplicate records found')

        #Initial Load
        if not (tableExists(catalog_silver,study_schema_name,table_name)):
    
            logger.info('Initial Load')
            
            schema = df_final.schema

            #Creation of iwrs table if not exists in Silver and gold layers
            silver_table = createTableIfNotExist(catalog_silver,study_schema_name,table_name,schema)
            gold_table = createTableIfNotExist(catalog_gold,study_schema_name,table_name,schema)
            
            silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{table_name}`")).alias('silver')
            
            logger.info(f'0 records in silver before merge')
            logger.info(f'Merging {df_final.count():,} records into silver')

            tic = time.perf_counter()
            silverTable.alias("silver").merge(source = df_final.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()
            toc = time.perf_counter()

            logger.info(f'{silverTable.toDF().count():,} records in silver after merge')
            logger.info(f'Merge completed {toc - tic:0.4f} seconds')
        
        #Incremental Load
        else:

            logger.info('Incremental Load')

            column_list = df_final.columns

            silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{table_name}`")).alias('silver')
            
            silver_records = silverTable.toDF().where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')

            df_insert = df_final.alias("df").join(silver_records,on = 'D4U_RECID',how = 'leftanti').select(['df.*'])
            df_insert = df_insert.select(column_list)

            logger.info(f'{df_insert.count():,} records in to insert')
            #display(df_insert)
            
            df_update = silver_records.join(df_final.alias("df"),expr(f"df.D4U_RECID = silver.D4U_RECID and df.D4U_RECVER != silver.D4U_RECVER"),how = 'inner').select(['df.*'])
            df_update = df_update.select(column_list)

            logger.info(f'{df_update.count():,} records in to update')
            #display(df_update)

            df_drop = silver_records.join(df_final.alias("df"), on = 'D4U_RECID', how = 'leftanti').select(['silver.*'])
            df_drop = df_drop\
                .select(column_list)\
                .withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp'))\
                .withColumn("D4U_ISACTIVE", lit(True))\
                .withColumn("D4U_ISDROP", lit(True))

            logger.info(f'{df_drop.count():,} records in to drop')
            #display(df_drop)
            
            df_insert_update_drop = df_insert.union(df_update).union(df_drop)
            #df_insert_update_drop_ids = list(df_insert_update_drop.select('D4U_RECID').toPandas()['D4U_RECID'])

            logger.info(f'{silverTable.toDF().count():,} records in silver before merge')
            logger.info(f'Merging { df_insert_update_drop.count()} records into silver')

             # Necessary to prevent refresh issues when silver is updated during the first merge (setting D4U_ISACTIVE = False)
            df_insert_update_drop.write\
                .mode("overwrite")\
                .format("delta")\
                .option("overwriteSchema", "true")\
                .saveAsTable(temp_iwrs_table)
           
            #display(df_insert_update_drop)

            tic = time.perf_counter()

            logger.info('Setting all silver records as inactive')
            #set previous records as false for updated records
            silverTable\
                .alias("silver")\
                .merge(source = df_insert_update_drop.alias("df"), condition = col('df.D4U_RECID') == col('silver.D4U_RECID'))\
                .whenMatchedUpdate(set = {"silver.D4U_ISACTIVE": lit(False)})\
                .execute()

            df_insert_update_drop = spark.sql(f"select * from {temp_iwrs_table}")
            logger.info(f'Merging { df_insert_update_drop.count()} records into silver')
            #display(df_insert_update_drop)

            #insert all new, updated and dropped records
            silverTable\
                .alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID').isNull())\
                .whenMatchedUpdate(condition = col('df.D4U_RECID') == col('silver.D4U_RECID'), set = {"silver.D4U_ISACTIVE": lit(False)})\
                .whenNotMatchedInsertAll()\
                .execute()

            toc = time.perf_counter()
            
            logger.info(f'{silverTable.toDF().count():,} records in silver after merge')
            logger.info(f'Merge completed {toc - tic:0.4f} seconds')

    finally:
        dropquery = spark.sql(f"drop table IF EXISTS {temp_iwrs_table}")

# COMMAND ----------


try:
    study_files = json.loads(dbutils.widgets.get("studyFilePath"))

    logger.info(f'Received {len(study_files)} files')

    date_list = []  
    
    for file in study_files:

        head_tail = os.path.split(file)
        split_path = head_tail[1]

        file_name_pattern = re.compile("(?P<table_name>csc_subject_vc|csc_subject_visit_bl_vc){1}\_(?P<date_time_stamp>.+){1}\.parquet.gzip")

        file_match = file_name_pattern.match(split_path)

        file_match_dict = file_match.groupdict()

        date_time_stamp_string = file_match_dict['date_time_stamp']

        
        load_timestamp_cr_str = str(date_time_stamp_string)


        load_timestamp_cr_datetime = dt.strptime(load_timestamp_cr_str, '%Y%m%dT%H%M%S')

       

        date_list.append(load_timestamp_cr_datetime)

        logger.info(f'Processing file: {file}')
        table_name = re.search("/dap_csc/(.*)/protocol_num",file).group(1)
        print(table_name)
        table_name = "iwrs_"+table_name
        logger.info(f'Processing table: {table_name}')
        if(table_name == "iwrs_csc_subject_visit_bl_vc"):            
            SavetoSilver(study_schema_name, config_dict, catalog_silver, catalog_gold, table_name, file)
        else:
            SavetoSilverCumulative(study_schema_name, config_dict, catalog_silver, catalog_gold, table_name, file) 

    max_date = max(date_list)
    formatted_timestamp_str = max_date.strftime("%Y-%m-%dT%H:%M:%S")
    print(f"formated_time : {formatted_timestamp_str}")

    dbutils.jobs.taskValues.set(key = "formatted_timestamp_str",value = formatted_timestamp_str)

except Exception as e:
    
    print(repr(traceback.format_exception(e)))
    error_process = "ingest_study_data"       
    error_table = f"{catalog_silver}.{study_schema_name}.{table_name}"
    tables_list=[table_name]
    handle_error(e, error_process, error_table,tables_list)

# COMMAND ----------

def saveToGold(study_schema_name,catalog_gold,catalog_silver,tableName):
    try:
        
        
        silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
        
        goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')

        logger.info('Merging silver updates to gold')

        if(goldTable.toDF().count()==0):
            logger.info(f'0 records in gold before merge')
            goldTable \
                .merge(
                    source = silverTable, 
                    condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
                ) \
                .whenNotMatchedInsertAll() \
                .execute()
            logger.info(f'{goldTable.toDF().count():,} records in gold after merge')
        else: 

        
            silverTable_drop = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`")\
                .where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == True)).alias('silver_drop')        
            
            logger.info(f'{goldTable.toDF().count():,} records in gold before merge')

            # Delete records updated in silver
            goldTable.merge(
                source = silverTable, 
                condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
            ).whenMatchedDelete(
                condition = col('silver.D4U_RECVER') != col('gold.D4U_RECVER')
            ).execute()

            # Delete Dropped records no in silver DF
            goldTable \
                .merge(
                    source = silverTable_drop, 
                    condition = (col('silver_drop.D4U_RECID') == col('gold.D4U_RECID'))
                ) \
                .whenMatchedDelete(
                    condition = col('silver_drop.D4U_RECVER') == col('gold.D4U_RECVER')
                ) \
                .execute()
        
            # Add all new and updated records
            goldTable \
                .merge(
                    source = silverTable, 
                    condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
                ) \
                .whenNotMatchedInsertAll() \
                .execute()

            logger.info(f'{goldTable.toDF().count():,} records in gold after merge')

        



        
    except Exception as p:
        global error_process
        global error_table
        error_process = "Ingest_data_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
        raise p
  

# COMMAND ----------

import traceback

try:
  table_name_list = [table_name1,table_name2]
  parallel_exec = ThreadPool(2)
  parallel_exec.starmap(saveToGold,zip(repeat(study_schema_name),repeat(catalog_gold),repeat(catalog_silver),table_name_list))
  # saveToGold(study_schema_name,catalog_gold,catalog_silver,table_name)
  
except Exception as e:
    print(repr(traceback.format_exception(e)))
    error_process = "Ingest_data_gold"       
    error_table = f"{catalog_gold}.{study_schema_name}.{table_name}"
    tables_list=[table_name]
    handle_error(e, error_process, error_table,tables_list)
