# Databricks notebook source
# DBTITLE 1,Init configuration for email
aws_access_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_access_key')
aws_secret_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_secret_key')
aws_region = dbutils.secrets.get(scope = 'marvel', key = 'aws_region')


# COMMAND ----------


