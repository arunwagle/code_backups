# Databricks notebook source
# DBTITLE 1,Include File Utility
# MAGIC %run ../utils/file_util

# COMMAND ----------

# DBTITLE 1,Include Zip Utility
# MAGIC %run ../utils/zip_util

# COMMAND ----------

# DBTITLE 1,Include Database Utility
# MAGIC %run ../utils/database_util

# COMMAND ----------

# pipeline_environment = dbutils.widgets.get("pipeline_environment").lower()

# COMMAND ----------

# DBTITLE 1,Pipeline Configurations - Load Clinical Study
job_name = 'process_css_data'
s3_access_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_access_key')
s3_secret_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_secret_key')
databricks_api_token = dbutils.secrets.get(scope = 'marvel', key = 'marvel_databricks_api_token')
databricks_job_uri = "/api/2.1/jobs/run-now"
databricks_runs_uri = "/api/2.1/jobs/runs/list"
domain_data_path = "domains/data"
aws_region = dbutils.secrets.get(scope = 'marvel', key = 'aws_region')
# Code block to read environment variables from AWS Secret Manager
awsSecretKeyName = 'DATABRICKS_ENV_CONFIG'
session = boto3.session.Session() 
secretClient = session.client(service_name='secretsmanager',aws_access_key_id=aws_access_key,
         aws_secret_access_key= aws_secret_key,region_name=aws_region)
s3_bucket_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_bucket_name']
vpc_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['vpc_name']
mount_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['mount_name']
s3_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_mountpoint']
databricks_job_url = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['databricks_job_url']
event_bus_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['event_bus_name']
s3_marvel_assets_bucket=json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_bucket']
s3_marvel_assets_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_mountpoint']
business_user_recipients=[]
admin_user_recipients = []
        
s3_study_folder_name = "css"
s3_zip_folder = "css/"
s3_unzipped_folder = "datamart/ExtractionPoint/"

lsaf_landing_path = "%s/css/" % (s3_mountpoint)
print(lsaf_landing_path)
lsaf_checkpoint_path = "/tmp/autoloader/css_checkpoint"
lsaf_data_path = "/tmp/autoloader/data"
zip_extractionpoint_path = "%s/datamart/ExtractionPoint" % (s3_marvel_assets_mountpoint)
print(zip_extractionpoint_path)
# Catalogs
catalog_marvel = "marvel"
catalog_uat_silver = "marvel-uat-silver"
catalog_uat_gold = "marvel-uat-gold"
catalog_prod_silver = "marvel-prod-silver"
catalog_prod_gold = "marvel-prod-gold"
# Schema
schema_marvel = "default"
# Table Names
checkpoint_table = "clinical_study_css_checkpoint"
audit_log_table = "audit_log"
data_source = "CSS"



# COMMAND ----------

# MAGIC %run ../utils/notification_util
