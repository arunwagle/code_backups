# Databricks notebook source
# DBTITLE 1,Include File Utility
# MAGIC %run ../utils/file_util

# COMMAND ----------

# DBTITLE 1,Include Zip Utility
# MAGIC %run ../utils/zip_util

# COMMAND ----------

# DBTITLE 1,Include Database Utility
# MAGIC %run ../utils/database_util

# COMMAND ----------

# pipeline_environment = dbutils.widgets.get("pipeline_environment").lower()

# COMMAND ----------

# DBTITLE 1,Pipeline Configurations - Load Clinical Study
import boto3
import json
job_name = 'process_clinical_roadmap'
s3_access_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_access_key')
s3_secret_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_secret_key')

databricks_api_token = dbutils.secrets.get(scope = 'marvel', key = 'marvel_databricks_api_token')

aws_region = dbutils.secrets.get(scope = 'marvel', key = 'aws_region')

databricks_job_uri = "/api/2.1/jobs/run-now"
databricks_runs_uri = "/api/2.1/jobs/runs/list"

# Code block to read environment variables from AWS Secret Manager
awsSecretKeyName = 'DATABRICKS_ENV_CONFIG'

session = boto3.session.Session() 
secretClient = session.client(service_name='secretsmanager',aws_access_key_id=s3_access_key,
         aws_secret_access_key= s3_secret_key,region_name=aws_region)

s3_bucket_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_bucket_name']

vpc_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['vpc_name']

mount_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['mount_name']

s3_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_mountpoint']

databricks_job_url = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['databricks_job_url']

event_bus_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['event_bus_name']

s3_marvel_assets_bucket=json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_bucket']
s3_marvel_assets_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_mountpoint']

business_user_recipients=[]
admin_user_recipients = []

relative_s3_folder = 'pnc_odw/dv_IL_Clinical_Roadmap/'
s3_folder_path = f's3a://{s3_bucket_name}/{relative_s3_folder}'
mnt_landing_path = f'{s3_mountpoint}/{relative_s3_folder}'

environment_prod='prod'

catalog_marvel = "marvel"

catalog_prod_gold = "marvel-prod-gold"
# Schema
schema_marvel = "default"
# Table Names
audit_log_table = "audit_log"

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

print(f"VPC: {vpc_name} | Mountpoint: {s3_mountpoint} | Bucket: {s3_bucket_name} | Mountname: {mount_name}")
data_source = "CLIN ROADMAP"

# COMMAND ----------

def get_clin_roadmap_tables_for_values(catalog_name, value_lists):
    
    clin_roadmap_tables_result = []

    for item in value_lists:
        table_name = item['table_name']
        values = item['values']

        for value in values:
            # Extract schema from the value
            schema_name = value.split('.')[0]

            # Get tables with "pnc_odw" prefix in the schema
            table_query = f"SHOW TABLES IN {catalog_name}.`{schema_name}`"
            tables_in_schema = [row.tableName for row in spark.sql(table_query).collect()]

            # Filter tables that start with "pnc_odw_"
            pnc_odw_tables_in_schema = list(filter(lambda t: t.startswith("pnc_odw_"), tables_in_schema))

            # Check if there are any PNC_ODW tables before appending to the result list
            if pnc_odw_tables_in_schema:
                clin_roadmap_tables_result.append({"schema": schema_name, "table_name": table_name})
                
    return clin_roadmap_tables_result


# COMMAND ----------

# MAGIC %run ../utils/notification_util
