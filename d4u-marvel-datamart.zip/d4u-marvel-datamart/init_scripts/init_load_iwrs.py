# Databricks notebook source
# DBTITLE 1,Include File Utility
# MAGIC %run ../utils/file_util

# COMMAND ----------

# DBTITLE 1,Include Zip Utility
# MAGIC %run ../utils/zip_util

# COMMAND ----------

# DBTITLE 1,Include Database Utility
# MAGIC %run ../utils/database_util

# COMMAND ----------

# DBTITLE 1,Pipeline Configurations - Load Clinical Study
import boto3
import json

job_name = 'process_iwrs_data'
s3_access_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_access_key')
s3_secret_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_secret_key')

databricks_api_token = dbutils.secrets.get(scope = 'marvel', key = 'marvel_databricks_api_token')

aws_region = dbutils.secrets.get(scope = 'marvel', key = 'aws_region')

databricks_job_uri = "/api/2.1/jobs/run-now"
databricks_runs_uri = "/api/2.1/jobs/runs/list"

# Code block to read environment variables from AWS Secret Manager
awsSecretKeyName = 'DATABRICKS_ENV_CONFIG'

session = boto3.session.Session() 
secretClient = session.client(service_name='secretsmanager',aws_access_key_id=s3_access_key,
         aws_secret_access_key= s3_secret_key,region_name=aws_region)

s3_bucket_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_bucket_name']

vpc_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['vpc_name']

mount_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['mount_name']

s3_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_mountpoint']

databricks_job_url = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['databricks_job_url']

event_bus_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['event_bus_name']

s3_marvel_assets_bucket=json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_bucket']
s3_marvel_assets_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_mountpoint']

business_user_recipients=[]
admin_user_recipients = []


iwrs_folder = "dap_csc"
iwrs_s3_folder = f's3a://{s3_bucket_name}/{iwrs_folder}'
iwrs_landing_path = f'{s3_mountpoint}/{iwrs_folder}'

table_name1="iwrs_csc_subject_vc"
table_name2="iwrs_csc_subject_visit_bl_vc"
data_model ="iwrs"

iwrs_checkpoint_path = "/tmp/autoloader/iwrs_checkpoint_data"
iwrs_data_path = "/tmp/autoloader/iwrs_data"
iwrs_checkpoint_table = "iwrs_checkpoint"

environment_prod='prod'
        
catalog_marvel = "marvel"
catalog_prod_silver = "marvel-prod-silver"
catalog_prod_gold = "marvel-prod-gold"

# Schema
schema_marvel = "default"

# Table Names
audit_log_table = "audit_log"

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled",True)

data_source = "IWRS"

# COMMAND ----------

# MAGIC %run ../utils/notification_util
