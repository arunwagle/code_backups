# Databricks notebook source
# MAGIC %run ../utils/file_util

# COMMAND ----------

# MAGIC %run ../utils/database_util

# COMMAND ----------

# DBTITLE 1,Pipeline Configurations - RMCM
import boto3
import json
aws_region = dbutils.secrets.get(scope = 'marvel', key = 'aws_region')
job_name = 'process_rmcm_data'
s3_access_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_access_key')
s3_secret_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_secret_key')
databricks_api_token = dbutils.secrets.get(scope = 'marvel', key = 'marvel_databricks_api_token')

databricks_job_uri = "/api/2.1/jobs/run-now"
databricks_runs_uri = "/api/2.1/jobs/runs/list"
# Code block to read environment variables from AWS Secret Manager
awsSecretKeyName = 'DATABRICKS_ENV_CONFIG'
session = boto3.session.Session() 
secretClient = session.client(service_name='secretsmanager',aws_access_key_id=s3_access_key,
         aws_secret_access_key= s3_secret_key,region_name=aws_region)
s3_bucket_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_bucket_name']
vpc_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['vpc_name']
mount_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['mount_name']
s3_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_mountpoint']
databricks_job_url = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['databricks_job_url']
event_bus_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['event_bus_name']
s3_marvel_assets_bucket=json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_bucket']
s3_marvel_assets_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_mountpoint']
business_user_recipients=[]
admin_user_recipients = []

        
schema_marvel = "rmcm"
catalog_prod_gold = "marvel-prod-gold"

# Table Names
audit_log_table = "audit_log"

relative_s3_folder = 'rmcm/'
s3_folder_path = f's3a://{s3_bucket_name}/{relative_s3_folder}'
mnt_landing_path = f'{s3_mountpoint}/{relative_s3_folder}'

checkpoint_path = "/tmp/autoloader/rmcm_checkpoint_data"
data_path = "/tmp/autoloader/rmcm_data"
checkpoint_table = "rmcm_checkpoint"

# checkpoint_incremental_path = "/tmp/autoloader/rmcm_incremental_data"
# data_incremental_path = "/tmp/autoloader/rmcm_incremental_data"
# checkpoint_incremental_table = "rmcm_incremental_checkpoint"

# dap_cor = "dap_cor"


environment_prod='prod'

catalog_marvel = "marvel"
catalog_prod_gold = "marvel-prod-gold"
# Schema
schema_marvel = "default"
# Table Names
audit_log_table = "audit_log"

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

print(f"VPC: {vpc_name} | Mountpoint: {s3_mountpoint} | Bucket: {s3_bucket_name} | Mountname: {mount_name}")

data_source = "RMCM"



# COMMAND ----------

# DBTITLE 1,Notification Utility
# MAGIC %run ../utils/notification_util

# COMMAND ----------


