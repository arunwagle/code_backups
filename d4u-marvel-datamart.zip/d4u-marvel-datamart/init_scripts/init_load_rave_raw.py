# Databricks notebook source
# DBTITLE 1,Include File Utility
# MAGIC %run ../utils/file_util

# COMMAND ----------

# DBTITLE 1,Include Zip Utility
# MAGIC %run ../utils/zip_util

# COMMAND ----------

# DBTITLE 1,Include Database Utility
# MAGIC %run ../utils/database_util

# COMMAND ----------

# pipeline_environment = dbutils.widgets.get("pipeline_environment").lower()

# COMMAND ----------

import os
env_name = os.getenv("ENVIRONMENT")
# if (env_name == 'DEV'):
#     import init_script_dev as init_script
# elif (env_name == 'PRE-QA'):
#     import init_script_preqa as init_script
# elif (env_name == 'QA'):
#     import init_script_qa as init_script
# else:
#     import init_script_prod as init_script

# COMMAND ----------

# DBTITLE 1,Pipeline Configurations - Rave_raw
job_name = 'load_rave_raw'
databricks_api_token = dbutils.secrets.get(scope = 'marvel', key = 'marvel_databricks_api_token')
git_readonly_token = dbutils.secrets.get(scope = 'marvel', key = 'marvel_databricks_bitbucket_token')
git_baseurl = 'https://sourcecode.jnj.com'
git_projectKey = 'ASX-JADF'
git_repo = 'd4u-marvel-datamart-library'
domain_data_path = "domains/data"
domain_metrics_path = "domain_metrics_attachments"
aws_region = dbutils.secrets.get(scope = 'marvel', key = 'aws_region')
# Code block to read environment variables from AWS Secret Manager
awsSecretKeyName = 'DATABRICKS_ENV_CONFIG'
session = boto3.session.Session() 
secretClient = session.client(service_name='secretsmanager',aws_access_key_id=aws_access_key,
         aws_secret_access_key= aws_secret_key,region_name=aws_region)
s3_bucket_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_bucket_name']
vpc_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['vpc_name']
mount_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['mount_name']
s3_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_mountpoint']
databricks_job_url = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['databricks_job_url']
event_bus_name = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['event_bus_name']
s3_marvel_assets_bucket=json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_bucket']
s3_marvel_assets_mountpoint = json.loads(secretClient.get_secret_value(SecretId=awsSecretKeyName)['SecretString'])['s3_marvel_assets_mountpoint']
dbMarvelPwd = json.loads(secretClient.get_secret_value(SecretId='POSTGRES_AUTH')['SecretString'])['password']
dbMarvelUser =json.loads(secretClient.get_secret_value(SecretId='POSTGRES_AUTH')['SecretString'])['username'] 
dbMarvelHost = json.loads(secretClient.get_secret_value(SecretId='POSTGRES_AUTH')['SecretString'])['host']
dbMarvelPort = "5432"
dbMarvelName = "marvel"
databricks_job_list_uri = "/api/2.1/jobs/list"
databricks_job_uri = "/api/2.1/jobs/run-now"
databricks_runs_uri = "/api/2.1/jobs/runs/list"
databricks_instance= databricks_job_url.split("/")
databricks_instance="https://"+databricks_instance[0]
databricks_job_list_api = f"{databricks_instance}{databricks_job_list_uri}"
databricks_run_job_api = f"{databricks_instance}{databricks_job_uri}"
databricks_runs_list_api = f"{databricks_instance}{databricks_runs_uri}"
business_user_recipients=[]
admin_user_recipients = []
shared_workspace_folder_path = "/Workspace/Shared/ProgListingCache/"
column_labels_file_name = "column_labels.csv"
data_source = "RAVE RAW"
print(data_source)

if (pipeline_environment == "release") or (pipeline_environment == ""):
        
    s3_study_domains_file = f"{s3_mountpoint}/domains/study_domain_definition.json"
    s3_nonclinical_domains_file = f"{s3_mountpoint}/domains/non_clinical_data.json"
    s3_study_folder_name = "lsaf"
    s3_zip_folder = "lsaf/"
    s3_unzipped_folder = "datamart/ExtractionPoint/"
    lsaf_landing_path = "%s/lsaf/" % (s3_mountpoint)
    lsaf_checkpoint_path = "/tmp/autoloader/rave_checkpoint_data"
    lsaf_data_path = "/tmp/autoloader/data"
    zip_extractionpoint_path = "%s/datamart/ExtractionPoint" % (s3_marvel_assets_mountpoint)
    # Catalogs
    catalog_marvel = "marvel"
    catalog_uat_silver = "marvel-uat-silver"
    catalog_uat_gold = "marvel-uat-gold"
    catalog_prod_silver = "marvel-prod-silver"
    catalog_prod_gold = "marvel-prod-gold"
    # Schema
    schema_marvel = "default"
    # Table Names
    checkpoint_table = "rave_raw_checkpoint"
    audit_log_table = "audit_log"
#     business_user_recipients = init_script.business_user_recipients
#     admin_user_recipients = init_script.admin_user_recipients
elif (pipeline_environment == "qa"):
    s3_study_folder_name = "lsaf-qa"
    s3_zip_folder = "lsaf-qa/"
    s3_unzipped_folder = "datamart/ExtractionPoint-QA/"
    lsaf_landing_path = "%s/lsaf-qa/" % (s3_mountpoint)
    lsaf_checkpoint_path = "/tmp/autoloader/study_checkpoint_data_qa"
    lsaf_data_path = "/tmp/autoloader/data-qa"
    zip_extractionpoint_path = "%s/datamart/ExtractionPoint-QA" % (s3_marvel_assets_mountpoint)
    s3_study_domains_file = f"{s3_mountpoint}/domains/study_domain_definition.json"
    s3_nonclinical_domains_file = f"{s3_mountpoint}/domains/non_clinical_data.json"
    # Catalogs
    catalog_marvel = "marvel_qa"
    # catalog_uat_silver = "marvel-uat-silver_qa"
    catalog_uat_gold = "marvel-uat-gold_qa"
    # catalog_prod_silver = "marvel-prod-silver_qa"
    catalog_prod_gold = "marvel-prod-gold_qa"
    # Schema
    schema_marvel = "default"
    # Table Names
    checkpoint_table = "rave_raw_checkpoint_qa"
    audit_log_table = "audit_log"
else:
    s3_zip_folder = "lsaf/"
    s3_unzipped_folder = "datamart/ExtractionPoint"
    lsaf_landing_path = "%s/lsaf/" % (s3_mountpoint)
    lsaf_checkpoint_path = "/tmp/autoloader/rave_checkpoint_data"
    lsaf_data_path = "/tmp/autoloader/data"
    zip_extractionpoint_path = "%s/datamart/ExtractionPoint" % (s3_marvel_assets_mountpoint)
    s3_study_domains_file = f"{s3_mountpoint}/domains/study_domain_definition.json"
    s3_nonclinical_domains_file = f"{s3_mountpoint}/domains/non_clinical_data.json"
    # Catalogs
    catalog_marvel = "marvel"
    # catalog_uat_silver = "marvel-uat-silver"
    catalog_uat_gold = "marvel-uat-gold"
    # catalog_prod_silver = "marvel-prod-silver"
    catalog_prod_gold = "marvel-prod-gold"
    # Schema
    schema_marvel = "default"
    # Table Names
    checkpoint_table = "clinical_study_checkpoint"
    audit_log_table = "audit_log"

s3_access_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_access_key')
s3_secret_key = dbutils.secrets.get(scope = 'marvel', key = 'marvel_landing_zone_secret_key')

data_model="Rave"

# COMMAND ----------

# MAGIC %run ../utils/notification_util
