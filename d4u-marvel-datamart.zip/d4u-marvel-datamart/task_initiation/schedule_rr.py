# Databricks notebook source
# DBTITLE 1,est
# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

import psycopg2
lifecycles = ['DEV', 'UAT', 'PROD']
run_date = dbutils.widgets.get("overrideRunDate")

# COMMAND ----------

from pyspark.sql.functions import trim,col
import json
def site_id(lifecycle, protocol_num):
    catalog_name = f"`marvel-{lifecycle.lower()}-gold`"
    schema_name = f"{protocol_num.lower()}"
    site_table = "d4u_basic_site_page_filters"
    subject_table = "d4u_basic_subject_page_filters"

    if spark.sql(f"SHOW SCHEMAS IN {catalog_name} LIKE '{schema_name}'").count() == 0:
        print(f"{schema_name}: empty")
        return json.dumps([])
    
    site_exists = spark.sql(f"SHOW TABLES IN {catalog_name}.`{schema_name}` LIKE '{site_table}'").count() > 0
    subject_exists = spark.sql(f"SHOW TABLES IN {catalog_name}.`{schema_name}` LIKE '{subject_table}'").count() > 0

    if site_exists:
        df = spark.sql(f"SELECT * FROM {catalog_name}.`{schema_name}`.{site_table}")
        if any(c.lower() == "siteid" for c in df.columns):
            siteid_col = next(c for c in df.columns if c.lower() == "siteid")
            site_id = [row["SITEID"] for row in df.select(trim(col(siteid_col)).alias("SITEID")).distinct().collect()]
            return json.dumps(site_id)
    elif subject_exists:
        df = spark.sql(f"SELECT * FROM {catalog_name}.`{schema_name}`.{subject_table}")
        if any(c.lower() == "siteid" for c in df.columns):
            siteid_col = next(c for c in df.columns if c.lower() == "siteid")
            site_id = [row["SITEID"] for row in df.select(trim(col(siteid_col)).alias("SITEID")).distinct().collect()]
            return json.dumps(site_id)
    else:
        return json.dumps([])

# COMMAND ----------

connection = None
cursor = None
response = ""

try:
    print('Connection to DB')
    connection = psycopg2.connect(user=dbMarvelUser,
                                  password=dbMarvelPwd,
                                  host=dbMarvelHost,
                                  port=dbMarvelPort,
                                  database=dbMarvelName)
    cursor = connection.cursor()

    for lifecycle in lifecycles:
        protocolQuery = f"""SELECT distinct protocol_num ,l."label" 
            FROM dre.study_lifecycle_version slv
            JOIN dre.study_lifecycle_assets sla ON slv.id = sla.study_lifecycle_version_id
            JOIN dre.study_rr rr ON sla.asset_version_id = rr.id
            JOIN dre.study_lifecycle sl ON sl.id = slv.study_lifecycle_id 
            JOIN dre.lifecycle l ON l.id = sl.lifecycle_id AND l."label" = '{lifecycle}'
            WHERE is_latest"""
        cursor.execute(protocolQuery)
        protocol_nums = [row[0] for row in cursor.fetchall()]
        print(f'Number of protocol numbers in {lifecycle} lifecycle: {len(protocol_nums)}')
        connection.commit() 

        for protocol_num in protocol_nums:
            listingQuery = f"""SELECT array_agg(DISTINCT a.rrId),run_date::text FROM (
                    SELECT asset_id as rrId,
                        dre.get_next_trigger_date(srr.id,'{lifecycle}',CASE WHEN TRIM('{run_date}') != '' THEN NULLIF('{run_date}','')::timestamp  without time zone ELSE current_timestamp ::timestamp without time zone END,'') as nextTriggerDate,
                        srr.label, srr.is_active,
                        CASE WHEN TRIM('{run_date}') != '' THEN NULLIF('{run_date}','')::timestamp without time zone ELSE current_timestamp ::timestamp without time zone END AS run_date
                    FROM dre.get_study_rr_table('{protocol_num}','{lifecycle}') srr
                    WHERE srr.config->'trigger_config'->0->>'type' = 'Schedule'
                    and srr.config->>'taskLevel'='Listing'
                    AND srr.is_active
                ) a 
                WHERE nextTriggerDate <= run_date
                group by run_date
                """
            cursor.execute(listingQuery)
            listing_record = cursor.fetchone()
            connection.commit()

            siteQuery = f"""SELECT array_agg(DISTINCT a.rrId),run_date::text FROM (
                    SELECT asset_id as rrId,
                        srr.label, srr.is_active,
                        CASE WHEN TRIM('{run_date}') != '' THEN NULLIF('{run_date}','')::timestamp without time zone ELSE current_timestamp ::timestamp without time zone END AS run_date
                    FROM dre.get_study_rr_table('{protocol_num}','{lifecycle}') srr
                    WHERE srr.config->'trigger_config'->0->>'type' = 'Schedule'
                    and srr.config->>'taskLevel'='Site'
                    AND srr.is_active
                ) a 
                group by run_date
                """
            cursor.execute(siteQuery)
            site_record = cursor.fetchone()
            connection.commit()


            for record, site in [
                (listing_record, "[]"),
                (site_record, f"{site_id(lifecycle, protocol_num)}")]:
                if record is not None :
                    try:
                        cursor.execute(f"""SELECT * FROM dre.create_rr_task_bulk('{record[0]}','{protocol_num}','{lifecycle}','data4you_dev@its.jnj.com',true,true,'{site}'::jsonb,'{record[1]}')""")
                        connection.commit()
                        print(f'Created tasks for Protocol Number - {protocol_num} in {lifecycle} lifecycle')
                    except Exception as e:
                        print(f"Error in creating the task for Protocol Number - {protocol_num} in {lifecycle} Lifecycle")
                        connection.rollback() 
                        print(e)
                else:
                    print(f"No Task to be created for Protocol Number - {protocol_num} in {lifecycle} lifecycle")

    cursor.close()
    connection.close()
except Exception as e:
    raise e
finally:
    if cursor:
        cursor.close()
    if connection:
        connection.close()
