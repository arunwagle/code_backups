# Databricks notebook source
pipeline_environment = dbutils.widgets.get("pipelineEnvironment").lower()
databricks_instance = dbutils.widgets.get("databricksInstance")
study_data_job_id = dbutils.widgets.get("processStudyJobId")

# COMMAND ----------

print(f"processStudyJobId: {study_data_job_id}")

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_css

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/date_util

# COMMAND ----------

import re
import os
import json
import requests
import datetime
from datetime import datetime as dt

# COMMAND ----------

# DBTITLE 1,Build & Call Process Clinical Study Job API
databricks_run_job_api = f"{databricks_instance}{databricks_job_uri}"
databricks_runs_list_api = f"{databricks_instance}{databricks_runs_uri}"
print(databricks_runs_list_api)

# Intialize audit log table based on environment variable
initialize_audit_log_table(catalog_marvel, schema_marvel, audit_log_table)

# print(f"Checkpoint Table: {checkpoint_table}")
checkpoint_query =f"SELECT path, file_arrival_timestamp, is_processed FROM {checkpoint_table} WHERE is_processed = 0 and path LIKE '%.zip'"
df_checkpoint_data = spark.sql(checkpoint_query)

print(s3_bucket_name)
file_path_trim_part = "s3a://%s" % (s3_bucket_name)
print(file_path_trim_part)
global batch_id
if (df_checkpoint_data.count() > 0):
    checkpoint_collect = df_checkpoint_data.collect()  
    print(checkpoint_collect)
    for row in checkpoint_collect:
        s3_file_path = row["path"]
        print('s3_file_path: ',s3_file_path)
        print('s3_mountpoint: ',s3_mountpoint)
        file_mount_path = s3_file_path.replace(file_path_trim_part, s3_mountpoint)        
        # Get only file name from the path
        file_name = get_file_name(file_mount_path)
        # Get only the folder path from the path
        folder_path = get_folder_path(file_mount_path)
        print('file_name: ',file_name)
        print('folder_path: ',folder_path)

        study_id = None
        domain_model = None
        environment = None
        data_model = "css" 

        #Study File Name format Validation
        try:
            # file_name_pattern = re.compile("[A-Za-z0-9-]+\_([cC][sS][sS])\_.+\.zip")
            # trim_study_file_name = file_name[0:file_name.rfind(".")]
            # file_name_parts = trim_study_file_name.split("_")
            # study_id = file_name_parts[0].lower()
            # data_model = file_name_parts[1]
            # environment = "prod" 
            # environment = environment.lower()
            # load_timestamp = dt.now().isoformat()
            # print(load_timestamp)
            # batch_id=create_audit_log(study_data_job_id, job_name, study_id, environment, load_timestamp)

          
            # file_name_pattern = re.compile("(?P<study_id>[A-Za-z0-9-\_]+)\_(?P<domain_model>css){1}\_(?P<date_time_stamp>.+){1}\_(?P<environment>uat|prod){1}\.zip", re.IGNORECASE)

            file_name_pattern = re.compile("(?P<study_id>[A-Za-z0-9-\_]+)\_(?P<domain_model>css){1}\_(?P<date_time_stamp>.+){1}\.zip", re.IGNORECASE)

            file_match = file_name_pattern.match(file_name)
            is_valid_fileName = False

            # File name validity check 1 of 2 (RegEx test)
            if file_match:
                file_match_dict = file_match.groupdict()

                # Parse out values from regex dictionary using subscript.
                study_id = file_match_dict['study_id']
                domain_model = file_match_dict['domain_model']
                environment = "prod" 
                date_time_stamp_string = file_match_dict['date_time_stamp']

                load_timestamp = dt.now().isoformat()
                batch_id=create_audit_log(study_data_job_id, job_name, study_id, environment, load_timestamp)

                is_valid_date = isValidDate(date_time_stamp_string)

                # File name validity check 2 of 2 (After parsing tokens & checking date/time stamp token)
                if is_valid_date:
                    is_valid_fileName = True
                    print(f"Study file has a valid naming convention: {file_name}")

                    print(f"study_id: {study_id}")
                    print(f"domain_model: {domain_model}")
                    print(f"environment: {environment}")
                    print(f"date_time_stamp_string: {date_time_stamp_string}")
                    
                    # study_id needs to be lower case for API call.
                    study_id = study_id.lower()
                    print(f"study_id (to lower): {study_id}")

                    # batch_id = create_audit_log(study_data_job_id, job_name, study_id, environment, load_timestamp)
                    print(f"batch_id: {batch_id}")
                    
                else:
                    msg = f"ERROR - CSS Date is invalid {date_time_stamp_string} "
                    print(msg)
                    checkpoint_update_query = f"UPDATE {checkpoint_table} SET is_processed = 1, job_id = '{study_data_job_id}' WHERE path = '{s3_file_path}'"
                    execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")
                    raise Exception(msg)


                    

            if  file_name_pattern.match(file_name) != None:
                # Parse Study File Name
                
                
                auth_header = f"Bearer {databricks_api_token}"
                headers = {
                        'Authorization': auth_header,
                        'Content-Type': 'application/json'
                        }
                data = {
                    "job_id": study_data_job_id,
                    "notebook_params": { "studyFilePath" : s3_file_path, "pipelineEnvironment" : pipeline_environment, "batchId": batch_id, "studyId": study_id,"data_model":data_model,"environment": environment, "loadTimestamp": load_timestamp, "date_time_stamp_string": date_time_stamp_string }
                    }
                
                jobs_response = requests.post(databricks_run_job_api, headers=headers, json=data)
                print(f"File: {s3_file_path} | API Response: {jobs_response}")
                
                if(jobs_response.status_code == 200):
                    print("Job has been triggered successfully")
                    runs_response = requests.get(databricks_runs_list_api, headers = headers)
                    print(f"run Response: {runs_response}")
                    if(runs_response.status_code == 200):
                        runs_response_json = runs_response.json()
                        if "runs" in runs_response_json:
                            current_run_id = runs_response_json["runs"][0]["run_id"]
                            print(f"Job submitted for study file {s3_file_path} with run_id: {current_run_id}")
                            # Update run id into audit log table
                            update_audit_log_run_id(batch_id, current_run_id, "STARTED")
                            # Update study process flag in checkpoint table
                            checkpoint_update_query = f"UPDATE {checkpoint_table} SET study_id = '{study_id}', environment = '{environment}', is_processed = 1, job_id = '{study_data_job_id}', run_id = {current_run_id}, process_start_timestamp = '{load_timestamp}' WHERE path = '{s3_file_path}'"
                            execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")
                            print(f"Checkpoint table updated for run_id: {current_run_id}")
                            
                        else:
                            print("No active runs exist")
                    else:
                        print("Get active runs API call is not successful")
                else:
                    print(f"Submit job run for study {study_id} is not successful")
                    update_audit_log_by_batch_id(batch_id,"FAILED", "API call to submit job has failed")

            else:
                msg = f"ERROR - CSS zip file {file_name} naming convention is incorrect. Job could not proceed. Expected naming convention: [studyid]_CSS_yyyymmddThhmmss.zip"
                print(msg)
                checkpoint_update_query = f"UPDATE {checkpoint_table} SET is_processed = 1, job_id = '{study_data_job_id}' WHERE path = '{s3_file_path}'"
                execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")
                raise Exception(msg)
                
        except Exception as e:
            error_msg = str(e)
            error_msg = error_msg.replace("'","").replace("\"","")
            print(error_msg)
            update_audit_log_by_batch_id(batch_id,"FAILED",error_msg)
            errant_tables = "N/A"
            load_timestamp = dt.now().isoformat()
            study_environment = "prod"
            study_environment = study_environment.lower()
            if (study_environment[0] == '_'):
                study_environment = study_environment[1:]
            if study_environment not in ('prod','uat'):
                study_environment = "Invalid Study Environment"
                
            domainstats={}
            message = build_clinical_study_json(study_id,errant_tables,study_environment,study_data_job_id,"",load_timestamp,"",error_msg,domainstats)
            send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
            raise e
            dbutils.notebook.exit(error_msg)
else:
    print("No study file exist to process")
