# Databricks notebook source
# DBTITLE 1,Get pipeline task variables
log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "log_file", default = "", debugValue = "")
temp_study_id= dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "temp_study_id", default = "", debugValue = "")
pipeline_environment = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "pipeline_environment", default = "release", debugValue = "")
target_study_extraction_path = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "target_study_extraction_path", default = "", debugValue = "")
study_data_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "study_data_file", default = "", debugValue = "")
study_data_path = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "study_data_path", default = "", debugValue = "")
batch_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "batch_id", default = "", debugValue = "")
study_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "study_id", default = "", debugValue = "")
study_domain_model = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "domain_model", default = "", debugValue = "")
study_environment = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "environment", default = "", debugValue = "")
job_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "job_id", default = "", debugValue = "")
run_id = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "run_id", default = "", debugValue = "")
load_timestamp = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "load_timestamp", default = "", debugValue = "")
thread_count = dbutils.jobs.taskValues.get(taskKey = "initiate_process_css_data", key = "thread_count", default = "8", debugValue = "")
thread_count=int(thread_count)
study_schema_name = study_id.lower()
# Define Silver & Gold Catalog Names
catalog_silver = f"marvel-{study_environment}-silver_qa" if (pipeline_environment == "qa") else f"marvel-{study_environment}-silver"
catalog_gold = f"marvel-{study_environment}-gold_qa" if (pipeline_environment == "qa") else f"marvel-{study_environment}-gold"
