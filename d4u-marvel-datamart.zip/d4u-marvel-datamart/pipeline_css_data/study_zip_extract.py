# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_css

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

# DBTITLE 1,Unzipping File and extracting CSV files from zip to Extraction Point Folder
try:
    trim_string = "%s/" % (s3_mountpoint)
    # DJM 3/15/24 Remove debug code - print(s3_mountpoint)
    # DJM 3/15/24 Remove debug code - print(trim_string)
    trimmed_study_folder_path = study_data_path.replace(trim_string, "")
    trimmed_study_source_path = "%s/%s" % (trimmed_study_folder_path, study_data_file)
    # DJM 3/15/24 Remove debug code - print(trimmed_study_source_path)
    
    s3_study_folder_name = study_data_file.replace(".zip", "")
    s3_study_folder_path_part = f"{s3_unzipped_folder}{s3_study_folder_name}"
    
    # DJM 3/15/24 Remove debug code - print(s3_unzipped_folder)
    # DJM 3/15/24 Remove debug code - print(s3_study_folder_path_part)

    # Create study folder
    s3_target_extraction_full_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
    result = dbutils.fs.mkdirs(s3_target_extraction_full_path)
    # DJM 3/15/24 Remove debug code - print(s3_marvel_assets_bucket)
    # DJM 3/15/24 Remove debug code - print(s3_target_extraction_full_path)
    # DJM 3/15/24 Remove debug code - print(result)

    
    if (result):
        # Extract zip file content
        extract_zip_file(trimmed_study_source_path, f"{target_study_extraction_path}", s3_bucket_name,s3_marvel_assets_bucket)
        #logger.info(f"Domain Data Files Extracted Succesfully from {study_data_file} file")
    else:
        print(f"S3 folder creation failed for path - {study_folder_path}")
        #logger.error(f"ERROR - S3 folder creation failed for path {study_folder_path}. CSS file could not be extracted and pipeline execution is aborted.")
        raise Exception(f"ERROR - S3 folder creation failed for path {study_folder_path}. CSS file could not be extracted and pipeline execution is aborted.")
except Exception as e:
    # logger.error("Error while Extracting the zip file")
    # logger.error(e)
    # log_file_data=read_log_file(p_filename)      
    # write_log_file(initiate_process_log_file,log_file_data,"","","","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "N/A" 
    domainstats={}
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

# DBTITLE 1,Listing Files from DBFS and fetching the domain names
try:
    domain_files = dbutils.fs.ls(s3_target_extraction_full_path)
    # DJM 3/15/24 Performance Tweak - print(domain_files)
    if domain_files:
        df_domain_files = pd.DataFrame(domain_files)
        # DJM 3/15/24 Performance Tweak - print(df_domain_files)
        list_file_names = list(df_domain_files["name"])
        # DJM 3/15/24 Performance Tweak - print(list_file_names)
        meta_files =[]
        pattern_string = ".parquet"
        
        for x in list_file_names:
          if x.endswith(pattern_string):
            meta_files.append(x)
        domains =[x.split(".")[0] for x in meta_files]
        # DJM 3/15/24 Performance Tweak - print(domains)
        if domains:
            print(domains)
        else:
            raise Exception("ERROR:CSS Zip File Compression is incorrect")
    else:
      raise Exception("ERROR:CSS Zip File is Empty")
except Exception as e:
    # logger.error("Error occured at while fecthing the file names")
    # logger.error(e)
    # log_file_data=read_log_file(p_filename)      
    # write_log_file(initiate_process_log_file,log_file_data,"","","","","","","",log_file)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats={}
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
    raise e
    dbutils.notebook.exit(error_msg)



# COMMAND ----------

# try:
#     log_file_data=read_log_file(p_filename)
#     dbutils.jobs.taskValues.set(key   = "study_zip_log_file", value = log_file_data)
# except Exception as e:
#     raise e

