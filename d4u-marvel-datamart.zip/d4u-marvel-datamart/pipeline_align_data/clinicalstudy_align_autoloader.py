# Databricks notebook source
# DBTITLE 1,Get Pipeline Environment
pipeline_environment = dbutils.widgets.get("pipeline_environment").lower()

# COMMAND ----------

# DBTITLE 1,Initialization
# MAGIC %run ../init_scripts/init_load_align

# COMMAND ----------

# DBTITLE 1,Create checkpoint table if not exists
# MAGIC %sql
# MAGIC -- Create clinical_study_align_checkpoint table, if not exists
# MAGIC CREATE TABLE IF NOT EXISTS hive_metastore.default.clinical_study_align_checkpoint (path STRING, file_arrival_timestamp TIMESTAMP, length BIGINT, study_id STRING, environment STRING, is_processed STRING, job_id STRING, run_id LONG, process_start_timestamp TIMESTAMP, process_end_timestamp TIMESTAMP) USING DELTA PARTITIONED BY (study_id, environment)

# COMMAND ----------

# DBTITLE 1,Configuration

sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", s3_access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", s3_secret_key)

# If you are using Auto Loader file notification mode to load files, provide the AWS Region ID.

sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

# aws_bucket_name = "itx-cer-marvel-landing-zone"

# COMMAND ----------

# DBTITLE 1,Define autoloader to monitor S3 bucket
from pyspark.sql.functions import lit
from pyspark.sql.types import StringType, TimestampType, IntegerType, LongType

print(s3_study_folder_name)
print(lsaf_checkpoint_path)
print(checkpoint_table)

df = spark.readStream.format('cloudFiles') \
    .option('cloudFiles.format', 'binaryFile') \
    .option('cloudFiles.includeExistingFiles', 'true') \
    .option('cloudFiles.useNotifications', 'true') \
    .option('cloudFiles.region', aws_region) \
    .option('cloudFiles.awsAccessKey', s3_access_key) \
    .option('cloudFiles.awsSecretKey', s3_secret_key) \
    .option('pathGlobFilter', '*_{ALIGN,align}_*.zip') \
    .load("s3a://%s/%s" % (s3_bucket_name, s3_study_folder_name))

df_custom = df.drop("content") \
    .withColumn("study_id", lit(None).cast(StringType())) \
    .withColumn("environment", lit(None).cast(StringType())) \
    .withColumn("is_processed", lit("0")) \
    .withColumn("job_id", lit(None).cast(StringType())) \
    .withColumn("run_id", lit(None).cast(LongType())) \
    .withColumn("process_start_timestamp", lit(None).cast(TimestampType())) \
    .withColumn("process_end_timestamp", lit(None).cast(TimestampType())) \
    .withColumnRenamed("modificationTime", "file_arrival_timestamp")

df_custom.writeStream \
    .option('checkpointLocation', lsaf_checkpoint_path) \
    .table(checkpoint_table)
