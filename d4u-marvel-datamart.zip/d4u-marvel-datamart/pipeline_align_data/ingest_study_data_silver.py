# Databricks notebook source
from pyspark.sql.functions import regexp_replace, md5, concat_ws, array, col, lit, struct, to_json, when, coalesce
from pyspark.sql.types import MapType, StringType, ArrayType, TimestampType
from delta.tables import *
import functools
import re
import operator
from datetime import datetime as dt
from pyspark.sql.functions import to_date,expr


# COMMAND ----------

# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_align

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

# DBTITLE 1,Read Pipeline Task Values
domains = dbutils.jobs.taskValues.get(taskKey = "read_postgres_db", key = "available_domains", default = "error", debugValue = "")
config_dict = dbutils.jobs.taskValues.get(taskKey = "read_postgres_db", key = "config_dict", default = "error", debugValue = "")

# COMMAND ----------

def SavetoSilver(file_name, config_dict,catalog_silver,study_schema_name,study_extraction_path,catalog_gold,temp_study_id):
    try:
        StudyID=study_schema_name.upper()
        print(f"StudyID: {StudyID}")
          
        print(f"File Name: {file_name}")
          
        composite_keys = config_dict[f"{file_name}"]['RecIdKeys']
        print(f"Composite Keys: {composite_keys}")
          
        RECVER_KEY = config_dict[f"{file_name}"]['RecverKey']
        print(f"Record Version Keys: {RECVER_KEY}")
          
        table_name = config_dict[f"{file_name}"]['TableName']
        print(f"Table Name: {table_name}")
          
        spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")
        spark.conf.set("spark.sql.parquet.enableVectorizedReader",False)
          
        if not (tableExists(catalog_silver,study_schema_name,table_name)):
            print(f"{table_name} does not exist in {catalog_silver}.{study_schema_name}")
            print(f"File Path: {study_extraction_path}{file_name}.parquet")
              
            df = spark.read.parquet(f"{study_extraction_path}{file_name}.parquet") 
              
            df_final=df.withColumn("D4U_RECID",lit(md5(concat_ws("||",*composite_keys)))).withColumn("D4U_RECVER",md5(concat_ws("||",*RECVER_KEY))).withColumn("D4U_DATAPROV",array(to_json(create_map(lit("table"),lit(table_name),lit("D4U_RECID"),md5(concat_ws("||",*composite_keys)),lit("D4U_RECVER"),md5(concat_ws("||",*RECVER_KEY))))).cast("string")).withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp')).withColumn("D4U_ISACTIVE", lit(True)).withColumn("D4U_ISDROP", lit(False))
            schema = df_final.schema
              
            # Create table if not exists in Silver and Gold layers
            silver_table = createTableIfNotExist(catalog_silver, study_schema_name, table_name, schema)
            gold_table = createTableIfNotExist(catalog_gold, study_schema_name, table_name, schema)
              
            silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.`{table_name}`")).alias('silver')
            silverTable.alias("silver").merge(source = df_final.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute()

        else:  
            #  If table_name not in list_a check for the table names from postgres DRE
            print(f"{table_name} exists in {catalog_silver}.{study_schema_name}")

            # Variable "table_exclusion_list" is referred from init_align
            if table_name not in table_exclusion_list:
                logger.info(f"File Path: {study_extraction_path}{file_name}.parquet")
                df_input = spark.read.parquet(f"{study_extraction_path}{file_name}.parquet")

                # Get records from incoming file and compute D4U columns    
                df_final = df_input.withColumn("D4U_RECID",lit(md5(concat_ws("||",*composite_keys)))).withColumn("D4U_RECVER",md5(concat_ws("||",*RECVER_KEY))).withColumn("D4U_DATAPROV",array(to_json(create_map(lit("table"),lit(table_name),lit("D4U_RECID"),md5(concat_ws("||",*composite_keys)),lit("D4U_RECVER"),md5(concat_ws("||",*RECVER_KEY))))).cast("string")).withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp')).withColumn("D4U_ISACTIVE", lit(True)).withColumn("D4U_ISDROP", lit(False))
                
                silverTable = DeltaTable.forName(spark, str(f"`{catalog_silver}`.`{study_schema_name}`.{table_name}")).alias('silver')
                    
                logger.info(f"Catalog: {catalog_silver} | Study: {study_schema_name} | Table: {table_name}")
                    
                # Get silver table records that are active & not deleted
                silver_records = silverTable.toDF().where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver') 
                column_list = silver_records.columns 
                    
                # Get new records eligible to insert (i.e. Records present in incoming dataset but not present in Silver table)  
                df_insert = df_final.alias("df").join(silver_records,on = 'D4U_RECID',how = 'leftanti')
                df_insert=df_insert.select(column_list) 

                logger.info(f'{table_name}: {df_insert.count():,} records in to insert')

                # Get dropped records
                df_drop = silver_records.join(df_final.alias("df"),on = 'D4U_RECID',how = 'leftanti')
                df_drop = df_drop.withColumn("D4U_ISDROP",lit(True)).withColumn("D4U_RECVERDATE",lit(load_timestamp).cast('timestamp'))
                df_drop = df_drop.select(column_list)

                logger.info(f'{table_name}: {df_drop.count():,} records in to drop')

                # Get updated records
                df_update = silver_records.join(df_final.alias("df"), (col("df.D4U_RECID")==col("silver.D4U_RECID")) & (col("df.D4U_RECVER")!=coalesce(col("silver.D4U_RECVER"), lit(""))),how = 'inner').select(['df.*'])
                df_update=df_update.select(column_list)

                logger.info(f'{table_name}: {df_update.count():,} records in to update')

                df_insertupdatedrop = df_insert.union(df_drop).union(df_update)

                logger.info(f'{table_name}: {silverTable.toDF().count():,} records in silver before merge')
                logger.info(f'{table_name}: Merging { df_insertupdatedrop.count()} records into silver')
                    
                dropquery = spark.sql(f"drop table IF EXISTS `{catalog_marvel}`.`default`.temp_{study_schema_name}_{table_name}_align_data")

                df_insertupdatedrop.write.mode("overwrite").format("delta").option("overwriteSchema", "true").option('delta.columnMapping.mode', 'name').option('delta.minReaderVersion','2').option('delta.minWriterVersion' ,'5').saveAsTable(f"`{catalog_marvel}`.`default`.temp_{study_schema_name}_{table_name}_align_data")

                df_insert_update_drop = spark.sql(f"select * from `{catalog_marvel}`.`default`.temp_{study_schema_name}_{table_name}_align_data")
                    
                #set previous records as false for updated records
                silverTable.alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID') == col('silver.D4U_RECID')).whenMatchedUpdate(set = {"silver.D4U_ISACTIVE": lit(False)}).execute()            
              
                # Insert all new and updated records
                silverTable.alias("silver").merge(source = df_insert_update_drop.alias("df"),condition = col('df.D4U_RECID').isNull()).whenNotMatchedInsertAll().execute() 

                logger.info(f'{table_name}: {silverTable.toDF().count():,} records in silver after merge')
                dropquery = spark.sql(f"drop table IF EXISTS `{catalog_marvel}`.`default`.temp_{study_schema_name}_{table_name}_align_data")
                
            else:
                logger.info(f'Skipping table {table_name} in exclusion list')
                pass
    except Exception as p:
        global error_process
        global error_table
        error_process = "ingest_align_data_silver"       
        error_table = f"{catalog_silver}.{study_schema_name}.{file_name}"
        raise p

# COMMAND ----------

try:
    #logger.info("Silver Layer Tables Insertion Started")
    print(s3_marvel_assets_mountpoint)
    study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
    parallel_runs = ThreadPool(thread_count)
    parallel_runs.starmap(SavetoSilver,zip(domains, repeat(config_dict), repeat(catalog_silver), repeat(study_schema_name), repeat(study_extraction_path), repeat(catalog_gold), repeat(temp_study_id)))
    #logger.info("Silver Layer Tables Insertion Completed")
except Exception as e:
    # logger.error("Silver Layer Tables Insertion Failed")
    # logger.error(e)
    # log_file_data=read_log_file(p_filename)      
    # write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,
    #metadata_log_file,log_file_data,"","","","",log_file)
    handle_error(e, error_process, error_table,domains)
