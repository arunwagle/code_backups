# Databricks notebook source
import requests
import json
import base64
from pathlib import Path, PurePath
import os

# COMMAND ----------

# dbutils.widgets.text("pipeline_environment", "release")
# dbutils.widgets.text("studyId", "77242113PSO3001_D4U")
# dbutils.widgets.text("dataEnv", "dev")
# dbutils.widgets.text("batchId", "12345")
# dbutils.widgets.text("run_id", "")
# dbutils.widgets.text("job_id", "12345")
# dbutils.widgets.text("commit_id", "7f8494cdbaf")
# dbutils.widgets.text("notebookpath", "Basic_VS/Basic_VS")
# dbutils.widgets.text("process_timestamp", "")
# dbutils.widgets.text("labelFilePath", "/Workspace/Shared/ProgListingCache/7f8494cdbaf/Basic_VS/column_labels.csv")

# COMMAND ----------

pipeline_environment=dbutils.widgets.get("pipeline_environment")
studyId = dbutils.widgets.get("studyId")
dataEnv = dbutils.widgets.get("dataEnv")
batch_id= dbutils.widgets.get("batchId")
run_id=dbutils.widgets.get("run_id")
job_id=dbutils.widgets.get("job_id")
gitCommit = dbutils.widgets.get("commit_id")
path = dbutils.widgets.get("notebookpath")
load_timestamp = dbutils.widgets.get("process_timestamp")
rootfolder = os.path.split(path)
rootfolder= rootfolder[0] 
gitPath =f"/{rootfolder}"

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./dre_utils

# COMMAND ----------

class GitOptions(object):
    def __init__(self, my_dict):
        for key in my_dict:
            setattr(self, key, my_dict[key])

# COMMAND ----------

def createDirIfNotExist(dir, label = None):
    if not dir.exists():
        print()
        print(f"Creating {label or 'directory'} {dir.absolute()}")
        dir.mkdir(parents=True)
    else:
        print()
        print(f"Found existing {label or 'directory'} {dir.absolute()}")

# COMMAND ----------

def gitRepoApi(options, apiPath, start=0, asJson=True):

    if apiPath.startswith("/"):
        apiPath = apiPath[1:]

    url = f"{options.baseurl}/rest/api/latest/projects/{options.projectKey}/repos/{options.repo}/{apiPath}"

    headers = {"Accept": "application/json", "Authorization": f"Bearer {options.token}"}

    # Add pagination parameter
    params = {"start": start}
 
    response = requests.request("GET", url, headers=headers, params=params)
    

    if response.status_code != 200:
        raise Exception(
            f"Error calling Git API {apiPath} (HTTP {response.status_code}). Response: {gitErrors(response)}"
        )
    elif asJson:
        return json.loads(response.text)
    else:
        return response.text


# COMMAND ----------

def gitErrors(response):
    try:
        return "\n".join([e["message"] for e in json.loads(response.text)["errors"]])
    except Exception as e:
        print("Failed to parse errors from response")
        print(e)
        return response.text

# COMMAND ----------

def gitFetchCommit(options, commit):
    apiPath = f"/commits/{commit}"
    print()
    print(f"Verifying commit {commit}")
    commit = gitRepoApi(options, apiPath)
    print(commit)

# COMMAND ----------

def gitFetchFiles(options, path, commit):

    # Check if the cache path exists
    cache_path = Path(f"{options.work_dir}/{path}")
    # print(f"cache_path: {cache_path}")
    if cache_path.exists():
        print(f"Path {cache_path} exists. Skipping fetch.")
        return

    print(f"Fetching git repo files in path {path} at commit {commit}")

    apiPath = f"/files/{path}?at={commit}"
    list_of_files = []
    start = 0
    is_last_page = False

    while (is_last_page ==False):
        files = gitRepoApi(options, apiPath, start=start)
        print(files)
        list_of_files.extend(files["values"])
        start = files.get("nextPageStart", None)
        is_last_page = files.get("isLastPage", True)

    
    print(f'Found {len(list_of_files)} file(s)\n')
    print(f"Downloading files to working directory {options.work_dir}")

    for sourcefile in list_of_files:
        print(f"... {sourcefile} ...")

        localfile = Path(options.work_dir, path, sourcefile)
        print(f"localfile: {localfile}")
        if localfile.exists():
            print(localfile)
            print(f'File {localfile} found in cache')
            continue

        rawFile = gitFetchFileContent(options, Path(path, sourcefile), commit)
        print(f"Ok ({len(rawFile)} bytes fetched)")

        createDirIfNotExist(localfile.parent)

        fileHeader = rawFile.splitlines()[0]

        if fileHeader.startswith('# Databricks notebook source'):
            notebook = Path('/', localfile.relative_to('/Workspace'))
            print(f"notebook: {notebook}")
            saveNotebook(notebook, rawFile)
            print(f'Notebook saved {notebook}')
        else:
            with open(localfile, "w") as f:
                f.write(rawFile)
                print(f"File saved {localfile}")


# COMMAND ----------

def gitFetchFileContent(options, sourcefile, commit):
    apiPath = f"/raw/{sourcefile}?at={commit}"
    return gitRepoApi(options, apiPath, asJson=False)

# COMMAND ----------

def saveNotebook(targetPath, content):

    ctx = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
    host_name = ctx['extraContext']['api_url']
    host_token = ctx['extraContext']['api_token']
    notebook_path = ctx['extraContext']['notebook_path']

    print(host_token)

    data = {
    "content": base64.b64encode(content.encode("utf-8")).decode('ascii'),
    "path": str(targetPath.absolute().with_suffix('')),
    "language": "PYTHON",
    "overwrite": True,
    "format": "SOURCE"
    }

    response = requests.post(f'{host_name}/api/2.0/workspace/import',
        headers={'Authorization': f'Bearer {host_token}'},
        json = data
    ).json()

    print(response)

# COMMAND ----------

def gitFetchProgListing(options, progListingPath, commit):

    # Check commit ID
    # NOTE: Removing the check to reduce the amount of traffic to Bitbucket
    # gitFetchCommit(options, commit)

    gitPath = Path(progListingPath.strip("/"))
    print()
    print(f'Git Path: {gitPath}')

    # create work Directory for storing source code
    work_dir = Path(options.cacheDir, commit)
    createDirIfNotExist(work_dir, 'Working directory')
    options.work_dir = work_dir

    #Look for programmed listing framework commit id
    prog_listing_framework_commit_id = get_prog_listing_framework_commit_id(studyId, dataEnv)

    if prog_listing_framework_commit_id is None:
        prog_listing_framework_commit_id = commit
        print('Using default commit ID from current prog listing: ', prog_listing_framework_commit_id)
    else:
        print('Using commit ID from prog listing framework: ', prog_listing_framework_commit_id)

    labelFilePath = dbutils.widgets.get("labelFilePath")

    if prog_listing_framework_commit_id.lower() != commit.lower():

        labelFilePath = Path(labelFilePath).relative_to(work_dir)
        work_dir = Path(str(work_dir) + f"_{prog_listing_framework_commit_id}")
        labelFilePath = str(Path(work_dir, labelFilePath))
        createDirIfNotExist(work_dir, 'Working directory')
        options.work_dir = work_dir

    dbutils.jobs.taskValues.set(key = 'commit_folder', value = os.path.basename(options.work_dir))
    dbutils.jobs.taskValues.set(key = 'labelFilePath', value = str(labelFilePath))

    # Fetch list of files in /common and store them in cache
    commonFiles = gitFetchFiles(options, "common", prog_listing_framework_commit_id)

    # Fetch list of files in /<ProgListingFolder> and store them in cache
    progListingFiles = gitFetchFiles(options, gitPath, commit)
    

# COMMAND ----------

try:
    

    gitOptions = GitOptions({
        'baseurl': git_baseurl,
        'projectKey': git_projectKey,
        'repo': git_repo,
        'token': git_readonly_token,
        'cacheDir' : Path('/Workspace','Shared','ProgListingCache')
    })
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, studyId, dataEnv, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,dataEnv,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(studyId,dataEnv,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

def initProgrammedListing(options, path, commit):
    createDirIfNotExist(options.cacheDir, 'Git chache')

    gitFetchProgListing(options, path, commit)

    #notebook = Path('/', options.work_dir.relative_to('/Workspace'), path.strip('/'),'')
 
    #return notebook

# COMMAND ----------

try:
    initProgrammedListing(gitOptions, gitPath, gitCommit)
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, studyId, dataEnv, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,dataEnv,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(studyId,dataEnv,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
