# Databricks notebook source
# DBTITLE 1,Import Modules
import time
import requests
import boto3
import json
from pyspark.sql.functions import col
import os
import logging
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
import uuid

logger = logging.getLogger(__name__)
logger.info("logger message")

# COMMAND ----------

def get_widget_value(widget_name):
    value = None
    try:
        value = dbutils.widgets.get(widget_name)
    except Exception as e:
        try: 
            value = globals().get(widget_name)
        except:
            raise e
    print(f'{widget_name} = {value}')
    return value

# COMMAND ----------

# dbutils.widgets.text("study_id", "test_study_id")
# dbutils.widgets.text("environment", "test_environment")
# dbutils.widgets.text("pipeline_environment", "test_pipeline_environment")
# dbutils.widgets.text("source_job_name", "test_source_job_name")
# dbutils.widgets.text("job_id", "test_job_id")
# dbutils.widgets.text("run_id", "test_run_id")
# dbutils.widgets.text("lifecycle", "test_lifecycle")
# dbutils.widgets.text("dataEnv", "test_lifecycle")
# dbutils.widgets.text("devMode", "false")
# dbutils.widgets.text("data_model", "test_data_model")
# dbutils.widgets.text("date_time_stamp_string", "2025-07-18T00:00:00")
# dbutils.widgets.text("listingType", "test_listing_type")
# dbutils.widgets.text("batchId", "test_batchId")

# COMMAND ----------

# DBTITLE 1,Reading Pipeline Parameters
studyId = get_widget_value("study_id")
study_environment = get_widget_value("environment")
pipeline_environment = get_widget_value("pipeline_environment")
source_job_name = get_widget_value("source_job_name")
job_id = get_widget_value("job_id")
run_id = get_widget_value("run_id")
lifecycle = get_widget_value("lifecycle")
devMode = get_widget_value("devMode")
dataModel = get_widget_value("data_model")
dataModel = dataModel.upper()
date_time_stamp_string = get_widget_value("date_time_stamp_string")
listingType = dbutils.widgets.get("listingType")


# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

submit_job_batch_id = get_widget_value("batchId")
if submit_job_batch_id is None:
    # When no batchId is given, this indicates that we have submitted the job from the study setup module in D4U.  So, we need initialize the audit_log records and create a batchId.
    from datetime import datetime as dt
    submit_job_batch_id = create_audit_log_with_run_id(job_id, source_job_name, studyId, study_environment, dt.now().isoformat(), run_id, "STARTED")
    print(f"Generated a batchId for this run: {submit_job_batch_id}")

# Make it available for downstream task
dbutils.jobs.taskValues.set(key="batchId", value=submit_job_batch_id)    

# COMMAND ----------

# MAGIC %run ../utils/lineage_utils

# COMMAND ----------

# MAGIC %run ../utils/jobs_util

# COMMAND ----------

# MAGIC %run ./dre_utils

# COMMAND ----------

# DBTITLE 1,Function- Read basic listings  from dre
try:
    
    run_exist = study_lifecycle_run_exist(study_id = studyId, job_id = job_id, environment = study_environment,dataModel = dataModel , run_id = run_id)
    print(f"run_exist: {run_exist}")
    if run_exist is True:
        msg = f"Found active run for study {studyId} & {study_environment} & {dataModel}"
        update_audit_log_with_partitioning(studyId, study_environment, source_job_name, submit_job_batch_id, "FAILED", msg)
        raise Exception(msg)

    listingAssetIds = ""
    try:
        listingAssetIds = get_widget_value("listingAssetIds")
    except:
        pass

    records = get_marvel_study_listing_config(studyId, study_environment, listingType, dataModel, listingAssetIds)
        
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, submit_job_batch_id, "FAILED", error_msg)
    raise e

# COMMAND ----------

# MAGIC %run ../utils/git_utils

# COMMAND ----------

from pathlib import Path

if len(records) > 0 :
    # Gather all distinct bitbucket_commit values
    commit_ids = list({row["bitbucket_commit"] for row in records})

    # Prepare GitOptions (example, adjust as needed)
    git_options_dict = {
        'baseurl': git_baseurl,
        'projectKey': git_projectKey,
        'repo': git_repo,
        'token': git_readonly_token,
        'cacheDir' : Path('/Workspace','Shared','ProgListingCache')
    }
    options = GitOptions(git_options_dict)

    # Call the new function to fetch common files for each commit
    gitFetchPLFCommon(studyId, study_environment, options, commit_ids)

# COMMAND ----------

# DBTITLE 1,Triggering programmed listing job for all basic listings
try:
    runid_list=[]

    auth_header = f"Bearer {databricks_api_token}"
    headers = {
            'Authorization': auth_header,
            'Content-Type': 'application/json'
                    }

    listing_list = []

    if len(records) > 0 :
        # From init_load_clinical_study
        print(f"Workspace Folder Path: {shared_workspace_folder_path}")

        job_batches = {}

        for row in records:
            listing_asset_id = row["asset_id"]
            listing_type= row["listing_type"]
            listing_name = row["listing_name"]
            listing_title= row["listing_title"]
            bitbucket_commit = row["bitbucket_commit"]
            bitbucket_path = row["bitbucket_path"]
            parameters = row["parameters"]
            recIdKeys = row["recIdKeys"]
            recVersionKeys = row["recVersionKeys"]
            load_timestamp = dt.now().isoformat()

            workspacepath=f"{shared_workspace_folder_path}{bitbucket_commit}"

            bit_bucket_folder_name=bitbucket_path.split('/')
            bit_bucket_folder_name=bit_bucket_folder_name[0]
            
            column_labels_file_path = "NA"
            if column_labels_file_name is not None:
                column_labels_file_path=f"{shared_workspace_folder_path}{bitbucket_commit}/{bit_bucket_folder_name}/{column_labels_file_name}"
                print(f"Column Labels File Path: {column_labels_file_path}")

            job_name = f"programmed_listing_{listing_type}_{listing_name}"
            
            pgm_job_batch_id = str(uuid.uuid4())
            job_batches[job_name] = pgm_job_batch_id

            # Prepare the pgm_data for the current listing
            pgm_data = {
                "listing_asset_id": listing_asset_id,
                "source_job_name" : job_name,
                "pipeline_environment" : pipeline_environment,
                "studyId" : studyId ,
                "study_environment" : study_environment,
                "lifecycle" : lifecycle, 
                "listingTitle" : listing_title,
                "listingType" : listing_type,
                "parameters" : json.dumps(parameters),
                "recIdKeys" : json.dumps(recIdKeys),
                "recVersionKeys" : json.dumps(recVersionKeys),
                "taskBatchId" : pgm_job_batch_id,
                "job_id" : job_id,
                "run_id" : run_id,
                "process_timestamp" : load_timestamp,
                "labelFilePath" : column_labels_file_path,
                "devMode" : "False",
                "dataModel" :dataModel
            }

            # Set the pgm_data for the listing task in the for_each loop
            dbutils.jobs.taskValues.set(key = listing_name, value = pgm_data)

            display({"Listing Name": listing_name, "PGM Data": pgm_data})

            # Prepare abridged listing list to pass to the for-each task loop
            listing = {
                "name" : listing_name,
                "commit" : bitbucket_commit,
                "path" : bitbucket_path,
            }

            # Add to the list of abridged listing details
            listing_list.append(listing)

        create_bulk_audit_log_with_run_id(
            job_id=job_id,
            job_batches=job_batches,
            study_id=studyId,
            environment=study_environment,
            load_timestamp=load_timestamp,
            run_id=run_id,
            status="STARTED"
        )

    else:
        pass
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, submit_job_batch_id, "FAILED", error_msg)
    raise e


# COMMAND ----------

try:
    # Set the abridged listings_list for the for_each task loop
    abridged_listings_json_pretty = json.dumps(listing_list, indent=4)
    print(f'Setting list of {listingType} listings to: {abridged_listings_json_pretty}')
    
    # TODO Is it better to set the json object or to set the minified json text?
    abridged_listings_json_minify = json.dumps(listing_list, separators=(",", ":"))
    dbutils.jobs.taskValues.set(key = "listings_list", value = abridged_listings_json_minify)
        
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, submit_job_batch_id, "FAILED", error_msg)
    raise e
