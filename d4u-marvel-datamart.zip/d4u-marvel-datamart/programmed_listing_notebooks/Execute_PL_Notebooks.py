# Databricks notebook source
from pathlib import Path

# COMMAND ----------

import json

# COMMAND ----------

gitCommit = dbutils.widgets.get("commit_id")
gitCommit = dbutils.jobs.taskValues.get(taskKey = "Extract_PL_Notebooks", key = "commit_folder", default = gitCommit)
print(f'Commit folder: {gitCommit}')

notebookpath= dbutils.widgets.get("notebookpath")
pipeline_environment=dbutils.widgets.get("pipeline_environment")
studyId = dbutils.widgets.get("studyId")
dataEnv = dbutils.widgets.get("dataEnv")
load_timestamp = dbutils.widgets.get("process_timestamp")
#databricks_job_url = dbutils.widgets.get("databricks_job_url")
devMode=dbutils.widgets.get("devMode")
lifecycle=dbutils.widgets.get("lifecycle")
listingName=dbutils.widgets.get("listingName")
listingTitle=dbutils.widgets.get("listingTitle")
listingType=dbutils.widgets.get("listingType")
batch_id= dbutils.widgets.get("batchId")
run_id=dbutils.widgets.get("run_id")
job_id=dbutils.widgets.get("job_id")
source_job_name=dbutils.widgets.get("source_job_name")

labelFilePath=dbutils.widgets.get("labelFilePath")
labelFilePath=dbutils.jobs.taskValues.get(taskKey = "Extract_PL_Notebooks", key = "labelFilePath", default = labelFilePath)
print(f'labelFilePath: {labelFilePath}')

parameters=dbutils.widgets.get("parameters")
recIdKeys=dbutils.widgets.get("recIdKeys")
recVersionKeys=dbutils.widgets.get("recVersionKeys")

# Passing all other notebook parameter (ie. override flags) to PL notebook
knowParams = ["commit_id","notebookpath","pipeline_environment","studyId","dataEnv","process_timestamp","devMode","lifecycle","listingName","listingTitle","listingType","batchId","run_id","job_id","source_job_name", "labelFilePath", "parameters", "recIdKeys", "recVersionKeys"]
 
allParams = dbutils.widgets.getAll()

optionalParams = {k:v for k,v in allParams.items() if k not in knowParams}

print(f'Optional parameters found: {json.dumps(optionalParams, indent=4)}')

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

try:
    notebookpath= Path(f"/Shared/ProgListingCache/{gitCommit}/{notebookpath}")
    
    params = {
        "devMode" : devMode,
        "dataEnv" : dataEnv,
        "lifecycle" : lifecycle,
        "listingName" : listingName,
        "listingTitle" : listingTitle,
        "listingType" : listingType,
        "studyId": studyId,
        "parameters" : parameters,
        "recIdKeys" : recIdKeys,
        "recVersionKeys" : recVersionKeys,
        "labelFilePath": labelFilePath,
        "runId": run_id
    }

    params = {**params, **optionalParams}

    print(f'Parameters passed to PL notebook: {json.dumps(params, indent=4)}')
    print()
    
    result = dbutils.notebook.run(str(notebookpath.absolute().with_suffix('')), 0, params)

    if result is not None:
        print(f'Result of PL notebook: {json.dumps(result, indent=4)}')
        parsed_result = json.loads(result)
        if 'error' in parsed_result.keys():
            raise Exception(parsed_result['error'])
        else:
            raise Exception(result)
    else:
        print('No result returned. PL Notebook executed successfully')

except Exception as e:
    print(f'Notebook execution failed: {e}')
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, studyId, dataEnv, "FAILED", error_msg)
    errant_tables = f"d4u_{listingType}_{listingName}"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,dataEnv,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(studyId,dataEnv,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

try:
    # Update audit log
    job_status = "SUCCESS"
    update_audit_log(batch_id, job_id, run_id, studyId, dataEnv, job_status, "Job has been executed successfully")
    msg = f"Success: The programmed listing d4u_{listingType}_{listingName} has been processed successfully for study- {studyId}"
    tblname = f"d4u_{listingType}_"+listingName
    final_stats_df = spark.sql(f"select '{tblname}' as table,'n/a' as drop,'n/a' as insert,'n/a' as updated ,'n/a' as metadata_change")
    domainstats = build_domain_statistics_dictionary(final_stats_df)
    
    # DJM 4/9/24 - JADF-23244 - We were passing in a blank as "source" parameter. The fix is to pass in "PL" literal for JSON creation.
    message = build_clinical_study_json(studyId, "", dataEnv, job_id, run_id, load_timestamp, "PL", msg, domainstats)
    send_notification(studyId, dataEnv, "Success", business_user_recipients, message, vpc_name, "", "", "", "", "")
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, studyId, dataEnv, "FAILED", error_msg)
    errant_tables = f"d4u_{listingType}_{listingName}"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,dataEnv,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(studyId,dataEnv,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
