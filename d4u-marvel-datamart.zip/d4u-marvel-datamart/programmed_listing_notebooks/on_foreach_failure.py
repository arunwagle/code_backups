# Databricks notebook source
from datetime import datetime as dt
from pyspark.sql.functions import col, regexp_replace
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,Reading Pipeline Parameters
pipeline_environment = dbutils.widgets.get("pipeline_environment")
studyId = dbutils.widgets.get("study_id")
study_environment = dbutils.widgets.get("environment")
# submit_job_batch_id= dbutils.widgets.get("batchId")
# run_id=dbutils.widgets.get("run_id")
# job_id=dbutils.widgets.get("job_id")
lifecycle=dbutils.widgets.get("lifecycle")
devMode=dbutils.widgets.get("devMode")
dataModel=dbutils.widgets.get("data_model")
listingType=dbutils.widgets.get("listingType")
source_job_name = dbutils.widgets.get("source_job_name")

if listingType == 'basic':
    submit_job_batch_id = dbutils.jobs.taskValues.get(taskKey="submit_process_basic_listings", key="batchId")
elif listingType == 'filtered':
    submit_job_batch_id = dbutils.jobs.taskValues.get(taskKey="submit_process_filtered_listings", key="batchId")
elif listingType == 'complex':
    submit_job_batch_id = dbutils.jobs.taskValues.get(taskKey="submit_process_complex_listings", key="batchId")
else:
    # NOTE: This should never happen
    raise Exception("listing_type not set to basic, filtered or complex")

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./dre_utils

# COMMAND ----------

try:
    if listingType == "basic" or listingType == "filtered":
        process_min_max(study_environment, studyId, table_pattern, exclude_table_name)
        
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, submit_job_batch_id, "FAILED", error_msg)
    raise e 

# COMMAND ----------


job_status = "FAILED"
error_msg = "Job failed as all child jobs did not succeed."
update_audit_log_with_partitioning(studyId, study_environment, source_job_name, submit_job_batch_id, "FAILED", error_msg)
raise Exception("Job failed as all child jobs did not succeed.")
