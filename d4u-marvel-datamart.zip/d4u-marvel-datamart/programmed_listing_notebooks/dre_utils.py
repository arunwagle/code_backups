# Databricks notebook source
import psycopg2
from pyspark.sql.types import *


print("Notebook loaded")

# COMMAND ----------

def get_marvel_study_listing_config(studyId, env, label, dataSource, listingAssetIds=""):
    connection = None
    try:
        # print('Connection to DB')
        connection = psycopg2.connect(user=dbMarvelUser,
                                      password=dbMarvelPwd,
                                      host=dbMarvelHost,
                                      port=dbMarvelPort,
                                      database=dbMarvelName)
        cursor = connection.cursor()
        # Query to fetch study listing records for a data source of a study

        if len(listingAssetIds) > 0:
            studyListingQuery = f"""
            WITH listingColumns AS (
                SELECT 
                    sl.asset_id,
                    LOWER('{label}') as listing_type, 
                    LOWER(REPLACE(LOWER(sl.config->>'tableName'),'d4u_{label.lower()}_','')) as listing_name, 
                    sl.label as listing_title,
                    sl.config->>'bitbucket_commit' as bitbucket_commit,
                    sl.config->>'bitbucket_path' as bitbucket_path,
                    COALESCE(sl.config->>'parameters','[]')::jsonb AS parameters,
                    rd.elem->>'name' AS column_name,
                    (rd.elem->>'isRecIdKey')::boolean AS isRecIdKey,
                    (rd.elem->>'isRecVersionKey')::boolean AS isRecVersionKey,
                    sl.is_active	
                FROM dre.get_study_listing_table('{studyId}', '{env}','{dataSource}','{label} Listing')sl
                CROSS JOIN LATERAL jsonb_array_elements(COALESCE(sl.config->>'columns','[]')::jsonb) rd(elem)
                WHERE sl.asset_id in ({listingAssetIds})
            )
            SELECT 
                asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters,
                array_remove(array_agg(CASE WHEN isRecIdKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recIdKeys,
                array_remove(array_agg(CASE WHEN isRecVersionKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recVersionKeys,
                is_active 
            FROM listingColumns
            GROUP BY asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters,
                is_active
            ORDER BY asset_id;
            """
            filtered_records = []
            cursor.execute(studyListingQuery)
            # print("Fetching study")
            records = cursor.fetchall()
            cursor.close()
            for record in records:
                if record[-1] == True:
                    filtered_records.append(record[0:-1])
                else:
                    print(f"Skipping inactive listing {record[2]}")
            # print('Total Records: ', len(filtered_records))
            # print(filtered_records)

            schema = StructType([
                StructField('asset_id', StringType()),
                StructField('listing_type', StringType()),
                StructField('listing_name', StringType()),
                StructField('listing_title', StringType()),
                StructField('bitbucket_commit', StringType()),
                StructField('bitbucket_path', StringType()),
                StructField('parameters', 
                    ArrayType(
                        StructType([
                            StructField('name', StringType()),
                            StructField('value', StringType())
                        ])
                    )
                ),
                StructField('recIdKeys', ArrayType(StringType())),
                StructField('recVersionKeys', ArrayType(StringType())),
            ])
        else:
            studyListingQuery = f"""
            WITH listingColumns AS (
                SELECT 
                    sl.asset_id,
                    LOWER('{label}') as listing_type, 
                    LOWER(REPLACE(LOWER(sl.config->>'tableName'),'d4u_{label.lower()}_','')) as listing_name, 
                    sl.label as listing_title,
                    sl.config->>'bitbucket_commit' as bitbucket_commit,
                    sl.config->>'bitbucket_path' as bitbucket_path,
                    COALESCE(sl.config->>'parameters','[]')::jsonb AS parameters,
                    rd.elem->>'name' AS column_name,
                    (rd.elem->>'isRecIdKey')::boolean AS isRecIdKey,
                    (rd.elem->>'isRecVersionKey')::boolean AS isRecVersionKey,
                    sl.is_active	
                FROM dre.get_study_listing_table('{studyId}', '{env}','{dataSource}','{label} Listing')sl
                CROSS JOIN LATERAL jsonb_array_elements(COALESCE(sl.config->>'columns','[]')::jsonb) rd(elem)
            )
            SELECT 
                asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters,
                array_remove(array_agg(CASE WHEN isRecIdKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recIdKeys,
                array_remove(array_agg(CASE WHEN isRecVersionKey IS TRUE THEN column_name ELSE NULL END), NULL) AS recVersionKeys,
                is_active 
            FROM listingColumns
            GROUP BY asset_id,
                listing_type,
                listing_name,
                listing_title,
                bitbucket_commit,
                bitbucket_path,
                parameters,
                is_active
            ORDER BY asset_id;
            """
            filtered_records = []
            cursor.execute(studyListingQuery)
            # print("Fetching study")
            records = cursor.fetchall()
            cursor.close()
            for record in records:
                if record[-1] == True:
                    filtered_records.append(record[0:-1])
                else:
                    print(f"Skipping inactive listing {record[2]}")
            # print('Total Records: ', len(filtered_records))
            # print(filtered_records)

            schema = StructType([
                StructField('asset_id', StringType()),
                StructField('listing_type', StringType()),
                StructField('listing_name', StringType()),
                StructField('listing_title', StringType()),
                StructField('bitbucket_commit', StringType()),
                StructField('bitbucket_path', StringType()),
                StructField('parameters', 
                    ArrayType(
                        StructType([
                            StructField('name', StringType()),
                            StructField('value', StringType())
                        ])
                    )
                ),
                StructField('recIdKeys', ArrayType(StringType())),
                StructField('recVersionKeys', ArrayType(StringType())),
            ])
            
        df = spark.createDataFrame(filtered_records, schema)
        return df.collect()

    except (Exception, psycopg2.Error) as error:
        print("Error while fetching data from PostgreSQL", error)
        return []
    finally:
        # closing database connection.
        if connection:
            cursor.close()
            connection.close()
            # print("PostgreSQL connection is closed")

# COMMAND ----------

def get_basic_listing_config(studyId, env, dataModel, listingAssetIds=""):
    return get_marvel_study_listing_config(studyId, env, 'Basic',dataModel, listingAssetIds)

def get_filtered_listing_config(studyId, env, dataModel, listingAssetIds=""):
    return get_marvel_study_listing_config(studyId, env, 'Filtered',dataModel, listingAssetIds)

def get_complex_listing_config(studyId, env, dataModel, listingAssetIds=""):
    return get_marvel_study_listing_config(studyId, env, 'Complex',dataModel, listingAssetIds)

def get_core_listing_config(studyId, env, dataModel):
    return get_marvel_study_listing_config(studyId, env, 'Core',dataModel)

def get_prog_listing_framework_commit_id(studyId, env, dataModel):
    
    listings_list = get_core_listing_config(studyId, env, 'Other')

    prog_listing_framework_commit = None

    for row in listings_list:
        if row['listing_title'] == 'Programmed Listing Framework':
            print('Found [Programmed Listing Framework listing]:', json.dumps(row))
            for param in row['parameters']:
                if param['name'] == 'commit_id':
                    prog_listing_framework_commit = param['value']

    print('prog_listing_framework_commit found: ', prog_listing_framework_commit)
    return prog_listing_framework_commit

# COMMAND ----------

def api_submit_job(optionalParams={}):
    try:
        load_timestamp = dt.now().isoformat()
        listing_job_batch_id = create_audit_log(listing_job_id, source_job_name, studyId, study_environment, load_timestamp)  

        auth_header = f"Bearer {databricks_api_token}"
        headers = {
            'Authorization': auth_header,
            'Content-Type': 'application/json'
        }

              
        data = {
            "job_id": listing_job_id,
            "notebook_params": {
                "study_id": studyId,
                "environment": study_environment,
                "pipeline_environment": pipeline_environment,
                "batchId": listing_job_batch_id,
                "source_job_name": source_job_name,
                "lifecycle": lifecycle,
                "devMode": devMode,
                "data_model": dataModel,
                "date_time_stamp_string": load_timestamp
            }
        }
        print(f"data: {data}")

        if len(optionalParams.keys()) > 0:
           for k,v in optionalParams.items():
               data["notebook_params"][k] = v
        
        print(f"data with optional params: {data}")
      
        jobs_response = requests.post(databricks_run_job_api, headers=headers, json=data)
        jobs_json = jobs_response.json()
        print(f"API Response: {json.dumps(jobs_json, indent=2)}")

        if jobs_response.status_code == 200:
            current_run_id = jobs_json['run_id']
            print(f"Job submitted for study {studyId} with run_id: {current_run_id}")
            # Update run id into audit log table
            update_audit_log_run_id(listing_job_batch_id, current_run_id, "STARTED")
        else:
            print(f"Submit job run for study {studyId} is not successful")
            update_audit_log_by_batch_id(listing_job_batch_id, "FAILED", f"API call to {source_job_name} job has failed")
    except Exception as e:
        raise e


# COMMAND ----------

from pyspark.sql.functions import col,min,max,lit

exclude_table_name = "d4u_basic_subject_page_filters"
delta_table_name = "d4u_basic_subject_page_filters"
table_pattern = "d4u_basic*|d4u_complex*|d4u_filtered*"
catalog = f"marvel-{study_environment}-gold"
schema = studyId
delta_table_path = f"`{catalog}`.`{schema}`.`{delta_table_name}`"

def process_min_max(study_environment, studyId, table_pattern, exclude_table_name):
    # Check if the delta_table_name exists
    existing_tables = spark.sql(f"SHOW TABLES IN `{catalog}`.`{schema}`").toPandas()
    if delta_table_name not in existing_tables["tableName"].values:
        print(f"{delta_table_name} does not exist. Skipping processing of min max study days.")
        return
    else:
        print(f"{delta_table_name} table already exists.")

    # Get the list of tables that match the specified pattern
    matching_tables = spark.sql(f"SHOW TABLES IN `{catalog}`.`{schema}` LIKE '{table_pattern}'")
    all_table_names = [row["tableName"] for row in matching_tables.collect()]

    # Exclude the specified table from the list
    table_names = [table for table in all_table_names if table != exclude_table_name]

    # Initialize an empty DataFrame 
    result_dfs = spark.createDataFrame([], schema="USUBJID STRING, D4U_START_STUDY_DAY DOUBLE, D4U_END_STUDY_DAY DOUBLE")

    for table_name in table_names:
        try:
            # Check if the table contains the required columns
            columns = spark.sql(f"DESCRIBE TABLE `{catalog}`.`{schema}`.`{table_name}`").collect()
            required_columns = {"D4U_START_STUDY_DAY", "D4U_END_STUDY_DAY", "USUBJID"}
            table_columns = set(col["col_name"].upper() for col in columns)

            if not required_columns.issubset(table_columns):
                print(f"Table {table_name} does not have all required columns. Skipping...")
                continue

            select_statement = (
                f"SELECT USUBJID, MIN(D4U_START_STUDY_DAY) as D4U_START_STUDY_DAY, "
                f"MAX(D4U_END_STUDY_DAY) as D4U_END_STUDY_DAY "
                f"FROM `{catalog}`.`{schema}`.`{table_name}` "
                f"GROUP BY USUBJID"
            )

            aggregated_values_df = spark.sql(select_statement)

            # Union DataFrames with matching schemas
            result_dfs = result_dfs.union(aggregated_values_df)

        except Exception as e:
            print(f"Error processing table {table_name}: {str(e)}")
            # Bubble up error to keep stack trace and error message.
            raise 

    if result_dfs.count() > 0:
        # Calculate the overall min and max values
        overall_values = (
            result_dfs.groupBy("USUBJID")
            .agg(
                min("D4U_START_STUDY_DAY").alias("D4U_START_STUDY_DAY"),
                max("D4U_END_STUDY_DAY").alias("D4U_END_STUDY_DAY")
            )
        )

        overall_values = overall_values.withColumn("study_id", lit(studyId))

        # overall_values.show(truncate=False)

        # Perform upsert using SQL operations
        deltaTable = f"`{catalog}`.`{schema}`.`{delta_table_name}`"
        overall_values.createOrReplaceTempView("updates")
        
        spark.sql(f"""
            MERGE INTO {deltaTable} AS existing
            USING updates
            ON existing.USUBJID = updates.USUBJID
            WHEN MATCHED THEN 
                UPDATE SET
                    D4U_MIN_STUDY_DAY = updates.D4U_START_STUDY_DAY,
                    D4U_MAX_STUDY_DAY = updates.D4U_END_STUDY_DAY
            WHEN NOT MATCHED THEN 
                INSERT (USUBJID, D4U_MIN_STUDY_DAY, D4U_MAX_STUDY_DAY)
                VALUES (updates.USUBJID, updates.D4U_START_STUDY_DAY, updates.D4U_END_STUDY_DAY)
        """)

        print("Upsert into Delta table completed successfully.")
    else:
        print("No valid data found for processing.")


