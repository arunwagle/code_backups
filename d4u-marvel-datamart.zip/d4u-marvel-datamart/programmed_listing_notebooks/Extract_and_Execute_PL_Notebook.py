# Databricks notebook source
# MAGIC %md
# MAGIC ### Imports & Inits

# COMMAND ----------

import requests
import json
import base64
from pathlib import Path, PurePath
import os
from datetime import datetime as dt

# COMMAND ----------

def get_widget_value(widget_name):
    value = None
    try:
        value = dbutils.widgets.get(widget_name)
    except Exception as e:
        try: 
            value = globals().get(widget_name)
        except:
            raise e
    print(f'{widget_name} = {value}')
    return value

# COMMAND ----------

# Pull the widget values first
listingName = get_widget_value("listingName")
gitCommit = get_widget_value("commit_id")
notebookpath = get_widget_value("notebookpath")

# Pull the rest of the details from the task value associated with the listingName
# TODO Consider renaming the submit_process_basic|filtered|complex_listings tasks to a unified submit_process_listings, that way we can get rid of this parameter
task_key = dbutils.widgets.get("listing_source_task")

pgm_data = dbutils.jobs.taskValues.get(taskKey = task_key, key = listingName)
print(f'pgm_data = {pgm_data}')

listing_asset_id = pgm_data.get("listing_asset_id")
source_job_name = pgm_data.get("source_job_name")
pipeline_environment = pgm_data.get("pipeline_environment")
studyId = pgm_data.get("studyId")
study_environment = pgm_data.get("study_environment")
lifecycle = pgm_data.get("lifecycle")
listingTitle = pgm_data.get("listingTitle")

listingType = pgm_data.get("listingType")
parameters = pgm_data.get("parameters")
recIdKeys = pgm_data.get("recIdKeys")
recVersionKeys = pgm_data.get("recVersionKeys")

batch_id = pgm_data.get("taskBatchId")
run_id = pgm_data.get("run_id")
job_id = pgm_data.get("job_id")

load_timestamp = pgm_data.get("process_timestamp")
labelFilePath = pgm_data.get("labelFilePath")
devMode = pgm_data.get('devMode')

dataModel = pgm_data.get("dataModel")

rootfolder = os.path.split(notebookpath)
rootfolder = rootfolder[0] 
gitPath =f"/{rootfolder}"
print(f'gitPath = {gitPath}')

root = "marvel"
delta_lake = "gold"

catalogName = f"{root}-{lifecycle}-{delta_lake}"

# Passing all other notebook parameter (ie. override flags) to PL notebook
knownParams = ["study_id", "environment", "pipeline_environment", "batchId", "source_job_name", "lifecycle", "devMode", "data_model", "date_time_stamp_string", "run_id", "job_id", "listingType", "filtered_prog_listing_jobid", "complex_prog_listing_jobid", "listingAssetIds", "commit_id", "listing_source_task", "notebookpath", "listingName", "repair_count" ]

allParams = dbutils.widgets.getAll()

optionalParams = {k:v for k,v in allParams.items() if k not in knownParams}

print(f'Optional parameters found: {json.dumps(optionalParams, indent=4)}')

tblname = f"d4u_{listingType}_"+listingName

# Apply logic to all optional parameters that are a comma delimited list
# Only process specific optional parameters if they are comma delimited lists
target_optional_params = ["evolveSchema", "allowDropAllRecords", "ignoreMissingKeys", "forceRefreshRecVer"]

for param_key in target_optional_params:
    param_value = optionalParams.get(param_key)
    if isinstance(param_value, str):
        values_list = [v.strip() for v in param_value.split(",")]
        print(f'Parameter "{param_key}" values: {values_list}')
        if tblname in values_list:
            print(f'{tblname} found in {param_key}, setting {param_key} = "true"')
            optionalParams[param_key] = "true"
        else:
            print(f'{tblname} not found in {param_key}, setting {param_key} = "false"')
            optionalParams[param_key] = "false"

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./dre_utils

# COMMAND ----------

# Check if this is a repair run
repair_count = get_widget_value("repair_count")
is_repair_run = bool(repair_count and int(repair_count) > 0)
print(f'is_repair_run = {is_repair_run}')

if is_repair_run:
    # Refresh listing configuration
    records = get_marvel_study_listing_config(studyId, study_environment, listingType, dataModel, f"'{listing_asset_id}'")
    row = records[0] if records else None
    if row is None:
        raise Exception(f"No listing configuration found for asset_id: {listing_asset_id} in study: {studyId}, environment: {study_environment}, listingType: {listingType}, dataModel: {dataModel}")

    print(f'Repair run found, refreshing listing configuration: {row}')
    listing_asset_id = row["asset_id"]
    listingType= row["listing_type"]
    listingName = row["listing_name"]
    listingTitle= row["listing_title"]
    gitCommit = row["bitbucket_commit"]
    notebookpath = row["bitbucket_path"]
    parameters = json.dumps(row["parameters"])
    recIdKeys = json.dumps(row["recIdKeys"])
    recVersionKeys = json.dumps(row["recVersionKeys"])

    # Insert new audit log record
    batch_id = create_audit_log_with_run_id(job_id, source_job_name, studyId, study_environment, dt.now().isoformat(), run_id, "STARTED")
    print(f'Created a new audit_log record with batch_id = {batch_id}')

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./dre_utils

# COMMAND ----------

# MAGIC %run ../utils/git_utils

# COMMAND ----------

# MAGIC %run ../utils/lineage_utils

# COMMAND ----------

# MAGIC %run ../utils/notification_util

# COMMAND ----------

# MAGIC %md
# MAGIC ### PL Execution

# COMMAND ----------

try:
    
    gitOptions = GitOptions({
        'baseurl': git_baseurl,
        'projectKey': git_projectKey,
        'repo': git_repo,
        'token': git_readonly_token,
        'cacheDir' : Path('/Workspace','Shared','ProgListingCache')
    })
    
except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")

    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, batch_id, "FAILED", error_msg)

    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    
    send_notification(studyId,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

def initProgrammedListing(options, path, commit):
    createDirIfNotExist(options.cacheDir, 'Git chache')
    gitFetchProgListing(options, path, commit)

# COMMAND ----------

try:
    dataEnv = study_environment
    initProgrammedListing(gitOptions, gitPath, gitCommit)

except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")

    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, batch_id, "FAILED", error_msg)

    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    
    send_notification(studyId,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

print(f'Commit folder: {commit_folder}')
print(f'labelFilePath: {labelFilePath}')

# COMMAND ----------

try:
    notebookpathStr = Path(f"/Shared/ProgListingCache/{commit_folder}/{notebookpath}")
    
    notebookParams = {
        "devMode" : devMode,
        "dataEnv" : study_environment,
        "lifecycle" : lifecycle,
        "listingName" : listingName,
        "listingTitle" : listingTitle,
        "listingType" : listingType,
        "studyId": studyId,
        "parameters" : parameters,
        "recIdKeys" : recIdKeys,
        "recVersionKeys" : recVersionKeys,
        "labelFilePath":labelFilePath
    }

    notebookParams = {**notebookParams, **optionalParams}

    notebookpathStr = str(notebookpathStr.absolute().with_suffix(''))

    print(f'Running notebook: {notebookpathStr}')
    print(f'With parameters: {json.dumps(notebookParams, indent=4)}')

    result = dbutils.notebook.run(notebookpathStr, 0, notebookParams)

    print(f'Result: {result}')

    if result is not None:
        try:
            result = json.loads(result)
        except:
            pass

        if result is not None and result.get('error') is not None:
            raise Exception(result['error'])

except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")

    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, batch_id, "FAILED", error_msg)

    errant_tables = f"d4u_{listingType}_{listingName}"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    
    send_notification(studyId,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

try:

    # Update audit log
    job_status = "SUCCESS"
    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, batch_id, job_status, "Job has been executed successfully")

    msg = f"Success: The programmed listing d4u_{listingType}_{listingName} has been processed successfully for study- {studyId}"
    final_stats_df = spark.sql(f"select '{tblname}' as table,'n/a' as drop,'n/a' as insert,'n/a' as updated ,'n/a' as metadata_change")

    domainstats = build_domain_statistics_dictionary(final_stats_df)
    
    # DJM 4/9/24 - JADF-23244 - We were passing in a blank as "source" parameter. The fix is to pass in "PL" literal for JSON creation.
    message = build_clinical_study_json(studyId, "", study_environment, job_id, run_id, load_timestamp, "PL", msg, domainstats)
    send_notification(studyId, study_environment, "Success", business_user_recipients, message, vpc_name, "", "", "", "", "")
    #dbutils.jobs.taskValues.set(key   = "listingType", value = listingType)

except Exception as e:

    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")

    update_audit_log_with_partitioning(studyId, study_environment, source_job_name, batch_id, "FAILED", error_msg)

    errant_tables = f"d4u_{listingType}_{listingName}"
    domainstats ={} 
    message = build_clinical_study_json(studyId,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    
    send_notification(studyId,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

try:
   # Skip create_lineage_relationships if listingName is "site_page_filters" or "subject_page_filters"
   if listingName not in ["site_page_filters", "subject_page_filters"]:
      tblname = f"d4u_{listingType}_"+listingName
      create_lineage_relationships_set_based(catalogName, studyId, [tblname], relationship_table_name, dataModel) 

except Exception as e:

   error_msg = str(e)
   error_msg = error_msg.replace("'","").replace("\"","")

   update_audit_log_with_partitioning(studyId, study_environment, source_job_name, batch_id, "FAILED", error_msg)
   raise e
