# Databricks notebook source
from datetime import datetime as dt
from pyspark.sql.functions import col, regexp_replace
from pyspark.sql.types import *
import requests
import json
import base64
from pathlib import Path, PurePath
import os

# COMMAND ----------

def get_widget_value(widget_name):
    value = None
    try:
        value = dbutils.widgets.get(widget_name)
    except Exception as e:
        try: 
            value = globals()[widget_name]
        except:
            raise e
    print(f'{widget_name} = {value}')
    return value


# COMMAND ----------

pipeline_environment = get_widget_value("pipeline_environment")
studyId = get_widget_value("study_id")
study_environment = get_widget_value("environment")
run_id=get_widget_value("run_id")
job_id=get_widget_value("job_id")
lifecycle=get_widget_value("lifecycle")
devMode=get_widget_value("devMode")
dataModel=get_widget_value("data_model")
listingType=dbutils.widgets.get("listingType")
# NOTE: We should revisit how we're relying on source_job_name to be set globally when calling api_submit()... it should be a parameter to that function
old_source_job_name = get_widget_value("source_job_name")


knownParams = ["study_id","environment","pipeline_environment","source_job_name","batchId","run_id","job_id","lifecycle","devMode","data_model","date_time_stamp_string", "listingType", "filtered_prog_listing_jobid", "complex_prog_listing_jobid"]
 
allParams = dbutils.widgets.getAll()

optionalParams = {k:v for k,v in allParams.items() if k not in knownParams}

print(f'Optional parameters found: {json.dumps(optionalParams, indent=4)}')

if listingType == 'basic':
    batch_id = dbutils.jobs.taskValues.get(taskKey="submit_process_basic_listings", key="batchId")
    source_job_name="submit_process_filtered_listings"
    listing_job_id = dbutils.widgets.get("filtered_prog_listing_jobid")
elif listingType == 'filtered':
    batch_id = dbutils.jobs.taskValues.get(taskKey="submit_process_filtered_listings", key="batchId")
    source_job_name="submit_process_complex_listings"
    listing_job_id = dbutils.widgets.get("complex_prog_listing_jobid")
elif listingType == 'complex':
    batch_id = dbutils.jobs.taskValues.get(taskKey="submit_process_complex_listings", key="batchId")
else:
    # NOTE: This should never happen
    raise Exception("listing_type not set to basic, filtered or complex")


# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./dre_utils

# COMMAND ----------

try:
    
    if listingType == "complex":
        process_min_max(study_environment, studyId, table_pattern, exclude_table_name)
    job_status = "SUCCESS"
    update_audit_log_with_partitioning(studyId, study_environment, old_source_job_name, batch_id, job_status, "Job has been executed successfully")
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log_with_partitioning(studyId, study_environment, old_source_job_name, batch_id, "FAILED", error_msg)
    raise e 

# COMMAND ----------

try:
    #optional_param = {}
    #optional_param["listingAssetIds"] = listingAssetIds
    if listingType == "basic" or listingType == "filtered":
        api_call = api_submit_job(optionalParams)  
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log_with_partitioning(studyId, study_environment, old_source_job_name, batch_id, "FAILED", error_msg)
    raise e 
