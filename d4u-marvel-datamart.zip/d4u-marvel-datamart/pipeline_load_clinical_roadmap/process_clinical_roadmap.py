# Databricks notebook source
# MAGIC %run ../init_scripts/init_load_clinical_roadmap

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# %run ../utils/custom_logging

# COMMAND ----------

from datetime import datetime as dt 
import os
import time
from delta.tables import DeltaTable
from pyspark.sql.functions import col, max
from pyspark.sql.types import DateType
from pyspark.sql import functions as F



pipeline_environment = dbutils.widgets.get("pipelineEnvironment")
jobId = dbutils.widgets.get("job_id")
runId = dbutils.widgets.get("run_id")
studyId = "CLINICAL_ROADMAP"
studyEnvironment = "prod"
job_name = "CLINICAL_ROADMAP"
today = dt.now()
load_timestamp = today.strftime("%Y-%m-%d %H:%M:%S")
domainStats ={} 


# COMMAND ----------

# Intialize audit log table based on environment variable
initialize_audit_log_table(catalog_marvel, schema_marvel, audit_log_table)

batch_id =create_audit_log(jobId, job_name, studyId,studyEnvironment, load_timestamp)

update_audit_log_run_id(batch_id, runId, "STARTED")


# COMMAND ----------

# Specify the catalog and schema name
catalog_name = "`marvel-prod-gold`"
schema_name = "clinical_roadmap"

# Check if the schema exists
query = f"SHOW SCHEMAS IN {catalog_name} LIKE '{schema_name}'"
result = spark.sql(query)
schema_exists = result.count() > 0

if schema_exists:
    print("Schema exists")
else:
    # Create schema
    spark.sql(f"CREATE SCHEMA {catalog_name}.{schema_name}")
    print("Schema created")

def read_parquet_and_write_to_delta(parquet_path, schema_name):
    try:
        tic = time.perf_counter()
        # Read all Parquet files in the specified folder
        df = spark.read.option("recursiveFileLookup", "true").parquet(parquet_path)
        df = (
            df.dropDuplicates()
            .withColumn('D4U_RECID', F.md5(F.concat_ws("||", *df.columns)))
            .withColumn('D4U_RECVERDATE', F.current_date())
            .withColumn('D4U_RECVER', F.md5(F.lit('')))
        )
        cmd = df.write.mode("overwrite")\
            .option("overwriteSchema","true")\
            .format("delta")\
            .option('delta.columnMapping.mode', 'name')\
            .option('delta.minReaderVersion', '2')\
            .option('delta.minWriterVersion', '5')

        if('' in df.columns):
            print('Partitioning by PROTOCOLID')
            cmd = cmd.partitionBy('PROTOCOLID')

        print("partioned by PROTOCAL ID")
        
        base_folder_name = os.path.basename(parquet_path)
        # delta_table_name = f"{base_folder_name}"
        prefix = "pnc_odw_"
        delta_table_name = prefix + base_folder_name

        cmd.saveAsTable(f"{catalog_name}.{schema_name}.{delta_table_name}")
        toc = time.perf_counter()

        print(f"Successfully wrote Parquet data to Delta table: {delta_table_name} in {toc - tic:0.4f} seconds")

       
    except Exception as e:
        # print(f"Error: {e}")
        # update_audit_log(batch_id, jobId, runId, studyId, studyEnvironment, "FAILED", {e})
        error_msg = str(e)
        error_msg = error_msg.replace("'","").replace("\"","")
        error_message = f"Error reading Parquet file: {e}"
        print(error_message)
        update_audit_log(batch_id, jobId, runId, studyId, studyEnvironment, "FAILED", error_msg)
        errant_tables = "N/A"
        domainstats={}
        message = build_clinical_study_json(studyId,errant_tables,studyEnvironment,jobId,runId,load_timestamp,"",error_msg,domainstats)
        send_notification(studyId,studyEnvironment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
        raise e
        


parquet_folder = f"{s3_mountpoint}/pnc_odw/dv_IL_Clinical_Roadmap"

read_parquet_and_write_to_delta(parquet_folder, schema_name)




# COMMAND ----------

# DBTITLE 1,Extracting timestamp
goldTable = DeltaTable.forName(spark, f"{catalog_name}.{schema_name}.pnc_odw_dv_IL_Clinical_Roadmap")
max_date_result = spark.sql(f"SELECT MAX(CAST(BASELINEDATE AS DATE)) FROM {catalog_name}.{schema_name}.pnc_odw_dv_IL_Clinical_Roadmap")
load_timestamp_cr = max_date_result.collect()[0][0]
# print(load_timestamp_cr)

load_timestamp_cr_str = str(load_timestamp_cr)


load_timestamp_cr_datetime = dt.strptime(load_timestamp_cr_str, '%Y-%m-%d')

formatted_timestamp_str = load_timestamp_cr_datetime.strftime("%Y-%m-%dT%H:%M:%S")



print(formatted_timestamp_str)



# COMMAND ----------

dbutils.jobs.taskValues.set(key   = "pipeline_environment", value = pipeline_environment)  
dbutils.jobs.taskValues.set(key   = "batch_id", value = batch_id)
dbutils.jobs.taskValues.set(key   = "study_id", value = studyId)
# dbutils.jobs.taskValues.set(key   = "domain_model", value = dataModel)
dbutils.jobs.taskValues.set(key   = "environment", value = studyEnvironment)
dbutils.jobs.taskValues.set(key   = "job_id", value = jobId)
dbutils.jobs.taskValues.set(key   = "run_id", value = runId)
dbutils.jobs.taskValues.set(key   = "load_timestamp", value = load_timestamp)
dbutils.jobs.taskValues.set(key   = "domainStats", value = domainStats)
dbutils.jobs.taskValues.set(key   = "batch_id", value = batch_id)
dbutils.jobs.taskValues.set(key="formatted_timestamp_str", value=formatted_timestamp_str)