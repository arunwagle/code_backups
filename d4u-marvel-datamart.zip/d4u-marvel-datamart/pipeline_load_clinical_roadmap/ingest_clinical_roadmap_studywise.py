# Databricks notebook source
import requests
import json
import base64
from pathlib import Path, PurePath
import os

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_roadmap

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

pipeline_environment= dbutils.jobs.taskValues.get(taskKey = "Process_clinical_roadmap", key = "pipeline_environment", default = "", debugValue = "")
study_id = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "study_id",default = "error", debugValue = "")
studyEnvironment = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "environment",default = "error", debugValue = "")
jobId = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "job_id",default = "", debugValue = "")
runId = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "run_id",default = "error", debugValue = "")
load_timestamp = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "load_timestamp",default = "", debugValue = "")
domainStats = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "domainStats",default = "", debugValue = "")
batch_id = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "batch_id",default = "", debugValue = "")
zipfile_date = dbutils.jobs.taskValues.get(taskKey  = "Process_clinical_roadmap",key = "formatted_timestamp_str",default = "error", debugValue = "")


# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

studyId=study_id
study_environment=studyEnvironment

# COMMAND ----------

# MAGIC %run ../programmed_listing_notebooks/dre_utils

# COMMAND ----------

def extract_values(table_name):
        table_df = spark.table(table_name)
        values = []
        study_vars = ["PROTOCOLID"]

        for study_var in study_vars:
            if study_var in table_df.columns:
                values.extend(
                    [
                        row[study_var].upper()
                        for row in table_df.select(study_var).distinct().collect()
                        if row[study_var].upper() in schema_names
                    ]
                )
                return {"table_name": table_name, "values": values, "study_var": study_var}

        return

   

# COMMAND ----------

def write_data_to_table(catalog_name, schema_name, table_name, study_var, study):
        try:
            cmd = f"""
            SELECT * 
            FROM {catalog_name}.`{schema_name}`.`{table_name}`
            WHERE {study_var} = '{study}'
            """

            df = spark.sql(cmd)

            cmd = (
                df.write.mode("overwrite")
                .format("delta")
                .option("overwriteSchema", "True")
                .option("delta.columnMapping.mode", "name")
                .option("delta.minReaderVersion", "2")
                .option("delta.minWriterVersion", "5")
                .saveAsTable(f"{catalog_name}.`{study}`.`{table_name}`")
            )

            message = f"Data writing completed for {table_name} with study variable {study_var} and study {study}."
            completed_list.append(message)
        
        except Exception as e:
            error_msg = f"Error writing data for {table_name} with study variable {study_var} and study {study}: {str(e)}"
            failure_list.append(error_msg)
            update_audit_log(batch_id, jobId, runId, study_id, studyEnvironment, "FAILED", error_msg)
            error_msg = error_msg.replace("'","").replace("\"","")
            errant_tables = "N/A"
            domainstats={}
            msg = build_clinical_study_json(study_id,errant_tables,studyEnvironment,jobId,runId,load_timestamp,"",error_msg,domainstats)
            send_notification(study_id,studyEnvironment,"Failed",admin_user_recipients,msg,vpc_name,"NA","","","","") 
            raise e

# COMMAND ----------


from concurrent.futures import ThreadPoolExecutor
value_list = []
try:
    catalog_name = "`marvel-prod-gold`"
    schema_name = "clinical_roadmap"

    schema_query = f"SHOW DATABASES IN {catalog_name}"
    schema_names = [row.databaseName.upper() for row in spark.sql(schema_query).collect()]
    schema_name_upper = schema_name.upper()
    spark.sql(f"USE {catalog_name}.`{schema_name_upper}`")

    table_query = f"SHOW TABLES IN {schema_name_upper}"
    tables = spark.sql(table_query)

    
    table_names = [row.tableName for row in tables.collect()]

    with ThreadPoolExecutor(max_workers=len(table_names)) as executor:
        value_lists = list(executor.map(extract_values, table_names))

    value_lists = [val for val in value_lists if val is not None]

    completed_list = []
    failure_list = []

    with ThreadPoolExecutor(max_workers=len(value_lists)) as executor:
        futures = [
            executor.submit(
                write_data_to_table,
                catalog_name,
                schema_name,
                value["table_name"],
                value["study_var"],
                study,
            )
            for value in value_lists
            for study in value["values"]
        ]

    
    
    print("Completed Messages: ", completed_list)
    print("Failure Messages: ", failure_list)
    print("Data writing completed.")

    

except Exception as e:
    print("An error occurred: ", str(e))
    update_audit_log(batch_id, jobId, runId, study_id, studyEnvironment, "FAILED", "Error writing data study wise")


successMsg = (f"Pipeline has been processed successfully and ingested study wise")
failure_string = '|'.join(failure_list)
errantTables = failure_string




# Extract 'values' from each dictionary in the list
all_values = [item['values'] for item in value_lists]

# Flatten the list of lists into a single list
study_values = [value for sublist in all_values for value in sublist]

table_name= 'pnc_odw_dv_il_clinical_roadmap'

value_result = get_clin_roadmap_tables_for_values(catalog_name,value_lists)
unique_schemas = set(entry['schema'] for entry in value_result)
unique_schemas_list = list(unique_schemas)








# COMMAND ----------

# DBTITLE 1,Metrics and audit log

spark.sql("set spark.sql.ansi.enabled = false")
initial_df = spark.sql("select '' as table,'' as drop,'' as insert,'' as updated ,'' as metadata_change")

# Loop through each study value and each table
for x in study_values:
    for table_name in table_names:
        try:
            new_inserted_records = spark.sql(f"select * from {catalog_name}.`{x}`.`{table_name}`").count()
            updated_records = 0
            dropped_records = 0

            meta_changes = "n/a"
            added_columns = "n/a"

            df2 = spark.sql(f"select '{x}.{table_name}' as table, {dropped_records} as drop, {new_inserted_records} as insert, {updated_records} as updated, 'meta_change:{meta_changes},added_columns:{added_columns}' as metadata_change")

            # Select only the necessary columns in df2 with the same order
            df2 = df2.select("table", "drop", "insert", "updated", "metadata_change")

            # Make sure both DataFrames have the same column order
            initial_df = initial_df.select("table", "drop", "insert", "updated", "metadata_change")

            initial_df = initial_df.union(df2)


        except Exception as e:
            print(f"Skipping table {table_name} due to error: {str(e)}")
        


# Send a single notification with all information
final_stats_df = initial_df
domainStats = build_domain_statistics_dictionary(final_stats_df)

successMsg = "Success"
failure_string = '|'.join(failure_list)
errantTables = failure_string

message = build_clinical_study_json(
    study_id="clinical_roadmap",
    errant_tables=errantTables,
    study_environment=studyEnvironment,
    job_id=jobId,
    run_id=runId,
    time=zipfile_date,
    source=data_source,
    msg=successMsg,
    domainstats=domainStats
)

# Send the single notification
send_notification(
    "Clinical_roadmap",
    studyEnvironment,
    "Success",
    admin_user_recipients,
    message,
    vpc_name,
    "NA",
    "",
    "",
    "",
    load_timestamp
)






# COMMAND ----------

import psycopg2

def update_refresh_timestamp(study_id, refresh_timestamp):
    # Define the PostgreSQL connection string
    connection_string = f"postgresql://{dbMarvelUser}:{dbMarvelPwd}@{dbMarvelHost}:{dbMarvelPort}/{dbMarvelName}"

    # Establish a connection to the PostgreSQL database
    conn = psycopg2.connect(connection_string)

    cursor = conn.cursor()
    source = 'CLIN ROADMAP'
    lifecycle = 'PROD'

    # Execute the SQL query
    update_query = f"""
        SELECT * FROM dre.update_study_lifecycle_source_refresh_time('{study_id}', '{lifecycle}', '{source}', '{refresh_timestamp}')
    """

    print(f"Executing query for study_id: {study_id}")
    print(f"Query: {update_query}")

    cursor.execute(update_query)

    # Commit the transaction
    conn.commit()
    
    # Close the cursor and connection
    cursor.close()
    conn.close()

common_refresh_timestamp = zipfile_date

# Iterate over the list and update the refresh timestamp
for study_id in unique_schemas_list:
    update_refresh_timestamp(study_id, common_refresh_timestamp)


# COMMAND ----------

for studyId in unique_schemas_list:
    try:
        records=get_basic_listing_config(studyId, study_environment, "Clinical Roadmap")
        if len(records) > 0:
            source_job_name = "submit_process_basic_listings"
            listing_job_id = dbutils.widgets.get("basic_prog_listing_jobid")
            lifecycle=study_environment
            devMode="True"
            dataModel="Clinical Roadmap"
            api_call = api_submit_job()  
        else:
            print(f"No basic listing found for study : {studyId}")
    except Exception as e:
        raise e

# COMMAND ----------

job_status = "SUCCESS"
message = "Pipeline Job %s has been executed successfully" % (job_name)
# Update audit log
update_audit_log(batch_id, jobId, runId, "CLINICAL_ROADMAP", studyEnvironment, job_status, "Job has been executed successfully")