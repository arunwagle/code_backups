# Databricks notebook source
# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./pipeline_task_variables

# COMMAND ----------


from pyspark.sql.functions import concat,lit,col,collect_list,concat_ws,md5,collect_set,explode,to_json,create_map,array,min,collect_list,cast,date_format,max,current_timestamp

from pyspark.sql.types import StringType,BooleanType,DateType,StructField,StructType,DoubleType,TimestampType
import pandas as pd
from multiprocessing.pool import ThreadPool
from itertools import repeat
from delta.tables import *
import datetime
from datetime import datetime as dt
from pyspark.sql.functions import desc


# COMMAND ----------

def is_schema_exist(catalog_name, schema_name):
    df_schemas = spark.sql("SHOW SCHEMAS IN `%s`" % (catalog_name))
    select_expr = "any(databaseName == '%s')" % (schema_name)
    return (df_schemas.selectExpr(select_expr).collect()[0][0])

# COMMAND ----------

def tableExists(catalog_name,study_schema_name,table_name):
        return spark.sql(f'show tables in `{catalog_name}`.`{study_schema_name}`').selectExpr(f"any(tableName =='{table_name}')").collect()[0][0]

# COMMAND ----------

def createTableIfNotExist(catalog_name,study_schema_name,  tableName,  schema):
    
    if tableExists(catalog_name,study_schema_name,tableName):
        print(f'Table {tableName} already exist.')
    else:
        if 'gold' in catalog_name:
            schema = list(filter(lambda x : x.name not in ["D4U_ISACTIVE","D4U_ISDROP"], schema))
        tableschema=StructType(schema)
        emptyDF = spark.createDataFrame([], tableschema)
        emptyDF \
            .write \
            .mode("overwrite") \
            .format("delta") \
            .saveAsTable(f"`{catalog_name}`.`{study_schema_name}`.`{tableName}`")

        #spark.sql(f"""COMMENT ON TABLE {str(tableName)} IS '{tableTitle}'""")
        
        print(f'Created new table {tableName}')

    return f"`{catalog_name}`.`{study_schema_name}`.{tableName}"

# COMMAND ----------

def restore(table_name,audit_df,catalog_name,study_schema_name,process_timestamp):
    if (is_table_exist(catalog_name, study_schema_name, table_name)):
        df= spark.sql(f"DESCRIBE HISTORY `{catalog_name}`.`{study_schema_name}`.`{table_name}`")
        df=df.orderBy(desc("timestamp")).select("version","timestamp").limit(1)
        timestamp=df.collect()[0][1]
        version=df.collect()[0][0]
        df1=spark.sql(f"select to_timestamp('{process_timestamp}') as tm")
        load_timestamp =df1.collect()[0][0]
        drop_query=f"DROP TABLE IF EXISTS `{catalog_name}`.`{study_schema_name}`.`{table_name}`"
        restore_query=f"RESTORE TABLE `{catalog_name}`.`{study_schema_name}`.{table_name} TIMESTAMP AS OF '{load_timestamp}'"
        if(audit_df.count()> 0):
            if (timestamp > load_timestamp and version <=1):
              spark.sql(drop_query)
            elif(timestamp > load_timestamp and version > 1):
              spark.sql(restore_query)   
            else:
              pass
    
        else:
          spark.sql(drop_query)


# COMMAND ----------

def handle_error(e,error_process,error_table,domains):
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    query=f"select * from `{catalog_marvel}`.`{schema_marvel}`.`{audit_log_table}`  where study_id='{study_id}' and environment='{study_environment}' and job_name='{job_name}' and job_status='SUCCESS'"
    audit_df = spark.sql(query)
    thread_count=3
    parallel_runs = ThreadPool(thread_count)
    parallel_runs.starmap(restore,zip(domains, repeat(audit_df), repeat(catalog_silver), repeat(study_id),repeat(load_timestamp)))
    parallel_runs.starmap(restore,zip(domains, repeat(audit_df), repeat(catalog_gold), repeat(study_id),repeat(load_timestamp)))
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)           
    errant_tables = str(error_table)
    domainstats ={} 
    message = build_clinical_study_json(study_id, errant_tables, study_environment, job_id, run_id, load_timestamp,"", error_msg, domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
    #dbutils.notebook.exit(error_msg)        
