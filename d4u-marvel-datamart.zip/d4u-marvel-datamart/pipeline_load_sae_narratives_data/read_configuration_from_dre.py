# Databricks notebook source
pipeline_environment = dbutils.widgets.get("pipelineEnvironment")
batch_id = dbutils.widgets.get("batchId")
study_id = dbutils.widgets.get("studyId")
dataModel= dbutils.widgets.get("data_model")
environment = dbutils.widgets.get("environment")
load_timestamp = dbutils.widgets.get("loadTimestamp")
job_id = dbutils.widgets.get("job_id")
run_id = dbutils.widgets.get("run_id")
studyId=study_id.lower()
temp_study_id=study_id.replace("-","_")

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_sae_narratives

# COMMAND ----------

# MAGIC %run  ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

# DBTITLE 1,Check schema existence 
try:
    catalog_silver = f"marvel-{environment}-silver"
    catalog_gold = f"marvel-{environment}-gold"      
    # Checking  Silver schema exists or not
    if not (is_schema_exist(catalog_silver, study_id.lower())):
        raise Exception(f"ERROR: Study schema {study_id} does not exists in {catalog_silver}. Job could not proceed")
    else:
        print("%s exists in %s" % (study_id, catalog_silver))
        #logger.info(f"{study_id} exists in {catalog_silver}")
    # Checking  gold schema exists or not
    if not (is_schema_exist(catalog_gold, study_id.lower())):
        raise Exception(f"ERROR: Study schema {study_id} does not exist in {catalog_gold}. Job could not proceed")
    else:
        print("%s exists in %s" % (study_id, catalog_gold))
        #logger.info(f"{study_id} exists in {catalog_gold}")
except Exception as e:
    # logger.error("ERROR: Study schema  does not exist. Job could not proceed")
    # logger.error(e)
    #log_file_data=read_log_file(p_filename)
    #write_log_file(log_file_data,"","","","","","","","",log_filename)
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","") 
    raise e
    #dbutils.notebook.exit(error_msg)


# COMMAND ----------

try:
    listing_records = get_marvel_study_listing_config(dataModel, studyId, environment)
    if len(listing_records) > 0:
        print('Study associated listing configuration present.')
    else:
        print('Study associated listing configuration is not present. Get listing configuration from template catalog')
        listing_records = get_marvel_study_listing_config(dataModel)

    # print(len(listing_records))
    if len(listing_records) > 0:
        print(f"Listing configuration count: {len(listing_records)}")
        config_dict={}
        for row in listing_records:
            config=row[3]
            tableName=row[1]
            columns_list=config['columns']
            recid_list=[]
            recver_list=[]
            
            is_active = row[4]
            if is_active == False:
                print(f"Skipping an inactive listing, {row[1]}")
                continue

            for key in columns_list:
                if key['isRecIdKey']==True:
                    recid_list.append(key['name'])
                if key['isRecVersionKey']==True:
                    recver_list.append(key['name'])
            combined_dict = dict(RecIdKeys= recid_list, RecverKey = recver_list)
            config_dict[tableName] = combined_dict
        print(config_dict)
    else:
        raise Exception(f"ERROR: {dataModel} Configuration for Study - {studyId} does not exist in DRE Marvel. Job could not proceed")

except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e

# COMMAND ----------

try:
  dbutils.jobs.taskValues.set(key   = "config_dict",value = config_dict)
  dbutils.jobs.taskValues.set(key   = "pipeline_environment", value = pipeline_environment)  
  dbutils.jobs.taskValues.set(key   = "batch_id", value = batch_id)
  dbutils.jobs.taskValues.set(key   = "study_id", value = study_id)
  dbutils.jobs.taskValues.set(key   = "domain_model", value = dataModel)
  dbutils.jobs.taskValues.set(key   = "environment", value = environment)
  dbutils.jobs.taskValues.set(key   = "job_id", value = job_id)
  dbutils.jobs.taskValues.set(key   = "run_id", value = run_id)
  dbutils.jobs.taskValues.set(key   = "load_timestamp", value = load_timestamp)
  dbutils.jobs.taskValues.set(key   = "temp_study_id", value = temp_study_id)
except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    errant_tables = "N/A"
    #errant_tables = "Error while parsing file name and setting job task values"
    #logger.error(errant_tables)
    #logger.error(e)
    #log_file_data=read_log_file(p_filename)
    #write_log_file(log_file_data,"","","","","","","","",log_filename)
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    domainstats ={}
    study_environment = environment
    if study_environment not in ('prod','uat'):
        study_environment = "Invalid Study Environment"
    message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,load_timestamp,"",error_msg,domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
    dbutils.notebook.exit(error_msg)
