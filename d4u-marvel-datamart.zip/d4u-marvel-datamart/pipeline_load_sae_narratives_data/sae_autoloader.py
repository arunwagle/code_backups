# Databricks notebook source
# DBTITLE 1,Get Pipeline Environment
pipeline_environment = dbutils.widgets.get("pipeline_environment").lower()

# COMMAND ----------

# DBTITLE 1,Initialization
# MAGIC %run ../init_scripts/init_load_sae_narratives

# COMMAND ----------

# DBTITLE 1,Configuration
# access_key = dbutils.secrets.get(scope = "marvel", key = "marvel_landing_zone_access_key")
# secret_key = dbutils.secrets.get(scope = "marvel", key = "marvel_landing_zone_secret_key")

sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", s3_access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", s3_secret_key)

# If you are using Auto Loader file notification mode to load files, provide the AWS Region ID.

sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

# COMMAND ----------

# DBTITLE 1,Define autoloader to monitor S3 bucket
from pyspark.sql.functions import lit, col, regexp_extract
from pyspark.sql.types import StringType, TimestampType, IntegerType,LongType

print(f's3_bucket_name: {s3_bucket_name}')
print(f'sae_s3_folder: {sae_s3_folder}')
print(f'sae_checkpoint_path: {sae_checkpoint_path}')
print(f'sae_checkpoint_table: {sae_checkpoint_table}')


df = spark.readStream.format('cloudFiles') \
    .option('cloudFiles.format', 'binaryFile') \
    .option('cloudFiles.includeExistingFiles', 'true') \
    .option('cloudFiles.useNotifications', 'true') \
    .option('cloudFiles.region', aws_region) \
    .option('cloudFiles.awsAccessKey', s3_access_key) \
    .option('cloudFiles.awsSecretKey', s3_secret_key) \
    .option('cloudFiles.partitionColumns', '') \
    .option('cloudFiles.maxBytesPerTrigger', str(1024 * 1024 * 1024)) \
    .option('pathGlobFilter', '*.{parquet,parquet.gzip}') \
    .load(f'{sae_s3_folder}')

df_custom = df.drop("content") \
    .withColumn("study_id", regexp_extract('path', '.*/study_id=([^/]*)/.*', 1).cast(StringType())) \
    .withColumn("domain_model", lit(data_model).cast(StringType())) \
    .withColumn("environment", lit(environment_prod).cast(StringType())) \
    .withColumn("is_processed", lit("0")) \
    .withColumn("job_id", lit(None).cast(StringType())) \
    .withColumn("run_id", lit(None).cast(LongType())) \
    .withColumn("process_start_timestamp", lit(None).cast(TimestampType())) \
    .withColumn("process_end_timestamp", lit(None).cast(TimestampType())) \
    .withColumnRenamed("modificationTime", "file_arrival_timestamp")

df_custom.writeStream \
    .option('checkpointLocation', sae_checkpoint_path) \
    .table(sae_checkpoint_table)
