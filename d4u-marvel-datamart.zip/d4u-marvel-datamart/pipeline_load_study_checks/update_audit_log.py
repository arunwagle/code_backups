# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_study_checks

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

import requests
import json
import base64
from pathlib import Path, PurePath
import os

# COMMAND ----------

studyId=study_id

# COMMAND ----------

# MAGIC %run ../programmed_listing_notebooks/dre_utils

# COMMAND ----------


import datetime
from datetime import datetime as dt


# COMMAND ----------

zipfile_date = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "date_time_stamp_string",default = "error", debugValue = "")
# domains = dbutils.jobs.taskValues.get(taskKey  = "study_zip_extract",key = "available_domains",default = "error", debugValue = "")

domains = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes",key = "available_domains",default = "error", debugValue = "")


# COMMAND ----------

job_status = "SUCCESS"
message = "Pipeline Job %s has been executed successfully" % (job_name)
# Update audit log
update_audit_log(batch_id, job_id, run_id, study_id, study_environment, job_status, "Job has been executed successfully")
#logger.info("Updating process end timstamp in audit log table ")

# COMMAND ----------

load_timestamp_cr_str = str(zipfile_date)
 
 
load_timestamp_cr_datetime = dt.strptime(zipfile_date, '%Y%m%dT%H%M%S')
 
source_date_refresh = load_timestamp_cr_datetime.strftime("%Y-%m-%dT%H:%M:%S")
print(source_date_refresh)


# COMMAND ----------

spark.sql("set spark.sql.ansi.enabled = false")
initial_df = spark.sql("select '' as table,'' as drop,'' as insert,'' as updated ,''as metadata_change")
for x in domains:

    if(x == "fbt_checks"):
        print(x)
        checks_history_df = spark.sql(f"describe history `{catalog_gold}`.`{study_schema_name}`.{x}")
        
        
        latest_checks_history_df = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='MERGE'))

                                                    
        column_changes_count = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='CHANGE COLUMN')).count()
        add_columns_count = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='ADD COLUMNS')).count()
        
        if(column_changes_count >0):
            meta_changes =  checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='CHANGE COLUMN')).select(collect_list('operationParameters')).collect()[0][0] 
        else:
            meta_changes = "n/a"  

        if(add_columns_count > 0):
            added_columns = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='ADD COLUMNS')).select(collect_list('operationParameters')).collect()[0][0] 
        else:
            added_columns = "n/a"

        print(f"Count_of_latest_checks_history_df{latest_checks_history_df.count()}")
        if(latest_checks_history_df.count() == 3):
           
           min_version = int(latest_checks_history_df.select(min('version')).collect()[0][0])
           # DJM 3/15/24 Remove debug code - print(min_version)          
        
           updated_records =int(latest_checks_history_df.filter(col('version')==int(min_version)).select('operationMetrics.numTargetRowsMatchedDeleted').collect()[0][0])

           dropped_records = int(latest_checks_history_df.filter(col('version')==int(min_version)+1).select('operationMetrics.numTargetRowsMatchedDeleted').collect()[0][0])

           all_inserts = int(latest_checks_history_df.filter(col('version')==int(min_version)+2).select('operationMetrics.numTargetRowsInserted').collect()[0][0])


           new_inserted_records = all_inserts - updated_records

        elif(latest_checks_history_df.count() ==1):


            new_inserted_records  = int(latest_checks_history_df.select('operationMetrics.numOutputRows').collect()[0][0])

        meta_changes = str(meta_changes).replace('\'','')
        added_columns = str(added_columns).replace('\'','')

        df1 = spark.sql(f"select '{x}' as table,{dropped_records} as drop,{new_inserted_records} as insert,{updated_records} as updated ,'meta_change:{meta_changes},added_columns:{added_columns}'as metadata_change")
        
        # display(df1)
        initial_df = initial_df.union(df1) 

    else:
        print(x)

        new_inserted_records =  spark.sql(f"select * from `{catalog_gold}`.`{study_schema_name}`.{x}").count()

        updated_records = 0
        dropped_records = 0
                
        meta_changes= "n/a"
        added_columns = "n/a"

        df2 = spark.sql(f"select '{x}' as table,{dropped_records} as drop,{new_inserted_records} as insert,{updated_records} as updated ,'meta_change:{meta_changes},added_columns:{added_columns}'as metadata_change")
        # display(df2)

        initial_df = initial_df.union(df2)
        
         



# COMMAND ----------

final_stats_df = initial_df

# COMMAND ----------

# TODO This logic should be in the marvel-study-data-refresh lambda so that the workflows do not have to produce both the Domain updates as well as the updated_tables array
def get_updated_tables(response):
    # Parse the JSON response
    parsed_response = json.loads(response)

    # Extract the Domains array
    domains = parsed_response["Domains"]

    # Initialize a list to store updated tables
    updated_tables = []

    # Iterate through the domains and check for updates, inserts, or drops
    for domain in domains:
        no_of_updates = int(domain.get("no_of_updates", 0) or 0)
        no_of_inserts = int(domain.get("no_of_inserts", 0) or 0)
        no_of_drops = int(domain.get("no_of_drops", 0) or 0)

        # If any of the values are greater than 0, add the table_name to updated_tables
        if no_of_updates > 0 or no_of_inserts > 0 or no_of_drops > 0:
            updated_tables.append(domain["table_name"])

    return updated_tables

# COMMAND ----------

try:
    records=get_basic_listing_config(study_id, study_environment, data_model)
    if len(records) > 0:
        source_job_name = "submit_process_basic_listings"
        listing_job_id = dbutils.widgets.get("basic_prog_listing_jobid")
        lifecycle=study_environment
        devMode="True"
        dataModel=data_model
        api_call = api_submit_job()  
    else:
        print(f"No basic listing found for study : {study_id}")
except Exception as e:
    raise e

# COMMAND ----------

errant_tables = "N/A"
s3_file_location = ""
bucket_name = f"{s3_bucket_name}"
metrics_file_name = ""
msg = "Success: The load file for Study Id - {0} has been processed successfully".format(study_id)

domainstats = build_domain_statistics_dictionary(final_stats_df)

message = build_clinical_study_json(study_id, errant_tables, study_environment, job_id, run_id, source_date_refresh, data_source, msg, domainstats)
print(f'message: {message}')

# Prepare the updated_tables
updated_tables = get_updated_tables(message)
print(f'updated_tables: {updated_tables}')

send_notification(study_id, study_environment, "Success", business_user_recipients, message, vpc_name, s3_file_location, bucket_name, metrics_file_name, updated_tables, load_timestamp)

# COMMAND ----------

checkpoint_update_query = f"UPDATE `{checkpoint_table}` SET process_end_timestamp = CURRENT_TIMESTAMP() WHERE run_id = {run_id} AND study_id = '{study_id}' AND environment='{study_environment}'"
execute_sql_with_retry(checkpoint_update_query)
#logger.info("Updating checkpoint  table")

# COMMAND ----------

# errant_tables = "N/A"
# msg = "Success: The checks file for Study Id - {0} has been processed successfully".format(study_id)
# #domainstats = build_domain_statistics_dictionary(final_stats_df)
# domainstats={}
# message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,source_date_refresh,data_source,msg,domainstats)
# send_notification(study_id,study_environment,"Success",business_user_recipients,message,vpc_name,"","","","","")
# # logger.info(f"Domains that were successfully processed are :  {domains}")
# # logger.info(msg)

# COMMAND ----------

# try:
#     log_file_data=read_log_file(p_filename)
#     write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,metadata_log_file,
#                         ingest_silver_log_file,nonclinicdom_log_file,overwrite_gold_log_file,
#                    cleanupres_log_file,log_file_data,log_file)
# except Exception as e:
#     raise e
