# Databricks notebook source
pipeline_environment = dbutils.widgets.get("pipelineEnvironment").lower()
databricks_instance = dbutils.widgets.get("databricksInstance")
checks_data_job_id = dbutils.widgets.get("processStudyJobId")

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_study_checks

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/jobs_util

# COMMAND ----------

import re
import os
import json
import requests
import datetime
from datetime import datetime as dt
import logging
logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.warning("This is a warning message")
logger.error("This is an error message")
logger.debug("About to do something")
logger.info("This is an informational message")

# COMMAND ----------

# DBTITLE 1,Build & Call Process Clinical Study Job API
# DBTITLE 1,Build & Call Process Clinical Study Job API
databricks_run_job_api = f"{databricks_instance}{databricks_job_uri}"
databricks_runs_list_api = f"{databricks_instance}{databricks_runs_uri}"

# Intialize audit log table based on environment variable
initialize_audit_log_table(catalog_marvel, schema_marvel, audit_log_table)

# print(f"Checkpoint Table: {checkpoint_table}")
# DJM - 11/27/23 - This is a temp solution for FIFO processing of a single record until the
#                  proper solution is implemented to use the date/time stamp from the filename.
checkpoint_query = f"SELECT path, file_arrival_timestamp, is_processed FROM `{checkpoint_table}` WHERE is_processed = 0 AND path LIKE '%.zip' ORDER BY file_arrival_timestamp ASC "
df_checkpoint_data = spark.sql(checkpoint_query)

file_path_trim_part = "s3a://%s" % (s3_bucket_name)
batch_id = None

if (df_checkpoint_data.count() > 0):
    checkpoint_collect = df_checkpoint_data.collect()

    for row in checkpoint_collect:
        s3_file_path = row["path"]
        file_mount_path = s3_file_path.replace(file_path_trim_part, s3_mountpoint)        
        # Get only file name from the path
        file_name = get_file_name(file_mount_path)
        # Get only the folder path from the path
        folder_path = get_folder_path(file_mount_path)

        print(f"file_name: {file_name}")
        print(f"folder_path: {folder_path}") 

        study_id = None
        domain_model = None
        environment = None

        data_model = "FBT"

        # Study File Name format validation & API call
        try:
            load_timestamp = dt.now().isoformat()

            file_name_pattern = re.compile("(?P<study_id>[A-Za-z0-9-\_]+)\_(?P<domain_model>checks){1}\_(?P<date_time_stamp>.+){1}\_(?P<environment>uat|prod){1}\.zip", re.IGNORECASE)
            file_match = file_name_pattern.match(file_name)
            is_valid_fileName = False

            # File name validity check 1 of 2 (RegEx test)
            if file_match:
                file_match_dict = file_match.groupdict()

                # Parse out values from regex dictionary using subscript.

                # Force lower case for study_id, domain_model & environment
                # NOTE: study_id needs to be lower case for API call.
                study_id = file_match_dict['study_id'].lower()
                domain_model = file_match_dict['domain_model'].lower()
                environment = file_match_dict['environment'].lower()

                date_time_stamp_string = file_match_dict['date_time_stamp']

                is_valid_date = isValidDate(date_time_stamp_string)

                #Checking if study run already exist
                run_exist = study_lifecycle_run_exist(study_id = study_id, job_id =checks_data_job_id,environment = environment)

                if run_exist is True:
                    logger.info(f'Skipping files for study {study_id} as there is already another job running.')
                    continue
                


                # File name validity check 2 of 2 (After parsing tokens & checking date/time stamp token)
                if is_valid_date:
                    is_valid_fileName = True
                    print(f"Study file has a valid naming convention: {file_name}")

                    print(f"study_id: {study_id}")
                    print(f"domain_model: {domain_model}")
                    print(f"environment: {environment}")
                    print(f"date_time_stamp_string: {date_time_stamp_string}")
                

                    # study_id needs to be lower case for API call.
                    study_id = study_id.lower()
                    print(f"study_id (to lower): {study_id}")

                    batch_id = create_audit_log(checks_data_job_id, job_name, study_id, environment, load_timestamp)
                    print(f"batch_id: {batch_id}")

                    auth_header = f"Bearer {databricks_api_token}"

                    headers = {
                            'Authorization': auth_header,
                            'Content-Type': 'application/json'
                            }

                    data = {
                        "job_id": checks_data_job_id,
                        "notebook_params": { 
                            "studyFilePath" : s3_file_path, 
                            "pipelineEnvironment" : pipeline_environment, 
                            "batchId": batch_id, 
                            "studyId": study_id, 
                            "data_model": data_model, 
                            "environment": environment, 
                            "loadTimestamp": load_timestamp,
                            "date_time_stamp_string":date_time_stamp_string 
                        }
                    }

                    jobs_response = requests.post(databricks_run_job_api, headers=headers, json=data)

                    print(f"File: {s3_file_path}")
                    print(f"API Response: {json.dumps(jobs_response.json(), indent=2)}")

                    if(jobs_response.status_code == 200):
                        current_run_id = jobs_response.json()['run_id']
                        print(f"Job has been triggered successfully")
                        print(f"Job submitted for study file {s3_file_path} with run_id: {current_run_id}")

                        # Update run id into audit log table
                        update_audit_log_run_id(batch_id, current_run_id, "STARTED")

                        # Update study process flag in checkpoint table
                        checkpoint_update_query = f"""
                            UPDATE `{checkpoint_table}` SET 
                                study_id = '{study_id}', 
                                domain_model = '{data_model}', 
                                environment = '{environment}', 
                                is_processed = 1, 
                                job_id = '{checks_data_job_id}', 
                                run_id = {current_run_id}, 
                                process_start_timestamp = '{load_timestamp}' 
                            WHERE path = '{s3_file_path}'"""

                        execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")

                        print(f"Checkpoint table updated for run_id: {current_run_id}")
                    else:
                        print(f"Submit job run for study {study_id} is not successful")
                        update_audit_log_by_batch_id(batch_id, "FAILED", "API call to submit job has failed")
                else:
                    print(f"The file name has an invalid date/time stamp token: {date_time_stamp_string}")

            if not is_valid_fileName:
                # NOTE: In this scenario, we will not have the study_id or environment values.
                batch_id = create_audit_log(checks_data_job_id, job_name, study_id, environment, load_timestamp)
                
                print(f'batch_id: {batch_id}')

                checkpoint_update_query = f"""
                    UPDATE `{checkpoint_table}` SET 
                        is_processed = 1, 
                        job_id = '{checks_data_job_id}' 
                    WHERE path = '{s3_file_path}'
                """
                
                execute_sql_with_retry(sql=checkpoint_update_query, log_try="Updating Checkpoint table")
                print(f"Checkpoint table: {checkpoint_table} has been updated for path: {s3_file_path}")

                invalid_filename_msg = f"ERROR - Study file {file_name} naming convention is incorrect. Study could not be processed. Expected naming convention: [studyid]_checks_[yyyymmddThhmmss]_[uat|prod].zip"


                raise Exception(invalid_filename_msg)
        except Exception as e:
            error_msg = str(e)
            error_msg = error_msg.replace("'","").replace("\"","")
            print(error_msg)

            if batch_id:
                print(f"batch_id: {batch_id}")
                update_audit_log_by_batch_id(batch_id, "FAILED", error_msg)
            else:
                print("Unable to write to the audit_log table. batch_id has no value.")

            errant_tables = "N/A"
            load_timestamp = dt.now().isoformat()
            study_environment = file_name[-8:-4]
            study_environment = study_environment.lower()
            if (study_environment[0] == '_'):
                study_environment = study_environment[1:]
            if study_environment not in ('prod','uat'):
                study_environment = "Invalid Study Environment"
                
            domainstats={}

            if study_id is None:
                print("Unable to get the study_id value. study_id will be set to 'UnknownStudyId' for the notification.")
                study_id = "UnknownStudyId"


            message = build_clinical_study_json(study_id, errant_tables, study_environment, checks_data_job_id, "", load_timestamp,"", error_msg, domainstats)
            send_notification(study_id, study_environment, "Failed", admin_user_recipients, message, vpc_name, "NA", "", "", "", "")
            raise e
else:
    print("No study file exists to process")
