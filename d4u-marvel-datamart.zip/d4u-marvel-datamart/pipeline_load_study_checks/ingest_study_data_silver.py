# Databricks notebook source
from pyspark.sql.functions import regexp_replace, md5, concat_ws, array, col, lit, struct, to_json, when
from pyspark.sql.types import MapType, StringType, ArrayType, TimestampType
from delta.tables import *
import functools
import re
import operator
from datetime import datetime as dt
from pyspark.sql.functions import to_date,expr
import sys, traceback


# COMMAND ----------

# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_study_checks

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

domains = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes",key = "available_domains",default = "error", debugValue = "")
tables_list = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes",key = "tables_list",default = "error", debugValue = "")
config_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_dict",default = "error", debugValue = "")
# initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
# study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
# create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
# metadata_log_file = dbutils.jobs.taskValues.get(taskKey = "handle_metadata_changes_silver", key = "metadata_log_file", default = "", debugValue = "")


# COMMAND ----------

def populate_silver_tables(domain, config_dict, catalog_silver, study_schema_name, study_extraction_path, temp_study_id):
    spark.sql("SET spark.sql.legacy.timeParserPolicy = LEGACY")  # Ensure legacy datetime parsing behavior

    temp_table = f'`{catalog_marvel}`.`default`.`temp_{study_schema_name}_{domain}`'

    try:
        # Derive filenames from the domain
        file_name = domain.replace("fbt_", "")
        data_file = file_name + ".csv"
        meta_file = file_name + "-meta.csv"
        domain_table_name = domain

        logger.info(f'Processing domain {domain}')

        # Read the main domain data file
        df_inputdata = spark.read\
            .option('header', 'true')\
            .option('delimiter', ',')\
            .option("ignoreLeadingWhiteSpace", "true")\
            .option('quote', None)\
            .option('escape', '"')\
            .option('multiline', True)\
            .csv(f"{study_extraction_path}/{data_file}")
        logger.info(f'[{domain}] df_inputdata : count {df_inputdata.count()}')
        #df_inputdata.display()

        df_inputdata.na.drop("all")

        # Load and inspect the metadata config for column formatting
        df_pandas = build_pandas_df(study_extraction_path, meta_file, domain)
        logger.info(f'[{domain}] df_pandas : count {df_pandas.count()}')
        #df_pandas.display()

        # List of system columns that are handled outside the formatting loop
        skip_columns = {
            "D4U_RECID",
            "D4U_RECVER",
            "D4U_DATAPROV",
            "D4U_ISACTIVE",
            "D4U_ISDROP"
        }

        # Calculate D4U_RECID and D4U_RECVER from raw input strings before transformations
        composite_keys = config_dict[domain]['RecIdKeys']
        RECVER_KEY = config_dict[domain]['RecverKey']
        if not composite_keys:
            composite_keys = list(set(df_inputdata.columns) - set(RECVER_KEY))

        df_inputdata = df_inputdata\
            .withColumn("D4U_RECID", md5(concat_ws("||", *[col(k) for k in composite_keys])))\
            .withColumn("D4U_RECVER", md5(concat_ws("||", *[col(k) for k in RECVER_KEY])))

        # Apply formatting rules after ID/version hash is created
        for i, row in df_pandas.iterrows():
            col_name = row["name"]
            col_expr = row["finalqueryformat"]

            if col_name == "D4U_RECVERDATE":
                logger.info(f'[{domain}]  Setting {col_name} as timestamp(load_timestamp)')
                df_inputdata = df_inputdata.withColumn(col_name, lit(load_timestamp).cast(TimestampType()))
            elif col_name in skip_columns:
                logger.info(f'[{domain}]  Skipping {col_name} (handled separately)')
            else:
                logger.info(f'[{domain}]  Applying format {col_expr} to column {col_name}')
                df_inputdata = df_inputdata.withColumn(col_name, expr(col_expr))

        # logger.info(f'[{domain}] df_inputdata after loop')
        #df_inputdata.display()

        df_inputdata = df_inputdata\
            .withColumn("D4U_DATAPROV", array(
                to_json(create_map(
                    lit("table"), lit(domain_table_name),
                    lit("D4U_RECID"), col("D4U_RECID"),
                    lit("D4U_RECVER"), col("D4U_RECVER")
                ))
            ).cast("string"))\
            .withColumn("D4U_ISACTIVE", lit(True))\
            .withColumn("D4U_ISDROP", lit(False))

        # Drop duplicate records based on D4U_RECID
        logger.info(f'[{domain}] Checking for duplicates')
        tcount = df_inputdata.count()
        df_inputdata = df_inputdata.dropDuplicates(["D4U_RECID"])
        dcount = tcount - df_inputdata.count()
        logger.info(f'[{domain}] {"Found and removed" if dcount > 0 else "No"} duplicates {f"{dcount}" if dcount > 0 else ""}')

        # Prepare the formatted DataFrame for comparison and merging
        df = df_inputdata.alias("df")

        # Load existing silver table and filter for active, non-dropped records
        silver_table_name = f"`{catalog_silver}`.`{study_schema_name}`.`{domain_table_name}`"
        logger.info(f'[{domain}] silver_table_name : {silver_table_name}')
        silverTable = DeltaTable.forName(spark, silver_table_name).alias('silver')
        silver_records = silverTable.toDF().where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
        list_columns = silver_records.columns

        logger.info(f'[{domain}] Silver has {silver_records.count()} active records')
        logger.info(f'[{domain}] Input file has {df.count()} records')

        # Identify dropped records (present in silver but not in input)
        df_drop = silver_records.join(df, on='D4U_RECID', how='leftanti')\
            .withColumn("D4U_ISDROP", lit(True))\
            .withColumn("D4U_RECVERDATE", lit(load_timestamp).cast('timestamp'))\
            .select(list_columns)
        logger.info(f'[{domain}] Found {df_drop.count()} dropped records')

        # Identify newly inserted records
        df_insert = df.join(silver_records, on='D4U_RECID', how='leftanti')\
            .select(list_columns)
        logger.info(f'[{domain}] Found {df_insert.count()} new records')

        # Identify updated records (same RECID, different RECVER)
        df_update = silver_records.join(df, expr("df.D4U_RECID = silver.D4U_RECID and df.D4U_RECVER != silver.D4U_RECVER"), how='inner')\
            .select(['df.*'])\
            .select(list_columns)
        logger.info(f'[{domain}] Found {df_update.count()} updated records')

        # Combine all changes into one unioned DataFrame
        df_insert_update_drop = df_insert.union(df_update).union(df_drop)

        # Initial Load Path: silver table is empty
        if silver_records.count() == 0:
            logger.info(f'[{domain}] Merging initial load')
            logger.info(f'[{domain}] 0 records in silver before merge')
            logger.info(f'[{domain}] Merging {df_insert_update_drop.count():,} records into silver')

            tic = time.perf_counter()
            silverTable.merge(
                source=df_insert_update_drop.alias("df"),
                condition=col('df.D4U_RECID').isNull()
            ).whenNotMatchedInsertAll().execute()
            toc = time.perf_counter()

            logger.info(f'[{domain}] {silverTable.toDF().count():,} records in silver after merge')
            logger.info(f'[{domain}] Merge completed {toc - tic:0.4f} seconds')

        # Incremental Load Path
        else:
            logger.info(f'[{domain}] Merging incremental load')
            logger.info(f'[{domain}] {silverTable.toDF().count():,} records in silver before merge')
            logger.info(f'[{domain}] Merging {df_insert_update_drop.count()} records into silver')

            # Stage the data to a temp Delta table to prevent Spark cache issues
            df_insert_update_drop.write\
                .mode("overwrite")\
                .format("delta")\
                .option("overwriteSchema", "true")\
                .saveAsTable(temp_table)

            tic = time.perf_counter()

            # Mark existing records as inactive where necessary
            logger.info(f'[{domain}] Setting all silver records as inactive')
            silverTable.merge(
                source=df_insert_update_drop.alias("df"),
                condition=col('df.D4U_RECID') == col('silver.D4U_RECID')
            ).whenMatchedUpdate(set={"silver.D4U_ISACTIVE": lit(False)}).execute()

            # Reload staged data and insert all new/updated records
            df_insert_update_drop = spark.sql(f"select * from {temp_table}")
            logger.info(f'[{domain}] Merging {df_insert_update_drop.count()} records into silver')

            silverTable.merge(
                source=df_insert_update_drop.alias("df"),
                condition=col('df.D4U_RECID').isNull()
            ).whenNotMatchedInsertAll().execute()

            toc = time.perf_counter()
            logger.info(f'[{domain}] {silverTable.toDF().count():,} records in silver after merge')
            logger.info(f'[{domain}] Merge completed {toc - tic:0.4f} seconds')

    except Exception as p:
        global error_process
        global error_table
        error_process = "ingest_study_data_silver"
        error_table = f"{catalog_silver}.{study_schema_name}.{domain}"
        raise p

    finally:
        # Cleanup: drop temp table used for incremental staging
        spark.sql(f"drop table IF EXISTS {temp_table}")

# COMMAND ----------

# domains = []
# domains.append("fbt_checks")
# print(domains)

# config_dict = {}
# config_dict['fbt_checks'] = {}  # Initialize the nested dictionary
# config_dict['fbt_checks']['RecIdKeys'] = ['ISSUEID']
# config_dict['fbt_checks']['RecverKey'] = ['MODIFIEDDATE']
# print(config_dict)

# target_study_extraction_path = '/datamart/ExtractionPoint/rgt123nsc3002/FBT/prod/RGT123NSC3002_checks_20240806T094330_prod/'
# print(target_study_extraction_path)

# study_schema_name = 'RGT123NSC3002'
# print(study_schema_name)

# temp_study_id = 'RGT123NSC3002'
# print(temp_study_id)

# COMMAND ----------

try:
    logger.info("Silver Layer Tables Insertion Started")
    study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"
    parallel_runs = ThreadPool(thread_count)
    parallel_runs.starmap(populate_silver_tables,zip(domains, repeat(config_dict), repeat(catalog_silver), repeat(study_schema_name), repeat(study_extraction_path), repeat(temp_study_id)))
    logger.info("Silver Layer Tables Insertion Completed")

except Exception as e:
    logger.error(f'Error: {repr(traceback.format_exception(e))}')
    handle_error(e, error_process, error_table,tables_list)
    raise e
