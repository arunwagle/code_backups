# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_study_checks

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

 domains = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes",key = "available_domains",default = "error", debugValue = "")
 tables_list = dbutils.jobs.taskValues.get(taskKey  = "handle_metadata_changes",key = "tables_list",default = "error", debugValue = "")
 config_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_dict",default = "error", debugValue = "")
 metatables = [x+"_meta" for x in list(set(domains))]
 maintable = ["fbt_checks"]
 exceptiontables = list(set(domains)-set(maintable))
 mainmeta = [x+"_meta" for x in maintable]
 exceptionmeta = [x + "_meta" for x in exceptiontables]

# COMMAND ----------

def saveToGoldMeta(tableName,catalog_gold,catalog_silver,study_schema_name):
  try:
      silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
      goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')
      if(goldTable.toDF().count()==0):

            goldTable \
                .merge(
                    source = silverTable, 
                    condition = (col('silver.name') == col('gold.name')  )
                ) \
                .whenNotMatchedInsertAll() \
                .execute()
      
      else: 
          
          goldTable.merge(
                    source = silverTable, 
                    condition = (col('silver.name') == col('gold.name') )
                ).whenMatchedDelete(
                    condition = ((col('silver.label') != col('gold.label')) | (col('silver.type') != col('gold.type')) | (col('silver.length') != col('gold.length')))
                ).execute()
          
          goldTable \
                .merge(
                    source = silverTable, 
                    condition = (col('silver.name') == col('gold.name'))
                ) \
                .whenNotMatchedInsertAll() \
                .execute()
  except Exception as p:
        global error_process
        global error_table
        error_process = "Ingest_data_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
        raise p



# COMMAND ----------

def saveToGoldMetaexception(tableName,catalog_gold,catalog_silver,study_schema_name):
  try:
      silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
      goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')

      

      if(goldTable.toDF().count()==0):

            goldTable \
                .merge(
                    source = silverTable, 
                    condition = (col('silver.name').isNull())
                ) \
                .whenNotMatchedInsertAll() \
                .execute()
      
      else: 
          
          goldTable.delete(col('name').isNotNull())               
                
          
          goldTable \
                .merge(
                    source = silverTable, 
                    condition = (col('silver.name').isNull())
                ) \
                .whenNotMatchedInsertAll() \
                .execute()
  except Exception as p:
        global error_process
        global error_table
        error_process = "Ingest_data_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
        raise p



# COMMAND ----------

 def saveToGold(tableName,catalog_gold,catalog_silver,study_schema_name):
    try:
     
        silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
        goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')

        print('Merging silver updates to gold')

        if(goldTable.toDF().count()==0):

          goldTable \
              .merge(
                  source = silverTable, 
                  condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
              ) \
              .whenNotMatchedInsertAll() \
              .execute()

        else: 

          
          silverTable_drop = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == True)).alias('silver_drop')        

          # Delete records updated in silver
          goldTable.merge(
                  source = silverTable, 
                  condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
              ).whenMatchedDelete(
                  condition = col('silver.D4U_RECVER') != col('gold.D4U_RECVER')
              ).execute()

          # Delete Dropped records no in silver DF
          goldTable \
              .merge(
                  source = silverTable_drop, 
                  condition = (col('silver_drop.D4U_RECID') == col('gold.D4U_RECID'))
              ) \
              .whenMatchedDelete(
                  condition = col('silver_drop.D4U_RECVER') == col('gold.D4U_RECVER')
              ) \
              .execute()
          

          # Add all new and updated records
          goldTable \
              .merge(
                  source = silverTable, 
                  condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
              ) \
              .whenNotMatchedInsertAll() \
              .execute()

        
    except Exception as p:
        global error_process
        global error_table
        error_process = "Ingest_data_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
        raise p
  

# COMMAND ----------

 def saveToGoldexception(tableName,catalog_gold,catalog_silver,study_schema_name):
    try:
     
        silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
        goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')

        print('Merging silver updates to gold')

        if(goldTable.toDF().count()==0):

            goldTable \
                .merge(
                    source = silverTable, 
                    condition = (col('silver.D4U_RECVERDATE').isNull())
                ) \
                .whenNotMatchedInsertAll() \
                .execute()
      
        else: 
            newcol = goldTable.toDF().columns[1]
            goldTable.delete(col(newcol).isNotNull())
                  
            
            goldTable \
                  .merge(
                      source = silverTable, 
                      condition = (col('silver.D4U_RECVERDATE').isNull())
                  ) \
                  .whenNotMatchedInsertAll() \
                  .execute()

        
    except Exception as p:
        global error_process
        global error_table
        error_process = "Ingest_data_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
        raise p
  

# COMMAND ----------

def saveToGoldLabel(tableName,catalog_gold,catalog_silver,study_schema_name):
  try:
    silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
    goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')
    if(goldTable.toDF().count()==0):

          goldTable \
              .merge(
                  source = silverTable, 
                  condition = ((col('silver.NAME') == col('gold.NAME')) & (col('silver.LISTING')==col('gold.LISTING')))
              ) \
              .whenNotMatchedInsertAll() \
              .execute()
    
    else: 
        
        goldTable.merge(
                  source = silverTable, 
                  condition = ((col('silver.NAME') == col('gold.NAME')) & (col('silver.LISTING')==col('gold.LISTING')))
              ).whenMatchedDelete(
                  condition = col('silver.LABEL') != col('gold.LABEL')
              ).execute()
        
        goldTable \
              .merge(
                  source = silverTable, 
                  condition = ((col('silver.NAME') == col('gold.NAME')) & (col('silver.LISTING')==col('gold.LISTING')))
              ) \
              .whenNotMatchedInsertAll() \
              .execute()

  except Exception as p:
        global error_process
        global error_table
        error_process = "Ingest_data_gold"       
        error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
        raise p


# COMMAND ----------

try:
    #logger.info("Gold Layer Tables Insertion Started")
    parallel_exec = ThreadPool(thread_count)
    metatables.append("checks_labels")
    

    #creation of meta tables and labels table in gold 
    parallel_exec.starmap(creategoldTables,zip(metatables,repeat(catalog_gold),repeat(catalog_silver),repeat(study_schema_name)))
    

    #Inserting data into gold layer tabels
    parallel_exec.starmap(saveToGold,zip(list(set(maintable+exceptiontables)),repeat(catalog_gold),repeat(catalog_silver),repeat(study_schema_name)))
    
  
    
    
    parallel_exec.starmap(saveToGoldMeta,zip(mainmeta+exceptionmeta,repeat(catalog_gold),repeat(catalog_silver),repeat(study_schema_name)))

  

    tableName="checks_labels"
    saveToGoldLabel(tableName,catalog_gold,catalog_silver,study_schema_name)

    #logger.info("Inserting records into Gold Layer Tables completed")
except Exception as e:
   
  #error_process = "overwrite_gold_layer"
  # logger.error("Gold Layer Tables Insertion Failed")
  # logger.error(e)
  # log_file_data=read_log_file(p_filename)      
  # write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,metadata_log_file,
  #         ingest_silver_log_file,nonclinicdom_log_file,log_file_data,"","",log_file)
  handle_error(e,error_process,error_table,tables_list)
  

# COMMAND ----------

# try:
#     log_file_data=read_log_file(p_filename)
#     dbutils.jobs.taskValues.set(key   = "overwrite_gold_log_file", value = log_file_data)
# except Exception as e:
#     raise e

