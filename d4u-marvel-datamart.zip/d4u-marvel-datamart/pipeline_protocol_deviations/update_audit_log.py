# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

# MAGIC %run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_configuration

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_clinical_study

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_protocol_deviations

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

import requests
import json
import base64
from pathlib import Path, PurePath
import os

# COMMAND ----------

studyId=study_id

# COMMAND ----------

# MAGIC %run ../programmed_listing_notebooks/dre_utils

# COMMAND ----------

# import traceback
# from pyspark.sql import functions as F
# from pyspark.sql.functions import cast,col,date_format,current_timestamp
# from pyspark.sql.types import StringType,BooleanType,DateType
# from datetime import datetime as dt 
# import time
# from delta.tables import DeltaTable
# from pyspark.sql.functions import col, max

# def saveToGold(study_schema_name,catalog_gold,catalog_silver,tableName):
#     try:
        
#         silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == False)).alias('silver')
#         goldTable = DeltaTable.forName(spark, str(f"`{catalog_gold}`.`{study_schema_name}`.`{tableName}`")).alias('gold')

#         logger.info('Merging silver updates to gold')

#         if(goldTable.toDF().count()==0):
#             logger.info(f'0 records in gold before merge')
#             goldTable \
#                 .merge(
#                     source = silverTable, 
#                     condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
#                 ) \
#                 .whenNotMatchedInsertAll() \
#                 .execute()
#             logger.info(f'{goldTable.toDF().count():,} records in gold after merge')
#         else: 

        
#             silverTable_drop = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`")\
#                 .where((col('D4U_ISACTIVE') == True) & (col('D4U_ISDROP') == True)).alias('silver_drop')        
            
#             logger.info(f'{goldTable.toDF().count():,} records in gold before merge')

#             # Delete records updated in silver
#             goldTable.merge(
#                 source = silverTable, 
#                 condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
#             ).whenMatchedDelete(
#                 condition = col('silver.D4U_RECVER') != col('gold.D4U_RECVER')
#             ).execute()

#             # Delete Dropped records no in silver DF
#             goldTable \
#                 .merge(
#                     source = silverTable_drop, 
#                     condition = (col('silver_drop.D4U_RECID') == col('gold.D4U_RECID'))
#                 ) \
#                 .whenMatchedDelete(
#                     condition = col('silver_drop.D4U_RECVER') == col('gold.D4U_RECVER')
#                 ) \
#                 .execute()
          
#             # Add all new and updated records
#             goldTable \
#                 .merge(
#                     source = silverTable, 
#                     condition = (col('silver.D4U_RECID') == col('gold.D4U_RECID'))
#                 ) \
#                 .whenNotMatchedInsertAll() \
#                 .execute()

#             logger.info(f'{goldTable.toDF().count():,} records in gold after merge')

        
#     except Exception as p:
#         global error_process
#         global error_table
#         error_process = "Ingest_data_gold"       
#         error_table = f"{catalog_gold}.{study_schema_name}.{tableName}"
#         raise p
  

# COMMAND ----------

try:

  max_date_result = spark.sql(f"SELECT max(date) AS protocol_dev_date FROM(SELECT create_dtm AS date FROM `{catalog_gold}`.`{study_schema_name}`.`{table_name}` UNION SELECT update_dtm AS date FROM `{catalog_gold}`.`{study_schema_name}`.`{table_name}`)")  

  load_timestamp_prot_dev = max_date_result.collect()[0][0]
  print(load_timestamp_prot_dev)

  load_timestamp_prot_dev_str = str(load_timestamp_prot_dev)
  load_timestamp_prot_dev_datetime = dt.strptime(load_timestamp_prot_dev_str, '%Y-%m-%d %H:%M:%S')
  source_date_refresh = load_timestamp_prot_dev_datetime.strftime("%Y-%m-%dT%H:%M:%S")
  print(source_date_refresh)
  
except Exception as e:

  print(repr(traceback.format_exception(e)))
  error_process = "Ingest_data_gold"       
  error_table = f"{catalog_gold}.{study_schema_name}.{table_name}"
  tables_list=[table_name]
  handle_error(e, error_process, error_table,tables_list)



# COMMAND ----------


try:
    domains=[table_name]
    spark.sql("set spark.sql.ansi.enabled = false")
    initial_df = spark.sql("select '' as table,'' as drop,'' as insert,'' as updated ,''as metadata_change")
    for x in domains:

        
        checks_history_df = spark.sql(f"describe history `{catalog_gold}`.`{study_schema_name}`.{x}")
        
        
        latest_checks_history_df = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='MERGE'))

                                                    
        column_changes_count = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='CHANGE COLUMN')).count()
        add_columns_count = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='ADD COLUMNS')).count()
        
        if(column_changes_count >0):
            meta_changes =  checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='CHANGE COLUMN')).select(collect_list('operationParameters')).collect()[0][0] 
        else:
            meta_changes = "n/a"  

        if(add_columns_count > 0):
            added_columns = checks_history_df.filter((checks_history_df.job.jobRunId == run_id)&(checks_history_df.operation =='ADD COLUMNS')).select(collect_list('operationParameters')).collect()[0][0] 
        else:
            added_columns = "n/a"

        print(latest_checks_history_df.count())
        if(latest_checks_history_df.count() ==3):
        
            min_version = int(latest_checks_history_df.select(min('version')).collect()[0][0])
            # DJM 3/15/24 Remove debug code - print(min_version)          
            
            updated_records =int(latest_checks_history_df.filter(col('version')==int(min_version)).select('operationMetrics.numTargetRowsMatchedDeleted').collect()[0][0])

            dropped_records = int(latest_checks_history_df.filter(col('version')==int(min_version)+1).select('operationMetrics.numTargetRowsMatchedDeleted').collect()[0][0])

            all_inserts = int(latest_checks_history_df.filter(col('version')==int(min_version)+2).select('operationMetrics.numTargetRowsInserted').collect()[0][0])


            new_inserted_records = all_inserts - updated_records

        elif(latest_checks_history_df.count() ==1):

            dropped_records = 0
            updated_records = 0
            new_inserted_records  = int(latest_checks_history_df.select('operationMetrics.numOutputRows').collect()[0][0])

        meta_changes = str(meta_changes).replace('\'','')
        added_columns = str(added_columns).replace('\'','')

        df1 = spark.sql(f"select '{x}' as table,{dropped_records} as drop,{new_inserted_records} as insert,{updated_records} as updated ,'meta_change:{meta_changes},added_columns:{added_columns}'as metadata_change")
        
        # display(df1)
        initial_df = initial_df.union(df1)
except Exception as e:
    print(e)

# COMMAND ----------

try:
    records=get_basic_listing_config(study_id, study_environment, data_model)
    if len(records) > 0:
        source_job_name = "submit_process_basic_listings"
        listing_job_id = dbutils.widgets.get("basic_prog_listing_jobid")
        lifecycle=study_environment
        devMode="True"
        dataModel=data_model
        api_call = api_submit_job()  
    else:
        print(f"No basic listing found for study : {study_id}")
except Exception as e:
    raise e

# COMMAND ----------

job_status = "SUCCESS"
message = "Pipeline Job %s has been executed successfully" % (job_name)
# Update audit log
update_audit_log(batch_id, job_id, run_id, study_id, study_environment, job_status, "Job has been executed successfully")
#logger.info("Updating process end timstamp in audit log table ")

# COMMAND ----------

final_stats_df = initial_df

# COMMAND ----------

errant_tables = "N/A"
msg = "Success: The Protocol Deviations data for Study Id - {0} has been processed successfully".format(study_id)

domainstats = build_domain_statistics_dictionary(final_stats_df)
message = build_clinical_study_json(study_id,errant_tables,study_environment,job_id,run_id,source_date_refresh,data_source,msg,domainstats)




send_notification(study_id,study_environment,"Success",business_user_recipients,message,vpc_name,"","","","",load_timestamp)
