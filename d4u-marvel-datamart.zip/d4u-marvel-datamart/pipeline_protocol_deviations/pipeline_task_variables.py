# Databricks notebook source
# DBTITLE 1,Get pipeline task variables
temp_study_id= dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "temp_study_id", default = "", debugValue = "68284528MMY3031")

pipeline_environment = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "pipeline_environment", default = "release", debugValue = "release")

batch_id = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "batch_id", default = "", debugValue = "1670398893")

study_id = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "study_id", default = "", debugValue = "68284528MMY3031")

study_domain_model = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "domain_model", default = "", debugValue = "drm")

study_environment = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "environment", default = "", debugValue = "uat")

job_id = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "job_id", default = "", debugValue = "211349027580568")

run_id = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "run_id", default = "", debugValue = "1234567")

load_timestamp = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "load_timestamp", default = "", debugValue = "2022-12-09T07:00:11")

config_dict = dbutils.jobs.taskValues.get(taskKey = "read_configuration_from_dre", key = "config_dict", default = "", debugValue = "")

for key in config_dict:
  table_name=key

print(table_name)

study_schema_name = study_id

# Define Silver & Gold Catalog Names
catalog_silver = f"marvel-{study_environment}-silver_qa" if (pipeline_environment == "qa") else f"marvel-{study_environment}-silver"
catalog_gold = f"marvel-{study_environment}-gold_qa" if (pipeline_environment == "qa") else f"marvel-{study_environment}-gold"
