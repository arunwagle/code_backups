# Databricks notebook source
# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

#%run ../utils/custom_logging

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_study_specific_report

# COMMAND ----------

# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./clinical_study_util

# COMMAND ----------

# initiate_process_log_file = dbutils.jobs.taskValues.get(taskKey = "initiate_process_study_data", key = "initiate_process_log_file", default = "", debugValue = "")
# study_zip_log_file = dbutils.jobs.taskValues.get(taskKey = "study_zip_extract", key = "study_zip_log_file", default = "", debugValue = "")
# create_schema_log_file = dbutils.jobs.taskValues.get(taskKey = "create_silver_gold_schema", key = "create_schema_log_file", default = "", debugValue = "")
config_dict = dbutils.jobs.taskValues.get(taskKey  = "read_postgres_db",key = "config_dict",default = "error", debugValue = "")
domains=[]
for key in config_dict:
    domains.append(key)
metatables_list=[]
for i in domains:
    i=i+"_meta"
    metatables_list.append(i)
metatables_list.append("ssr_labels")
tables_list= domains+metatables_list
dbutils.jobs.taskValues.set(key   = "available_domains", value = domains)
dbutils.jobs.taskValues.set(key   = "tables_list", value = tables_list)

# COMMAND ----------

try:
    #logger.info("Creation of Lables Table if not Exists")
        spark.sql(f"CREATE TABLE IF NOT EXISTS `" + catalog_silver + "`.`" + study_schema_name + "`.`" + "ssr" + "_labels` \
        ( \
        STUDYID string, \
        SOURCE string, \
        REPORT string, \
        NAME string, \
        LABEL string, \
        D4U_RECVERDATE string, \
        D4U_ISACTIVE boolean, \
        D4U_ISDROP boolean \
        ) PARTITIONED BY (STUDYID,REPORT)" )
    
except Exception as e: 
    #logger.error("Creation of Lables Table Failed")
    error_process = "handle_metadata_changes_silver"       
    error_table = f"{catalog_silver}.{study_schema_name}.ssr_lables"
    # logger.error(e)
    # log_file_data=read_log_file(p_filename)      
    # write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,log_file_data,"","","","","",log_file)
    handle_error(e,error_process,error_table)

# COMMAND ----------

def create_table(domain,study_id,study_extraction_path,catalog_silver,catalog_gold,temp_study_id):
    print("create_table function is called...")
    global error_table_suffix 
    error_table_suffix= ""
    try:
        file_name= domain
        data_file = file_name  + ".csv"
        meta_file = file_name + "-meta.csv"
        domain_table_name = domain
        print(f"Data File: {data_file}")
        print(f"Meta File: {meta_file}")
        print(f"Domain Table Name: {domain_table_name}")

        df_pandas = build_pandas_df(study_extraction_path, meta_file,domain)      
        # print(df_pandas)
        column_array = df_pandas.values
        querystr = ""
        for i in range(0,len(column_array)):
            querystr = querystr + str(column_array[i][0]) + " " + str(column_array[i][1]) + str(column_array[i][3]) + " comment \"" + str(column_array[i][2]) + "\","
            # DJM 3/15/24 Performance Tweak - print(querystr)
        querystr = querystr[0:len(querystr)-1]
        query1,query2 = querystr.split('D4U_ISACTIVE',1)
        gold_querystr=query1[0:len(query1)-1]

        df = spark.read.option("header","true").option("delimiter",",").option("ignoreLeadingWhiteSpace","true").csv(study_extraction_path + "/" + meta_file + "")
        df = df.na.drop("all")
        df.createOrReplaceTempView(f"{temp_study_id}_{domain}_metadata")
        #domain table names must be set lowercase for string match with actual table name which is always lowercase
        if not (is_table_exist(catalog_silver, study_id, domain_table_name.lower())):
            # Create Silver domain table if not exist in study schema
            spark.sql("CREATE TABLE `" + catalog_silver + "`.`" + study_id + "`.`" + domain_table_name + "` (" + querystr + ")")
            spark.sql("CREATE TABLE `" + catalog_gold + "`.`" + study_id + "`.`" + domain_table_name + "` (" + gold_querystr + ")")
        else:
            # METADATA COMPARISON
            new_schema = spark.createDataFrame(df_pandas)
            new_schema = new_schema.select(col("name").alias("col_name"),col("finalformat").alias("data_type"),col("label").alias("comment"),col("varnum"))
            old_schema = spark.sql(f"DESCRIBE TABLE `{catalog_silver}`.`{study_schema_name}`.`{domain}`")
            old_schema = old_schema.withColumn("old_varnum", lit(0))
            compare_df = new_schema.join(old_schema,new_schema.col_name == old_schema.col_name,"fullouter").select(old_schema.col_name.alias("old_column"),new_schema.col_name.alias("new_column"),old_schema.data_type.alias("old_dtype"),new_schema.data_type.alias("new_type"),when(new_schema["data_type"]==old_schema["data_type"],lit("pass")).otherwise(lit("fail")).alias("dtype_match"),old_schema.old_varnum.alias("old_varnum"),new_schema.varnum.alias("varnum"), new_schema.comment.alias("new_comment"),old_schema.comment.alias("comment"),when(new_schema["comment"]==old_schema["comment"],lit("pass")).otherwise(lit("fail")).alias("comment_match"))          
            dtype_changes_df = compare_df.filter((col("dtype_match") == "fail") & (col("old_column").isNotNull()))
            newcols_changes_df = compare_df.filter(col("old_column").isNull())
            newcols_changes_df = newcols_changes_df.withColumn('varnum',col('varnum').cast('int')).orderBy(col('varnum'))
            comment_changes_df = compare_df.filter((col("comment_match") == "fail") & (col("old_column").isNotNull())&(col("new_column").isNotNull()))
            new_columns_added = newcols_changes_df.collect()
            dtype_changes = dtype_changes_df.collect()
            comment_changes = comment_changes_df.collect()
            #for including new columns
            for row in new_columns_added:
                column_name = row.new_column
                data_type = row.new_type
                
                label = row.new_comment
                add_new_column(catalog_silver, study_schema_name, domain, column_name, data_type,label,temp_study_id)
                add_new_column(catalog_gold, study_schema_name,  domain, column_name, data_type,label,temp_study_id)

            #for changing the datatype of existing column
            for row in dtype_changes:
                column_name = row.old_column
                #limiting the target datatype to string only(for sprint 2)
                #data_type = row.new_type
                data_type = "string"
                old_type = row.old_dtype
                label = row.comment
                modify_column_datatype(catalog_silver, study_schema_name,  domain, column_name, data_type,label,old_type)
                modify_column_datatype(catalog_gold, study_schema_name, domain, column_name, data_type,label,old_type)
            for row in comment_changes:
                column_name = row.new_column
                #limiting the target datatype to string only(for sprint 2)
                #data_type = row.new_type
                data_type =row.new_type 
                label = row.new_comment
                modify_column_label(catalog_silver, study_schema_name, domain, column_name, data_type,label)
                modify_column_label(catalog_gold, study_schema_name, domain, column_name, data_type,label)
        # Drop the metadata temp view created for current domain
        spark.sql(f"DROP VIEW {temp_study_id}_{domain}_metadata")



        try:
            # Populate domain meta data table
            ingest_domain_metadata(df,catalog_silver,study_schema_name,domain,temp_study_id)
        except Exception as t:
            error_table_suffix = "_meta"
            raise t
        try:  
            # Populate domain lables table
            df_labels=df.select("name","label")
            labels_table_name = "ssr_labels"
            df_labels = df_labels.withColumn("REPORT",lit(file_name)) \
                      .withColumn("STUDYID",lit(study_id)) \
                      .withColumn("SOURCE",lit("ssr")) \
                      .withColumn("D4U_RECVERDATE",lit(load_timestamp).cast('timestamp')) \
                      .withColumn("D4U_ISACTIVE",lit(True)) \
                      .withColumn("D4U_ISDROP",lit(False))
            df_labels = df_labels.select("STUDYID","SOURCE","REPORT","NAME","LABEL","D4U_RECVERDATE","D4U_ISACTIVE","D4U_ISDROP")
            ingest_domain_labels(df_labels, catalog_silver, study_schema_name, labels_table_name,file_name,temp_study_id)
        except Exception as y:
            #global error_table
            #error_process = "populate_domain_labels"       
            #error_table = f"{catalog_silver}.{study_schema_name}.{study_domain_model}_lables"
            raise y
    except Exception as p:
        global error_process
        global error_table
        error_process = "handle_metadata_changes_silver_gold"       
        error_table = f"{catalog_silver}.{study_schema_name}.{domain}{error_table_suffix}"
        raise p



# COMMAND ----------

try:
    # logger.info("Creation of SSR Tables in Silver Layer Started ")
    # logger.info("Creation and Insertion of  SSR Metadata Tables in Silver Layer Started")
    # logger.info("SSR Lables Table Insertion started at Silver Layer")
    study_extraction_path = f"{s3_marvel_assets_mountpoint}/{target_study_extraction_path}"  
    parallels = ThreadPool(thread_count)
    parallels.starmap(create_table,zip(domains,repeat(study_id),
                                   repeat(study_extraction_path),repeat(catalog_silver),repeat(catalog_gold),repeat(temp_study_id)))
    #logger.info("Creation of Domain Tables in Silver Layer Completed ")
    #logger.info("Creation and Insertion of  Domain Metadata Tables in Silver Layer Completed")
    #logger.info("Domain Lables Table Insertion completed at Silver Layer")
except Exception as e:
        # logger.error("Error at handle_metadata_changes_silver Process")
        # logger.error(e)
        # log_file_data=read_log_file(p_filename)      
        # write_log_file(initiate_process_log_file,study_zip_log_file,create_schema_log_file,log_file_data,"","","","","",log_file)
        handle_error(e,error_process,error_table,tables_list)

# COMMAND ----------

# try:  
#     log_file_data=read_log_file(p_filename)
#     dbutils.jobs.taskValues.set(key   = "metadata_log_file", value = log_file_data)
# except Exception as e:
#     raise e


