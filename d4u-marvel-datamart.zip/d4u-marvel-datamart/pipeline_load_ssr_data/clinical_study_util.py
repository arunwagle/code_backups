# Databricks notebook source
# MAGIC %run ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ./pipeline_task_variables

# COMMAND ----------

import pandas as pd
import re
from pyspark.sql.functions import col,expr,when,lit,explode,to_json,create_map,array,StructType
import datetime
from datetime import datetime as dt
from pyspark.sql.functions import col, lit,current_timestamp
import boto3 
import zipfile 
from io import BytesIO 
import json 
import re 
import time
from delta.tables import *
from multiprocessing.pool import ThreadPool
from itertools import repeat
from pyspark.sql.functions import concat,lit,col,collect_list,concat_ws,md5,collect_set,min,collect_list
from pyspark.sql.functions import desc
today=dt.today()
current_date=today.strftime("%Y%m%d")

# COMMAND ----------

def tableExists(catalog_name,study_schema_name,table_name):
        return spark.sql(f'show tables in `{catalog_name}`.`{study_schema_name}`').selectExpr(f"any(tableName =='{table_name}')").collect()[0][0]

# COMMAND ----------

def createTableIfNotExist(catalog_name,study_schema_name,  tableName,  schema):
    
    if tableExists(catalog_name,study_schema_name,tableName):
        print(f'Table {tableName} already exist.')
    else:
        
        emptyDF = spark.createDataFrame([], schema)
        emptyDF \
            .write \
            .mode("overwrite") \
            .format("delta") \
            .saveAsTable(f"`{catalog_name}`.`{study_schema_name}`.`{tableName}`")

        #spark.sql(f"""COMMENT ON TABLE {str(tableName)} IS '{tableTitle}'""")
        
        print(f'Created new table {tableName}')

    return f"`{catalog_name}`.`{study_schema_name}`.`{tableName}`"

# COMMAND ----------

def creategoldTables(tableName,catalog_gold,catalog_silver,study_schema_name):
    silverTable = spark.table(f"`{catalog_silver}`.`{study_schema_name}`.`{tableName}`").alias('silver')
    goldColumns = list(filter(lambda x : x.name not in ["D4U_ISACTIVE","D4U_ISDROP"], silverTable.schema.fields))
    goldTable = createTableIfNotExist(catalog_gold,study_schema_name,  tableName,schema = StructType(goldColumns))
    

# COMMAND ----------

def restore(table_name,audit_df,catalog_name,study_schema_name,process_timestamp):
    if (is_table_exist(catalog_name, study_schema_name, table_name)):
        df= spark.sql(f"DESCRIBE HISTORY `{catalog_name}`.`{study_schema_name}`.`{table_name}`")
        df=df.orderBy(desc("timestamp")).select("version","timestamp").limit(1)
        timestamp=df.collect()[0][1]
        version=df.collect()[0][0]
        df1=spark.sql(f"select to_timestamp('{process_timestamp}') as tm")
        load_timestamp =df1.collect()[0][0]
        drop_query=f"DROP TABLE IF EXISTS `{catalog_name}`.`{study_schema_name}`.`{table_name}`"
        restore_query=f"RESTORE TABLE `{catalog_name}`.`{study_schema_name}`.`{table_name}` TIMESTAMP AS OF '{load_timestamp}'"
        if(audit_df.count()> 0):
            if (timestamp > load_timestamp and version <=1):
              spark.sql(drop_query)
            elif(timestamp > load_timestamp and version > 1):
              spark.sql(restore_query)   
            else:
              pass
    
        else:
          spark.sql(drop_query)


# COMMAND ----------

def handle_error(e,error_process,error_table,domains):
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    query=f"select * from `{catalog_marvel}`.`{schema_marvel}`.{audit_log_table}  where study_id='{study_id}' and environment='{study_environment}' and job_name='{job_name}' and job_status='SUCCESS'"
    audit_df = spark.sql(query)
    parallel_runs = ThreadPool(thread_count)
    parallel_runs.starmap(restore,zip(domains, repeat(audit_df), repeat(catalog_silver), repeat(study_id),repeat(load_timestamp)))
    parallel_runs.starmap(restore,zip(domains, repeat(audit_df), repeat(catalog_gold), repeat(study_id),repeat(load_timestamp)))
    update_audit_log(batch_id, job_id, run_id, study_id, study_environment, "FAILED", error_msg)           
    errant_tables = str(error_table)
    domainstats ={} 
    message = build_clinical_study_json(study_id, errant_tables, study_environment, job_id, run_id, load_timestamp,"", error_msg, domainstats)
    send_notification(study_id,study_environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
    #dbutils.notebook.exit(error_msg)        

# COMMAND ----------

def build_column_datatype(name,dtype):
    if(str(dtype) == "date"):
        return "to_date("+name+",'ddMMMyyyy') as "+name+""
    elif(str(dtype) == "timestamp"):
        return "to_timestamp("+name+",'ddMMMyyyy:HH:mm:ss') as "+name+""
    elif(str(dtype) == "double"):
        return "double("+name+") as "+name+""
    else:
        return str(name)


# COMMAND ----------

def ingest_domain_labels(data_frame, catalog_name, schema_name, table_name,domain_name,temp_study_id):
    
    query_top_record=f"SELECT * FROM `{catalog_name}`.`{schema_name}`.`{table_name}` WHERE report='{domain_name}' LIMIT 1"
    df_top_rec=spark.sql(query_top_record)
    
    if (df_top_rec.count()==0):
        data_frame.createOrReplaceTempView(f"{temp_study_id}_{domain_name}_label_tempview")
        insertqry = f"INSERT INTO `{catalog_name}`.`{schema_name}`.`{table_name}` SELECT * FROM {temp_study_id}_{domain_name}_label_tempview"
        spark.sql(insertqry)
    else:
        data_frame.createOrReplaceTempView(f"{temp_study_id}_{domain_name}_label_tempview")
        latest_label_query=f"SELECT * FROM {temp_study_id}_{domain_name}_label_tempview ip LEFT ANTI JOIN  `{catalog_name}`.`{schema_name}`.`{table_name}` op ON ip.name=op.name AND ip.label=op.label and op.report='{domain_name}'"
        df_final=spark.sql(latest_label_query)
        df_final.createOrReplaceTempView(f"{temp_study_id}_{domain_name}_newupdate_label_tempview")

        update_query=f"MERGE INTO `{catalog_name}`.`{schema_name}`.`{table_name}`  d USING {temp_study_id}_{domain_name}_newupdate_label_tempview as ip ON  d.name = ip.name AND d.report=ip.report WHEN MATCHED THEN UPDATE SET d.D4U_ISACTIVE=false"
        insert_query=f"INSERT INTO `{catalog_name}`.`{schema_name}`.`{table_name}` SELECT * FROM {temp_study_id}_{domain_name}_newupdate_label_tempview"
        execute_sql_with_retry(sql=update_query, log_try="Updating Labels Table")
        spark.sql(insert_query)


# COMMAND ----------

def ingest_domain_metadata(data_frame, catalog_name, schema_name, domain,temp_study_id):

    df=spark.sql(f"show tables in `{catalog_name}`.`{schema_name}`")
    dataframe_meta=data_frame.withColumn("D4U_RECVERDATE",lit(load_timestamp).cast('timestamp')).withColumn("D4U_ISACTIVE",lit(True)).withColumn("D4U_ISDROP",lit(False))
    column_list=dataframe_meta.columns

    if (df.selectExpr(f"any(tableName =='{domain}_meta')").collect()[0][0]):

        silverTable = DeltaTable.forName(spark, str(f"`{catalog_name}`.`{schema_name}`.`{domain}_meta`")).alias('silver')
        silver_records = silverTable.toDF().where(col('D4U_ISACTIVE') == True).alias('silver')
        df_meta = dataframe_meta.join(silver_records,on = ["name","label","type","length"],how="leftanti").select(column_list)

        silverTable.alias("silver").merge(source = df_meta.alias("df"),condition = col('df.name') == col('silver.name')).whenMatchedUpdate(set = {"silver.D4U_ISACTIVE": lit(False)}).execute()

        silverTable.alias("silver").merge(source =  df_meta.alias("df"),condition = col('df.name').isNull()).whenNotMatchedInsertAll().execute()
    else:
        schema=StructType(dataframe_meta.schema.fields)
        silverTableName=createTableIfNotExist(catalog_name, schema_name, f"{domain}_meta", schema)
        silverTable = DeltaTable.forName(spark, str(f"`{catalog_name}`.`{schema_name}`.`{domain}_meta`")).alias('silver')
        silverTable.alias("silver").merge(source =  dataframe_meta.alias("df"),condition = col('df.name').isNull()).whenNotMatchedInsertAll().execute()


# COMMAND ----------

def modify_column_label(catalog_name, schema_name, domain, column_name, data_type,label):
    table = f"`{catalog_name}`.`{schema_name}`.`{domain}`"
    spark.sql(f"ALTER TABLE {table} CHANGE `{column_name}` `{column_name}` {data_type} COMMENT \"{label}\"")

# COMMAND ----------

def modify_column_datatype(catalog_name, schema_name, domain, column_name, data_type,label,old_type):
    
    table = f"`{catalog_name}`.`{schema_name}`.`{domain}`"
    spark.read.table(f"{table}").withColumn(f"{column_name}",col(f"{column_name}").cast(f"{data_type}")).write.format("delta").mode("overwrite").option("overwriteSchema","true").saveAsTable(f"{table}")
    spark.sql(f"ALTER TABLE {table} CHANGE `{column_name}` `{column_name}` {data_type} COMMENT \"{label}\"")
    if(old_type == "double" and data_type == "string"):
        spark.sql(f"""update {table} set {column_name} = rtrim('.',rtrim('0',cast(cast(cast( {column_name} as double) as decimal(27,7)) as string)))""")
        
    

# COMMAND ----------

def add_new_column(catalog_name, schema_name, domain, column_name, data_type,label,temp_study_id):
    
    table = f"`{catalog_name}`.`{schema_name}`.`{domain}`"
    df_pos = spark.sql(f"SELECT varnum, label FROM {temp_study_id}_{domain}_metadata WHERE name = '{column_name}'")
    col_position = df_pos.select("varnum").collect()[0][0]
    prev_col_position = int(col_position) - 1
    new_col_label = df_pos.select("label").collect()[0][0]
    if (int(col_position) == 1):
        add_col_query = f"ALTER TABLE {table} ADD COLUMN {column_name} {data_type} comment \"{label}\" first"  
        spark.sql(add_col_query)
    elif int(prev_col_position) > 0:
        df_prev_col = spark.sql(f"SELECT name FROM {temp_study_id}_{domain}_metadata WHERE varnum = {prev_col_position}")
        prev_col_name = df_prev_col.collect()[0][0]
        add_col_query = f"ALTER TABLE {table} ADD COLUMN {column_name} {data_type} COMMENT \"{label}\" AFTER {prev_col_name}"
        spark.sql(add_col_query)

# COMMAND ----------

def build_pandas_df(zip_extractionpoint_path,meta_file,domain):
    print("build_pandas_df function is called...")
    meta_file_path = zip_extractionpoint_path + "/" + meta_file + ""
    print(meta_file_path)
    df = spark.read.option("header","true").option("delimiter",",").option("ignoreLeadingWhiteSpace","true").csv(meta_file_path)
    df = df.na.drop("all")
    df = df.withColumn("finalformat",when(df.format.rlike("DATETIME[0-9\.]*"),lit("timestamp")).when(df.format.rlike("DATE[^TIME][0-9\.]*"),lit("date")).when(df.format.rlike("TIME[0-9\.]*"),lit("string")).otherwise(df.type))

    df_pandas = df.select("name","finalformat","label","notnull","varnum").toPandas()
    dict = {'name':['D4U_RECID','D4U_RECVER','D4U_DATAPROV','D4U_RECVERDATE','D4U_ISACTIVE','D4U_ISDROP'],
            'finalformat':['string','string','string','timestamp','boolean','boolean'],
            'label': ['DATA4YOU Unique Record Identifier','DATA4YOU Record Version Identifier','DATA4YOU Data Provenance object','DATA4YOU Record Insert Date','DATA4YOU Latest Record Version Flag','DATA4YOU Soft Delete Flag'],      
            'notnull':['yes','yes','yes','yes','yes','yes'],
            'varnum':['na','na','na','na','na','na']
     }
    df_flags = pd.DataFrame(dict)
    df_pandas = pd.concat([df_pandas, df_flags], ignore_index = True)
    df_pandas.reset_index()
    df_pandas["finalformat"] = df_pandas["finalformat"].replace("char","string").replace("num","double")
    df_pandas["notnull"] = df_pandas["notnull"].replace("no","").replace("yes"," not null")
    df_pandas["finalqueryformat"] = df_pandas[["name","finalformat"]].apply(lambda x: build_column_datatype(*x),axis = 1)
    return df_pandas

