# Databricks notebook source
pipeline_environment = dbutils.widgets.get("pipelineEnvironment")
batch_id = dbutils.widgets.get("batchId")
study_id = dbutils.widgets.get("studyId")
dataModel= dbutils.widgets.get("data_model")
environment = dbutils.widgets.get("environment")
load_timestamp = dbutils.widgets.get("loadTimestamp")
job_id = dbutils.widgets.get("job_id")
run_id = dbutils.widgets.get("run_id")
studyId=study_id.upper()
dataModel=dataModel.upper()
date_time_stamp_string = dbutils.widgets.get("date_time_stamp_string")

# COMMAND ----------

# MAGIC %run ../init_scripts/init_load_study_specific_report

# COMMAND ----------

# MAGIC %run  ../utils/audit_logger

# COMMAND ----------

# MAGIC %run ../utils/marvel_util

# COMMAND ----------

try:
    print(f"Data model: {dataModel} | Study Id: {studyId} | Environment: {environment}")
    records = get_marvel_study_listing_config(dataModel, studyId, environment)

    print(len(records))
    if len(records):
        config_dict={}
        for row in records:
            config=row[3]
            tableName=row[1]
            columns_list=config['columns']
            recid_list=[]
            recver_list=[]
            
            is_active = row[4]
            if is_active == False:
                print(f"Skipping an inactive listing, {row[1]}")
                continue

            for key in columns_list:
                if key['isRecIdKey']==True:
                    recid_list.append(key['name'])
                if key['isRecVersionKey']==True:
                    recver_list.append(key['name'])
            combined_dict = dict(RecIdKeys= recid_list, RecverKey = recver_list)
            config_dict[tableName] = combined_dict


        print(config_dict)
        dbutils.jobs.taskValues.set(key   = "config_dict", \
                                                value = config_dict)
        dbutils.jobs.taskValues.set(key   = "date_time_stamp_string", \
                                                value = date_time_stamp_string)
        
    else:
        raise Exception(f"ERROR: {dataModel} Configuration for Study - {studyId} does not exist in DRE Marvel. Job could not proceed")

except Exception as e:
    error_msg = str(e)
    error_msg = error_msg.replace("'","").replace("\"","")
    update_audit_log(batch_id, job_id, run_id, study_id, environment, "FAILED", error_msg)
    errant_tables = "N/A"
    domainstats ={} 
    message = build_clinical_study_json(study_id,errant_tables,environment,job_id,run_id,load_timestamp,data_source,error_msg,domainstats)
    print(message)
    send_notification(study_id,environment,"Failed",admin_user_recipients,message,vpc_name,"NA","","","","")
    raise e
